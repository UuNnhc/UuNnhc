#pragma once

#define HTTP_SERVER "164.92.85.17"
#define HTTP_PORT 80

#define TFTP_SERVER "164.92.85.17"
