#pragma once

// Choose to either define DEBUG_PRINT or exclude

#ifdef DEBUG
#define DEBUG_PRINT(fmt, ...) printf("\e[0;1m\e[95;1m%s()\e[0;1m:%d:" fmt, __func__, __LINE__, ##__VA_ARGS__)
#endif

#ifndef DEBUG
#define DEBUG_PRINT(...)
#endif
