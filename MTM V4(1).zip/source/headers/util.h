#pragma once

#include <stdint.h>

void util_remove_trailing(char *, int);
char *util_strcat(char *, const char *);
int util_strcpy(char *, char *);
uint32_t util_local_addr(void);
char *util_strstr(register char *, char *);
int util_exists(char *, int, char *, int);
void util_memset(void *, int, int);
int util_strlen(char *);
int util_strcmp(char *, char *);
void util_memcpy(void *, void *, int);
void util_split_free(char **, size_t);
int util_split(const char *, char, char ***);
char *util_itoa(int, int, char *);
