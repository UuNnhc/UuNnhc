#pragma once

#include <stdint.h>

#include "includes.h"

struct dnshdr {
    uint16_t id, opts, qdcount, ancount, nscount, arcount;
};

struct dns_question {
    uint16_t qtype, qclass;
};

struct dns_resource {
    uint16_t type, _class;
    uint32_t ttl;
    uint16_t data_len;
} __attribute__((packed));

struct grehdr {
    uint16_t opts, protocol;
};

enum 
{
	PROTO_DNS_QTYPE_A   = 1,
    PROTO_DNS_QCLASS_IP = 1,

    PROTO_TCP_OPT_NOP   = 1,
    PROTO_TCP_OPT_MSS   = 2,
    PROTO_TCP_OPT_WSS   = 3,
    PROTO_TCP_OPT_SACK  = 4,
    PROTO_TCP_OPT_TSVAL = 8,

    PROTO_GRE_TRANS_ETH = 0x6558
};
